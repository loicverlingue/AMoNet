# AMoNet

Artificial Molecular Networks
V0.1

## Packaging on Mac instructions

### Using the install target
Normally, build the target install and it should generate a bundle (.app directory file and a .dmg file) in the build/bundles directory.
Note that you need to provide the path to the binary qtmacdeploy in the CMake variable.
For some unknown reason, the generated .app directory file does not run.

### Manually using **macdeployqt**
- build the AMoNet target in Release
- in the build/source/Release directory, open the AMoNet.app directory file (Right click > "Show package content"). 
- create a `Resources` directory in the AMoNet.app/Contents if it does not exist yet.
- copy all the input files required for AMoNet to run in that AMoNet.app/Contents/Resources directory:
  - settings.ini
  - therapies folder
  - *.csv files
  - *.qm translation files

- Run **qtmacdeploy** using the following command line:
`~/Qt/5.15.2/clang_64/bin/macdeployqt AMoNet.app/ -verbose=2 -always-overwrite -qmldir="/Users/sqi/Projects/AMoNet/src/app/source/gui/views/" -dmg`
Change directories accordingly.

### Running the app 
On Mac, once you got the .dmg file, open it and drag & drop its .app content to your applications directory.
AMoNet input files are provided within the .app file. Once user runs it for the first time, all input files are copied to the `~/Library/AMoNet` folder. 

Note that, the application will load input files from the `~/Library/AMoNet` directory in priority, if it doesn't find them, it will load the default ones provided with the package (and copy those missing the `~/Library/AMoNet` folder). This allow the user to edit the files located in the home directory.

Log outputs are located in the standard log directory ~/Library/Logs/AMoNet




