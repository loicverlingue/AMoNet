Contribution guidelines
==============================

Coding style
------------------------------

This project follows the [SurgiQual Institute's coding style](https://git.surgiqual-institute.com/sqi/softwarewiki/-/wikis/c++/SurgiQual-Institute's-Cpp-Coding-style).

Environment
------------------------------

This project uses Visual studio 2019.
