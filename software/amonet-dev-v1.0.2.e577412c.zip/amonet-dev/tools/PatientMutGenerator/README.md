# HelloCommandLine

Template for command line applications.

## Cloning the repository

```bash
git clone --recurse-submodules https://git.surgiqual-institute.com/sqi/cppsamples/hellocommandline.git
```

Execute the following command to update the repository:

```bash
git pull
git submodule update --init --recursive
```
