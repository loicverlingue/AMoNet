#ifndef _utils_Exceptions_
#define _utils_Exceptions_

//! \file Exceptions.h
//! \brief Defines Exceptions
//! \author http://www.surgiqual-institute.com/
//! \date April 2019


// STL
#include <string>
#include <exception>
#include <stdexcept>

// Qt
#include <qstring.h>
#include <qfileinfo.h>

template<class ExceptionType>
inline void _throwVerboseException(const QString& p_exceptionName, const QString& p_message, const QString& p_function, const QFileInfo& p_file, int p_line)
{
    throw ExceptionType(QString("%1 : %2 \n\tin function '%3' \n\tat %4:%5")
        .arg(p_exceptionName)
        .arg(p_message)
        .arg(p_function)
        .arg(p_file.fileName())
        .arg(p_line)
        .toStdString()
    );
}

template<class ExceptionType>
inline void _throwVerboseException(const QString& p_exceptionName, const std::string& p_message, const QString& p_function, const QFileInfo& p_file, int p_line)
{
    _throwVerboseException<ExceptionType>(
        p_exceptionName,
        QString::fromStdString(p_message),
        p_function,
        p_file,
        p_line
        );
}

template<class ExceptionType>
inline void _throwVerboseException(const QString& p_exceptionName, const char* p_message, const QString& p_function, const QFileInfo& p_file, int p_line)
{
    _throwVerboseException<ExceptionType>(
        p_exceptionName,
        QString::fromLocal8Bit(p_message),
        p_function,
        p_file,
        p_line
        );
}

//! \brief Get the string representation of the given token.
//!
//! \details See the sample code below:
//! \code{.cpp}
//! int someInt = 0;
//! // Prints "someInt"
//! std::cout << TOKEN_STR(someInt) << std::endl;
//!
//! // Prints "float"
//! std::cout << TOKEN_STR(float) << std::endl;
//!
//! class SomeClass {};
//! //Prints "SomeClass"
//! std::cout << TOKEN_STR(SomeClass) << std::endl;
//! \endcode
// NOLINTNEXTLINE(cppcoreguidelines-macro-usage)
#define TOKEN_STR(token) (#token)


//! \brief Throws an exception that will contain where the exception was thrown.
//! \param[in] exception_type The exception type to use. Any class derived from std::exception is valid.
//! \param[in] message Exception message.
//!
//! \details In the sample code below, the exception contains the following message:
//! \verbatim
//! std::runtime_error: Something went wrong
//!      in function 'someFunction'
//!      at C:\Projects\SomeProject\main.cpp:123
//! \endverbatim
//! \code{.cpp}
//! // Defined in file C:\Projects\SomeProject\main.cpp
//! void someFunction()
//! {
//!     ...
//!
//!     // Throw at line 123
//!     THROW_VERBOSE_EXCEPTION(std::runtime_error, "Something went wrong");
//!
//!     ...
//! }
//! \endcode
// NOLINTNEXTLINE(cppcoreguidelines-macro-usage)
#define THROW_VERBOSE_EXCEPTION(exception_type, message)       \
    (                                                          \
        _throwVerboseException<exception_type>(                \
            QString::fromStdString(TOKEN_STR(exception_type)), \
            message,                                           \
            QString::fromStdString(__func__),                  \
            QFileInfo(__FILE__),                               \
            __LINE__                                           \
        )                                                      \
    )



#endif // _utils_Exceptions_
