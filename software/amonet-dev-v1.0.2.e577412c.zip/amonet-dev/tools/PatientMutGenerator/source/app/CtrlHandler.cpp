#pragma once

// Qt
#include <qloggingcategory.h>

// STL

// Libraries

// Project dependencies
#include "Application.h"
#include "CtrlHandler.h"

namespace app {
    BOOL WINAPI CtrlHandler(DWORD CtrlEvent)
    {
        switch (CtrlEvent) {
            case CTRL_C_EVENT:
                return TRUE; // We do not want Ctrl+C to close the application.
            case CTRL_CLOSE_EVENT:
            case CTRL_SHUTDOWN_EVENT:
            case CTRL_LOGOFF_EVENT:
                qInfo() << "Close signal received.";
                //call deallocators/destructors here
                return TRUE;

            default:
                return FALSE; // Any event not handled in this function is passed to the next handler.
        }
    }

} // namespace app