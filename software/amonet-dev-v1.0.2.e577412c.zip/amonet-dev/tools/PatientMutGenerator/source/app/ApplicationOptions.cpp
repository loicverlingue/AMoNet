//! \file ApplicationOptions.cpp
//! \brief Implements ApplicationOptions
//! \author http://www.surgiqual-institute.com/
//! \date September 2020


// Library dependencies

// Project dependencies
#include "ApplicationOptions.h"


namespace app
{
    const QCommandLineOption ApplicationOptions::VERBOSE_OPTION
    {
        "verbose",
        "Verbose mode."
    };

    ApplicationOptions::ApplicationOptions()
    {
    }

    bool ApplicationOptions::verbose() const
    {
        return m_commandLineParser.isSet(VERBOSE_OPTION);
    }

    void ApplicationOptions::init(const QCoreApplication& p_app)
    {
        m_commandLineParser.setApplicationDescription("Command line application.");
        m_commandLineParser.addHelpOption();
        m_commandLineParser.addVersionOption();

        m_commandLineParser.addOption(VERBOSE_OPTION);

        m_commandLineParser.process(p_app);
    }

} // app


