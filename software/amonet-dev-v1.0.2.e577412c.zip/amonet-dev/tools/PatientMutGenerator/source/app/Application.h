#ifndef _app_Application_
#define _app_Application_

//! \file Application.h
//! \brief Defines Application
//! \author http://www.surgiqual-institute.com/
//! \date January 2020

// STL
#include <memory>

// Qt
#include <qcoreapplication.h>
#include <qtranslator.h>
#include <qsettings.h>
#include <qrandom.h>
// Project dependencies
#include "utils/Exceptions.h"

namespace app
{
    class ApplicationSettings;
    class ApplicationOptions;
}

namespace app
{
    //! \class Application
    //! \brief Application singleton
    class Application : public QCoreApplication
    {
        // constructor / destructor / operator
    public:
        //! \brief private Constructor
        //! /!\ pay attention to the reference to argc (not same signature as main.cpp !!!!)
        explicit Application(int &argc, char **argv);

        //! \brief Destructor
        virtual ~Application();

        //! \brief Copy constructor
        //! \param[in] p_other Object to copy
        Application(const Application& p_other) = delete;

        //! \brief Copy assignment operator
        //! \param[in] p_other Object to copy
        Application& operator=(const Application& p_other) = delete;

        //! \brief Move constructor
        //! \param[in] p_other Object to move
        Application(Application&& p_other) = delete;

        //! \brief Move assignment operator
        //! \param[in] p_other Object to move
        Application& operator=(Application&& p_other) = delete;

        // get / set
    public:
        //! \brief Get application settings.
        std::shared_ptr<const ApplicationSettings> getSettings() const;

        //! \brief Get application options.
        std::shared_ptr<const ApplicationOptions> getOptions() const;

    protected:
    private:

        // methods / functions / slots
    public:

        //! \brief Initializes the application
        void init();

        //! \brief Executes the application
        int exec();

    protected:
    private:

        //! \brief Loads the application settings.
        void loadSettings();

        //! \brief Initializes application infos.
        void initAppInfo();

        //! \brief Initializes translations.
        void initTranslations();

        //! \brief Initializes command line.
        void initCommandLine();

        //! \brief Generate a csv with randomly generated patients
        //! \param p_nbOfPatient nb of patients to generate
        void generatePatientsMUT(int p_nbOfPatient);

        //! \brief Create a mutation value from a random number
        //! \param p_rand random value in range [0,1]
        //! \return a mutation value (among NA, 0.3, 0.6, 1)
        QString randomMutValue(double p_rand);

        // members
    protected:
    private:

        //! \brief Applications settings.
        std::shared_ptr<ApplicationSettings> m_settings = nullptr;

        //! \brief Translator for managing translations.
        //! \details This objects needs to be instantiated for dynamic translations to work.
        std::unique_ptr<QTranslator> m_translator = nullptr;

        //! \brief Command line options.
        std::shared_ptr<ApplicationOptions> m_options = nullptr;
    };

} // app

#endif // _app_Application_
