//! \file Main.cpp
//! \brief Defines application start.
//! \author http://www.surgiqual-institute.com/
//! \date January 2020

// STL
#include <iostream>

// Qt
#include <qdebug.h>

// Project dependencies
#include "Application.h"
#include "CtrlHandler.h"


// No namespace for the 'main' (even if the file is in the app directory).

int main(int argc, char* argv[])
{
    int returnValue{ EXIT_SUCCESS };

    // Set the global terminate handler to warn about exception management issues
    std::set_terminate(
        []()
        {
            qCritical() << "Unhandled exception.";
            std::abort();
        }
    );

    if (SetConsoleCtrlHandler(app::CtrlHandler, TRUE)) {
        qInfo() << "Control Handler set.\n ";

        try
        {
            // initialize
            app::Application app(argc, argv);
            app.init();
            returnValue = app.exec();
        }
        // Catch all exceptions, display their message if possible
        catch (const std::exception& exception)
        {
            qCritical() << exception.what();
            returnValue = EXIT_FAILURE;
        }
        catch (...)
        {
            qCritical() << "An error occurred.";
            returnValue = EXIT_FAILURE;
        }
    }
    else {
        qInfo() << "ERROR : Could not set control handler.";
        return EXIT_FAILURE;
    }

    // Do last things here before leaving (deallocations)


    return returnValue;
}
