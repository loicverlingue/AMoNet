#ifndef _app_ApplicationSettings_
#define _app_ApplicationSettings_

//! \file ApplicationSettings.h
//! \brief Defines ApplicationSettings
//! \author http://www.surgiqual-institute.com/
//! \date February 2020


// Qt
#include <qsettings.h>

// Project dependencies
#include "utils/Exceptions.h"

class ApplicationSettingsTestU;

namespace app
{
    //-----------------------------------------------------------------------------
    //! \class ApplicationSettings
    //! \brief Holds the settings of the applicaion from INI files.
    class ApplicationSettings
    {
        friend class ApplicationSettingsTestU;

        // constructor / destructor / operator
    public:
        //! \brief Default constructor
        explicit ApplicationSettings();

        //! \brief Destructor
        virtual ~ApplicationSettings() = default;

        //! \brief Copy constructor
        //! \param[in] p_other Object to copy
        ApplicationSettings(const ApplicationSettings& p_other) = default; // To implement if copying is non-trivial

        //! \brief Copy assignment operator
        //! \param[in] p_other Object to copy
        ApplicationSettings& operator=(const ApplicationSettings& p_other) = default; // To implement if copying is non-trivial

        //! \brief Move constructor
        //! \param[in] p_other Object to move
        ApplicationSettings(ApplicationSettings&& p_other) = default; // To implement if moving is non trivial

        //! \brief Move assignment operator
        //! \param[in] p_other Object to move
        ApplicationSettings& operator=(ApplicationSettings&& p_other) = default; // To implement if moving is non trivial

        // get / set
    public:

        //! \brief Gets the main settings of the application
        std::shared_ptr<const QSettings> getMainSettings() const;

        //! \brief Gets a settings value from the main settings
        //! \param[in] p_key Setting key
        //! \return Setting value
        template <typename ValueType>
        inline ValueType getMainSettingsValue(const QString& p_key) const
        {
            return GET_SETTINGS_VALUE<ValueType>(p_key, m_mainSettings);
        }

    protected:
    private:

        //! \brief Gets a settings value from the main settings
        //! \param[in] p_key Setting key
        //! \param[in] p_settings Settings containing the value
        //! \return Setting value
        template <typename ValueType>
        inline static ValueType GET_SETTINGS_VALUE(const QString& p_key, const std::shared_ptr<const QSettings>& p_settings)
        {
            QVariant settingsValueVariant = p_settings->value(p_key);
            if (!settingsValueVariant.isValid() || settingsValueVariant.isNull())
            {
                THROW_VERBOSE_EXCEPTION(std::logic_error, "Unable to get the settings key " + p_key.toStdString());
            }
            if (!settingsValueVariant.canConvert<ValueType>())
            {
                THROW_VERBOSE_EXCEPTION(std::logic_error, "Incorrect type for settings key " + p_key.toStdString());
            }
            return qvariant_cast<ValueType>(settingsValueVariant);
        }

        // methods / functions / slots
    public:

        //! \brief Loads the settings from INI files.
        void load();

    protected:
    private:

        //! \brief Loads some settings from a particular INI file.
        //! \param[in] p_iniFilePath INI file to load
        //! \param[out] p_settings Settings to load
        static void LOAD_SETTINGS(const QString& p_iniFilePath, std::shared_ptr<QSettings>* p_settings);

        // members
    protected:
    private:

        //! \brief Main settings of the application
        std::shared_ptr<QSettings> m_mainSettings = nullptr;

        // Add other settings here

    };

} // app

#endif // _app_ApplicationSettings_


