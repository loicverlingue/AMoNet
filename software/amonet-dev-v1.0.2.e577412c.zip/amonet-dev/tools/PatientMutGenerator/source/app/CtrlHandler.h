#pragma once

// Qt

// STL
#include <windows.h>

// Libraries

// Project dependencies

namespace app {
    /*************************************************************************************
     * \brief Function to handle application exit by close.
     * \return TRUE if the event was handled, FALSE otherwise (and the event is to be handled by the next handler).
     * 
     * Will exit application on close,shutdown of computer or session logging off. Ctrl+C doesn't
     * quit the application (does nothing).
     * 
     * Microsoft documentation:
     * https://docs.microsoft.com/en-us/windows/console/setconsolectrlhandler?redirectedfrom=MSDN
     *
     * Microsoft example:
     * https://docs.microsoft.com/en-us/windows/console/registering-a-control-handler-function
     *
     * More explanation on why use this:
     * https://stackoverflow.com/questions/696117/what-happens-when-you-close-a-c-console-application
     */
    BOOL WINAPI CtrlHandler(DWORD fdwCtrlType);
} // namespace app