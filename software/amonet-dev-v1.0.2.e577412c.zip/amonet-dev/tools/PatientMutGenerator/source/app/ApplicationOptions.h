#ifndef _app_ApplicationOptions_
#define _app_ApplicationOptions_

//! \file ApplicationOptions.h
//! \brief Defines ApplicationOptions
//! \author http://www.surgiqual-institute.com/
//! \date September 2020

// Qt
#include <qcoreapplication.h>
#include <qcommandlineoption.h>
#include <qcommandlineparser.h>

// Project dependencies


namespace app
{
    //! \class ApplicationOptions
    //! \brief Stores options passed as command lines arguments to the application.
    class ApplicationOptions
    {
        // constructor / destructor / operator
    public:
        //! \brief Default constructor
        explicit ApplicationOptions();

        //! \brief Destructor
        virtual ~ApplicationOptions() = default;

        //! \brief Copy constructor
        //! \param[in] p_other Object to copy
        ApplicationOptions(const ApplicationOptions& p_other) = default; // To implement if copying is non-trivial

        //! \brief Copy assignment operator
        //! \param[in] p_other Object to copy
        ApplicationOptions& operator=(const ApplicationOptions& p_other) = default; // To implement if copying is non-trivial

        //! \brief Move constructor
        //! \param[in] p_other Object to move
        ApplicationOptions(ApplicationOptions&& p_other) = default; // To implement if moving is non trivial

        //! \brief Move assignment operator
        //! \param[in] p_other Object to move
        ApplicationOptions& operator=(ApplicationOptions&& p_other) = default; // To implement if moving is non trivial

        // get / set
    public:

        bool verbose() const;

    protected:
    private:

        // methods / functions / slots
    public:

        //! \brief Initializes the options.
        void init(const QCoreApplication& p_app);

    protected:
    private:

        // members
    protected:
    private:

        static const QCommandLineOption VERBOSE_OPTION;

        //! Command line parser
        QCommandLineParser m_commandLineParser;

    };

} // app

#endif // _app_ApplicationOptions_
