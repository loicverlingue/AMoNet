//! \file Application.cpp
//! \brief Implements Application
//! \author http://www.surgiqual-institute.com/
//! \date January 2020

// Std
#include <iostream>
#include <ctime>
// Qt
#include <qloggingcategory.h>
#include <qstring.h>
#include <qfile>
#include <qtextstream.h>
#include <qdir.h>

// Project dependencies
#include "Application.h"
#include "Version.h"
#include "ApplicationSettings.h"
#include "ApplicationOptions.h"

namespace app
{

    Application::Application(int &argc, char **argv)
        : QCoreApplication(argc, argv)
    {
    }

    Application::~Application()
    {
    }

    std::shared_ptr<const ApplicationSettings> Application::getSettings() const
    {
        return m_settings;
    }

    std::shared_ptr<const ApplicationOptions> Application::getOptions() const
    {
        return m_options;
    }

    void Application::init()
    {
        initCommandLine();
        loadSettings();
        initAppInfo();
        initTranslations();
    }

    int Application::exec()
    {
        std::cout << std::endl;
        std::cout << "===========================================================" << std::endl;
        std::cout << "======> How many patients do you want to generate?" << std::endl;
        
        std::cout << "Answer : ";
        int nbPatient=0;
        std::cin >> nbPatient;

        generatePatientsMUT(nbPatient);

        if (m_options->verbose())
        {
            qInfo() << "Verbose mode activated.";
        }

        return EXIT_SUCCESS;
    }

    void Application::loadSettings()
    {
        m_settings = std::make_unique<ApplicationSettings>();
        m_settings->load();
    }

    void Application::initAppInfo()
    {
        // App info
        setOrganizationName(PROJECT_ORGANIZATION);
        setApplicationVersion(QString("%1.%2").arg(PROJECT_VERSION).arg(GIT_COMMIT_HASH));
        setOrganizationDomain(PROJECT_DOMAIN);
        setApplicationName(PROJECT_NAME);

        // Info logs
        qInfo() << "App version:" << applicationVersion().toStdString().c_str();

        // Debug logs
        qDebug() << "Qt compile version:" << QT_VERSION_STR;
        qDebug() << "Qt runtime version:" << qVersion();
    }

    void Application::initTranslations()
    {
        QString language = m_settings->getMainSettingsValue<QString>("languages/applicationLanguage");
        m_translator = std::make_unique<QTranslator>();
        QString translationFilePath("translation_" + language);
        if (!m_translator->load(translationFilePath))
        {
            qCritical() << "Could not load translations from" << translationFilePath;
        }
        else
        {
            qDebug() << "Translations loaded from" << translationFilePath;
        }
        if (!installTranslator(m_translator.get()))
        {
            qCritical() << "Could not install translator";
        }
        else
        {
            qDebug() << "Translator installed";
        }
    }

    void Application::initCommandLine()
    {
        m_options = std::make_shared<ApplicationOptions>();
        m_options->init(*this);
    }

    void Application::generatePatientsMUT(int p_nbOfPatient)
    {
        QString geneTemplate;

        // load template
        QFile fileTemplate("template.csv");
        if (!fileTemplate.open(QIODevice::ReadOnly))
        {
            qInfo("Cannot open template.csv file");
        }
        else
        {
            // read the file data
            geneTemplate = fileTemplate.readAll();
            fileTemplate.close();
        }

        QFile output("randomPatientsMUT.csv");
        if (output.open(QFile::WriteOnly))
        {
            QTextStream stream(&output);
            
            // init random genrator
            QRandomGenerator randGene;
            randGene.seed(std::time(0));

            // insert gene template
            stream << geneTemplate;

            // extract nb of genes
            QStringList listData = geneTemplate.split("\r\n");
            listData.operator[](0).remove("\"");
            int nbOfGenes = listData.at(0).split(",").size() - 1; 

            for (int i = 0; i < p_nbOfPatient; i++)
            {
                // insert random mutation values (NA,0.3,0.6 or 1) for each gene
                stream << "Patient" + QString::number(i);
                for (int j = 0; j < nbOfGenes; j++)
                {
                    stream << "," << randomMutValue(randGene.generateDouble());
                }
                stream << "\r\n";
            }
        }
        else 
        {
            qInfo("Cannot write randomPatientsMUT.csv file");
        }

        QDir currentDir;
        qInfo() << "File generated at : " << currentDir.absoluteFilePath("randomPatientsMUT.csv");

        // close output file
        output.close();
    }

    QString Application::randomMutValue(double p_rand)
    {
        if (p_rand >= 0.75)
        {
            return "1";
        }
        if (p_rand >= 0.5)
        {
            return "0.6";
        }
        if (p_rand >= 0.25)
        {
            return "0.3";
        }
        return "NA";
    }

} // app
