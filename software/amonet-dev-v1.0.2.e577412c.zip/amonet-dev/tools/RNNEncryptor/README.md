# Hello QML

Template for QML applications.

## Cloning the repository

```bash
git clone --recurse-submodules https://git.surgiqual-institute.com/sqi/cppsamples/helloqml.git
```
