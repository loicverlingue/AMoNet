//! \file EncryptorModel.cpp
//! \brief Implements EncryptorModel
//! \author http://www.surgiqual-institute.com/
//! \date April 2021


// Qt
#include <qfile.h>
// Project dependencies
#include "EncryptorModel.h"
#include "encryption/SimpleCrypt.h"
#include "def/EncryptionDefinitions.h"

namespace gui
{

    EncryptorModel::EncryptorModel(QObject* p_parent)
        : QObject{ p_parent }
    {
    }

    QString EncryptorModel::getStatusMessage() const
    {
        return m_statusMessage;
    }

    bool EncryptorModel::getIsSuccessful() const
    {
        return m_isSuccessful;
    }

    void EncryptorModel::slotEncryptData(const QString& p_path)
    {

        QFile inputFile(p_path);
        if (!inputFile.open(QIODevice::ReadOnly))
        {
            inputFile.close();
            m_statusMessage = tr("Error : Cannot open file");
            emit signalStatusMessageChanged();
            m_isSuccessful = false;
            emit signalIsSuccessfulChanged();
        }
        else
        {
            // Read file
            QByteArray dataToEncrypt = inputFile.readAll();
            inputFile.close();

            // Encrypt data
            SimpleCrypt crypto(def::AMONET_ENCRYPT_KEY);
            QByteArray encryptedFileContent = crypto.encryptToByteArray(dataToEncrypt);
            
            // Create output path
            QString folderPath = p_path.left(p_path.lastIndexOf("/") + 1);
            QString fileName = p_path.mid(p_path.lastIndexOf("/") + 1);
            QString outputPath = folderPath + "encrypted_" + fileName;

            // Write encrypted file
            QFile encryptedFile(outputPath);
            encryptedFile.open(QIODevice::WriteOnly);
            encryptedFile.write(encryptedFileContent);
            encryptedFile.close();
            
            // update status
            m_statusMessage = tr("Success : Encrypted file saved at ") + outputPath;
            emit signalStatusMessageChanged();
            m_isSuccessful = true;
            emit signalIsSuccessfulChanged();
        }
    }
    void EncryptorModel::slotReset()
    {
        m_statusMessage = "";
        m_isSuccessful = false;
        emit signalStatusMessageChanged();
        emit signalIsSuccessfulChanged();
    }
    void EncryptorModel::REGISTER_QML_TYPE()
    {
        qmlRegisterType<EncryptorModel>("gui.models", 1, 0, "EncryptorModel");
    }

} // gui


