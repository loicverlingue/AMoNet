#ifndef _gui_EncryptorModel_
#define _gui_EncryptorModel_

//! \file EncryptorModel.h
//! \brief Defines EncryptorModel
//! \author http://www.surgiqual-institute.com/
//! \date April 2021


// Qt
#include <qobject.h>
#include <qqml.h>
#include <qstring.h>
// Project dependencies


namespace gui
{
    //! \class EncryptorModel
    //! \brief ...
    class EncryptorModel : public QObject
    {
        Q_OBJECT
            Q_PROPERTY(QString statusMessage READ getStatusMessage NOTIFY signalStatusMessageChanged)
            Q_PROPERTY(bool isSuccessful READ getIsSuccessful NOTIFY signalIsSuccessfulChanged)

        // constructor / destructor / operator
    public:
        //! \brief Default constructor
        explicit EncryptorModel(QObject* p_parent = nullptr);

        //! \brief Destructor
        virtual ~EncryptorModel() = default;

        //! \brief Copy constructor
        //! \param[in] p_other Object to copy
        EncryptorModel(const EncryptorModel& p_other) = default; // To implement if copying is non-trivial

        //! \brief Copy assignment operator
        //! \param[in] p_other Object to copy
        EncryptorModel& operator=(const EncryptorModel& p_other) = default; // To implement if copying is non-trivial

        //! \brief Move constructor
        //! \param[in] p_other Object to move
        EncryptorModel(EncryptorModel&& p_other) = default; // To implement if moving is non trivial

        //! \brief Move assignment operator
        //! \param[in] p_other Object to move
        EncryptorModel& operator=(EncryptorModel&& p_other) = default; // To implement if moving is non trivial

        // get / set
    public:
        [[nodiscard]]
        //! \brief get the status message of the encryption
        //! \return the status message
        QString getStatusMessage() const;

        [[nodiscard]]
        //! \brief get the success status of the encryption
        //! \return the success status
        bool getIsSuccessful() const;
    protected:
    private:

    signals:
        void signalStatusMessageChanged();
        void signalIsSuccessfulChanged();
    public slots:
        //! \brief encrypt csv file
        //! \param p_path path of the file to encrypt
        void slotEncryptData(const QString& p_path);

        //! \brief reset the status
        void slotReset();

        // methods / functions / slots
    public:
        //! \brief register qml type
        static void REGISTER_QML_TYPE();
    protected:
    private:

        // members
    protected:
    private:
        //! \brief status message of the encryption
        QString m_statusMessage;

        //! \brief status of the success
        bool m_isSuccessful = false;
    };

} // gui

#endif // _gui_EncryptorModel_
