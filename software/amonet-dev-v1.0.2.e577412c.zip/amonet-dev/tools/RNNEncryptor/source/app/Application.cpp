//! \file Application.cpp
//! \brief Implements Application
//! \author http://www.surgiqual-institute.com/
//! \date January 2020

// Qt
#include <qqmlcontext.h>
#include <qloggingcategory.h>
#include <qicon.h>

// Project dependencies
#include "Application.h"
#include "Version.h"
#include "gui/Registry.h"
#include "ApplicationSettings.h"

namespace app
{
    Application::Application(int &argc, char **argv)
        : QGuiApplication(argc, argv)
    {
    }

    Application::~Application() = default;

    std::shared_ptr<const ApplicationSettings> Application::getSettings() const
    {
        return m_settings;
    }

    void Application::init()
    {
        loadSettings();
        initAppInfo();
        initDisplaySettings();
        initTranslations();
        loadEngine();
    }

    void Application::loadSettings()
    {
        m_settings = std::make_unique<ApplicationSettings>();
        m_settings->load();
    }

    void Application::initAppInfo()
    {
        // App icon
        setWindowIcon(QIcon("://icons/windowIcon"));

        // App info
        setOrganizationName(PROJECT_ORGANIZATION);
        setApplicationVersion(QString("%1.%2").arg(PROJECT_VERSION).arg(GIT_COMMIT_HASH));
        setOrganizationDomain(PROJECT_DOMAIN);
        setApplicationName(PROJECT_NAME);

        // Info logs
        qInfo() << "App version:" << applicationVersion().toStdString().c_str();

        // Debug logs
        qDebug() << "Qt compile version:" << QT_VERSION_STR;
        qDebug() << "Qt runtime version:" << qVersion();
#ifndef NDEBUG
        QLoggingCategory::setFilterRules(QStringLiteral("qt.qml.binding.removal.info=true"));
#endif
    }

    void Application::initDisplaySettings()
    {
        // Set MSAA samples for shapes
        QSurfaceFormat format;
        format.setSamples(m_settings->getMainSettingsValue<int>("display/msaaSamples"));
        QSurfaceFormat::setDefaultFormat(format);
    }

    void Application::initTranslations()
    {
        auto language = m_settings->getMainSettingsValue<QString>("languages/applicationLanguage");
        m_translator = std::make_unique<QTranslator>();
        QString translationFilePath("translation_" + language);
        if (!m_translator->load(translationFilePath))
        {
            qCritical() << "Could not load translations from" << translationFilePath;
        }
        else
        {
            qDebug() << "Translations loaded from" << translationFilePath;
        }
        if (!installTranslator(m_translator.get()))
        {
            qCritical() << "Could not install translator";
        }
        else
        {
            qDebug() << "Translator installed";
        }
    }

    void Application::loadEngine()
    {
        // Register types
        gui::Registry::REGISTER_QML_TYPES();

        // Init QML engine
        m_engine = std::make_unique<QQmlApplicationEngine>();

        // Load QML engine
        m_engine->load(QUrl(QStringLiteral("qrc:/main.qml")));
    }

} // app
