#ifndef _app_Application_
#define _app_Application_

//! \file Application.h
//! \brief Defines Application
//! \author http://www.surgiqual-institute.com/
//! \date January 2020


// Qt
#include <qguiapplication.h>
#include <qoffscreensurface.h>
#include <qqmlapplicationengine.h>
#include <qtranslator.h>
#include <qsettings.h>

// Project dependencies
#include "utils/Exceptions.h"

namespace app
{
    class ApplicationSettings;
}

namespace app
{
    //! \class Application
    //! \brief Application singleton
    class Application : public QGuiApplication
    {
        // constructor / destructor / operator
    public:
        //! \brief private Constructor
        //! /!\ pay attention to the reference to argc (not same signature as main.cpp !!!!)
        explicit Application(int &argc, char **argv);

        //! \brief Destructor
        ~Application() override;

        //! \brief Copy constructor
        //! \param[in] p_other Object to copy
        Application(const Application& p_other) = delete;

        //! \brief Copy assignment operator
        //! \param[in] p_other Object to copy
        Application& operator=(const Application& p_other) = delete;

        //! \brief Move constructor
        //! \param[in] p_other Object to move
        Application(Application&& p_other) = delete;

        //! \brief Move assignment operator
        //! \param[in] p_other Object to move
        Application& operator=(Application&& p_other) = delete;

        // get / set
    public:

        //! \brief Get application settings.
        [[nodiscard]]
        std::shared_ptr<const ApplicationSettings> getSettings() const;

    protected:
    private:

        // methods / functions / slots
    public:
        //! \brief initialise appdata
        void init();


    protected:
    private:

        //! \brief Loads the application settings.
        void loadSettings();

        //! \brief Initializes application infos.
        static void initAppInfo();

        //! \brief Initialiezes display settings.
        void initDisplaySettings();

        //! \brief Initializes translations.
        void initTranslations();

        //! \brief Initializes and load QMl engine
        void loadEngine();

        // members
    protected:
    private:

        //! \brief Applications settings.
        std::shared_ptr<ApplicationSettings> m_settings = nullptr;

        //! \brief qml engine to use the qml system
        std::unique_ptr<QQmlApplicationEngine> m_engine = nullptr;

        //! \brief Translator for managing translations.
        //! \details This objects needs to be instantiated for dynamic translations to work.
        std::unique_ptr<QTranslator> m_translator = nullptr;
    };

} // app

#endif // _app_Application_
