# RcppTest

This R project's goal is to test several simple uses of Rcpp, which interfaces R codes with c++ ones

## How to use

1 - You first have to install Rtool. An install exe can be founded here : https://cran.r-project.org/bin/windows/Rtools/

2 - Open the project on RStudio (open.Rproj file)

4 - Install the Rcpp packgage -> type in RStudio's console : install.packages(Rcpp)

3 - Open the file R/main.R, click on "Source on Save"

4 - Save the file to add it to the sources (Ctrl+S)

5 - Call the execute function directly in the console