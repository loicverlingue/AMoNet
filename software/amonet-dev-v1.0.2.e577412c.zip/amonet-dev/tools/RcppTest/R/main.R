# main test app
execute <- function()
{
    library(Rcpp)

    sourceCpp('src/myClass.cpp')
    sourceCpp('src/test.cpp')


    print("TEST - Rcpp class exposition => expected result 10 and FALSE")
    localClass<-new(myClass,10,20)
    print(localClass$X)
    print(localClass$isEqual())

    print("TEST - Rcpp function exposition => expected result 30")
    print(addNb(10,30))

    print("TEST - Rcpp function calling using c++ class => expected result TRUE")
    print(useClass(10))

    print("TEST - Rcpp function using stl vector => expected result 5")
    print(getVectorSize())

    print("TEST - Rcpp function using stl map => expected result 1 and 0")
    print(playWithMap("hey"))
    print(playWithMap("salut"))

    print("TEST - Matrix conversion => expected result 3")
    localMat<-matrix(0,3,4);
    print(playWithMatrix(localMat))

    # Create two vectors of different lengths.
    vector1 <- c(5,9,3)
    vector2 <- c(10,11,12,13,14,15)
    column.names <- c("COL1","COL2","COL3")
    row.names <- c("ROW1","ROW2","ROW3")
    matrix.names <- c("Matrix1","Matrix2")
    result <- array(c(vector1,vector2),dim = c(3,3,2),dimnames = list(row.names,column.names,
                                                                      matrix.names))
    print(result[,,"Matrix1"])

    print(playWithArray(result))
}
