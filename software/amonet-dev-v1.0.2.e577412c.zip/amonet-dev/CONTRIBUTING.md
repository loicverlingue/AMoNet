Contribution guidelines
==============================

Coding style
------------------------------

This project follows the [SurgiQual Institute's coding style](https://projects.surgiqual-institute.com/projects/qualite-et-reglementations/wiki/5_C++).

Environment
------------------------------

This project uses Visual studio 2019.
