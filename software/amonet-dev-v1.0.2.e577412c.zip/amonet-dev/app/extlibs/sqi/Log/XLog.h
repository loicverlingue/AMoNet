#ifndef _XLog_
#define _XLog_

#include <QXmlStreamWriter>

#include "sqi/Log/BaseLog.h"
#include "sqi/Log/XFile.h"

namespace sqi
{
    //--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    namespace log
    //--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    {
        /****************************************************************************//**
        * \class XLogData
        * \brief Class for xlog handling, right above Qt level
        *
        * Normal use is via instance(); (and via sqi::xlog::open, msg, err, close)
        * Other uses should respect this :
        * Use XLogData() then open(existing_directory_name) then log(...) n times then close() then ~XLogData()
        ********************************************************************************/
        //---------------------------------------------------------------------------------------------------------------------------------------------------------
        class XLogData : public XFile
        //---------------------------------------------------------------------------------------------------------------------------------------------------------
        {
        public:
            //! constructs a static instance
            static XLogData* instance() ;

            //! constructor with uninitialized QFile & QXmlStreamWriter(&m_file) ; this way, when m_file is opened, m_stream operator << will append to this file.
            XLogData();
            /*!
            \brief Creates and open an xlog file.

            Sets m_file as p_path/Log20090306121651007 if date is March 6th 2009 and time is 12:16:51:007 & opens it in m_stream
            if p_path does not exist, create the corresponding directory.

            \note \b Path and \b FileName set using setFilePath or setLogFileName are used if no or empty \c p_path or
            \c p_fileName are given as parameter of this method.

            \param[in] p_path Path to locate the xlog file. To use default path ("."), \b either leave
                              the field empty if setFilePath() has not previously been called, \b or set the file path
                              to "." using XLogData::instance()->setFilePath("."), \b or reset file path to an empty string -- using
                              XLogData::instance()->setFilePath(QString()) -- to then leave the field empty.
            \param[in] p_fileName Name of the log file. To use default name, either leave the field empty, or if
                              setFileName has been previously called set it to an empty QString (using XLogData::instance()->setFileName(QString())).
            \returns false if opening failed or if m_file was already opened
            */
            bool open(const QString& p_path = ".", const QString& p_fileName = "");
            //! Close the xlog file on User control.
            void close();
            //! appends a formatted message to m_file
            void log(const QString& p_prefix, const QString& p_message, sqi::log::LogLevels p_logLevels = sqi::log::Default);
            //! \returns the file name of the current log (Null QString if empty or not set).
            const QString getFileName() const;
            //! \returns the file path of the current log (Null QString if empty or not set).
            const QString getFilePath() const;
            //! \returns the absolute path and file name of the current log file (Null QString if empty or not set).
            const QString getAbsoluteFilePath() const;
            /*!
            \brief Set the log file Name

            Log file name is set if log file is not already opened and if p_fileName is not empty

            \param[in] p_fileName Name of the log file.
            \returns true if log file name has been set, false otherwise
            */
            bool setFileName(const QString& p_fileName);
            /*!
            \brief Set the log file Path

            Log file path is set if log file is not already opened and if p_filePath is not empty

            \param[in] p_filePath Path to locate the log file.
            \returns true if log file path has been set, false otherwise
            */
            bool setFilePath(const QString& p_filePath);

            /*!
            \brief Let user set the log level policy for log entries.

            The p_logLevel in parameter will be used and will \b override any other custom
            logLevel used in existing log, msg or err entry.
            To reset changes, use resetLogLevels().<br> 

            \par Example:
            \code
            sqi::log::setLogLevels(sqi::log::ReleaseOnly);
            sqi::log::open("aDirectory");
            
            // further down in the code:
            sqi::log::msg("DEBUG message: In method m", sqi::log::DebugInConsole);
                // eventhough the previous message should only be displayed in the console in Debug mode,
                // since setLogLevels has been used, this message will be displayed in release (only) mode
                // in the console AND in the Log File.
            \endcode
            \param[in] p_logLevels Log level to be used on all log, msg or err entry.
            */
            void setLogLevels(sqi::log::LogLevels p_logLevels);
            /*!
            \brief Cancel any changes made while using setLogLevels()

            The custom log level used in log, msg or err will no longer be overriden by LogLevels
            set previously by the call to setLogLevels().
            */
            void resetLogLevels();

        protected:
            //! \returns QDateTime::currentDateTime();
            QDateTime now();



            QMutex           m_mutex;
            bool             m_userSpecifiedLogLevels;
            LogLevels        m_logLevels;

            QString          m_filePath;
            QString          m_fileName;
            int              m_currentFrame;
        };

    }
}

#endif // _XLog_
