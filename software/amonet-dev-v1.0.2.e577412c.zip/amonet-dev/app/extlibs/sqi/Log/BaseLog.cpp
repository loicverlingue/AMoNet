#include "sqi/Global/GeneralDefs.h"
#include "sqi/Log/BaseLog.h"
#include "sqi/Log/Log.h"
#include "sqi/Log/XLog.h"
#include "sqi/Global/NewMLP.h"

namespace sqi
{
    namespace log
    {

        LogErr LogErr::s_stream;
        LogMsg LogMsg::s_stream;
        BaseLog*  BaseLog::s_log = NULL;  

        //---------------------------------------------------------------------
        BaseLog* BaseLog::instance()
        //---------------------------------------------------------------------
        {
            if (s_log == NULL)
            {
                s_log = newMLP BaseLog();
            }
            return s_log;
        }


        //---------------------------------------------------------------------
        void BaseLog::resetInstance()
        //---------------------------------------------------------------------
        {
            sqi::delPtr(s_log);
        }


        //---------------------------------------------------------------------
        BaseLog::BaseLog() :
        //---------------------------------------------------------------------
                             m_useXlog(false),
                             m_logData(0),
                             m_xlogData(0)
        {
        }
        
        
        //---------------------------------------------------------------------
        BaseLog::~BaseLog()
        //---------------------------------------------------------------------
        {
            sqi::delPtr(m_xlogData);
            sqi::delPtr(m_logData);
        }


        //---------------------------------------------------------------------
        void BaseLog::checkXlogDataPtr()
        //---------------------------------------------------------------------
        {
            if (m_xlogData == 0)
            {
                m_xlogData = newMLP XLogData();
            }
        }


        //---------------------------------------------------------------------
        void BaseLog::checkLogDataPtr()
        //---------------------------------------------------------------------
        {
            if (m_logData == 0)
            {
                m_logData = newMLP LogData();
            }
        }


        //---------------------------------------------------------------------
        bool BaseLog::open(const QString& p_path, const QString& p_fileName)
        //---------------------------------------------------------------------
        {
            bool returnValue = false;

            // Call appropriate open method
            if (m_useXlog == true)
            {
                checkXlogDataPtr();
                returnValue = m_xlogData->open(p_path, p_fileName);
            }
            else
            {
                checkLogDataPtr();
                returnValue = m_logData->open(p_path, p_fileName);
            }

            return returnValue;
        }


        //---------------------------------------------------------------------
        void BaseLog::close()
        //---------------------------------------------------------------------
        {
            // Call appropriate close method
            if (m_useXlog == true && m_xlogData != NULL)
            {
                checkXlogDataPtr();
                m_xlogData->close();
            }
            else if (m_logData != NULL)
            {
                checkLogDataPtr();
                m_logData->close();
            }
        }


        //---------------------------------------------------------------------
        void BaseLog::log(const QString& p_prefix, const QString& p_message, sqi::log::LogLevels p_logLevels)
        //---------------------------------------------------------------------
        {
            // Call appropriate log method
            if (m_useXlog == true)
            {
                checkXlogDataPtr();
                m_xlogData->log(p_prefix, p_message, p_logLevels);
            }
            else
            {
                checkLogDataPtr();
                m_logData->log(p_prefix, p_message, p_logLevels);
            }
        }


        //---------------------------------------------------------------------
        void BaseLog::enableXlog()
        //---------------------------------------------------------------------
        {
            m_useXlog = true;
        }


        //---------------------------------------------------------------------
        void BaseLog::disableXlog()
        //---------------------------------------------------------------------
        {
            m_useXlog = false;
        }


        //---------------------------------------------------------------------
        const QString BaseLog::getFileName() 
        //---------------------------------------------------------------------
        {
            // Call appropriate getFileName method
            if (m_useXlog == true)
            {
                checkXlogDataPtr();
                return m_xlogData->getFileName();
            }
            else
            {
                checkLogDataPtr();
                return m_logData->getFileName();
            }
        }


        //---------------------------------------------------------------------
        const QString BaseLog::getFilePath() 
        //---------------------------------------------------------------------
        {
            // Call appropriate getFilePath method
            if (m_useXlog == true)
            {
                checkXlogDataPtr();
                return m_xlogData->getFilePath();
            }
            else
            {
                checkLogDataPtr();
                return m_logData->getFilePath();
            }
        }


        //---------------------------------------------------------------------
        const QString BaseLog::getAbsoluteFilePath() 
        //---------------------------------------------------------------------
        {
            // Call appropriate getAbsoluteFilePath method
            if (m_useXlog == true)
            {
                checkXlogDataPtr();
                return m_xlogData->getAbsoluteFilePath();
            }
            else
            {
                checkLogDataPtr();
                return m_logData->getAbsoluteFilePath();
            }
        }

        
        //---------------------------------------------------------------------
        bool BaseLog::setFileName(const QString& p_fileName)
        //---------------------------------------------------------------------
        {
            // Call appropriate setFileName method
            if (m_useXlog == true)
            {
                checkXlogDataPtr();
                return m_xlogData->setFileName(p_fileName);
            }
            else
            {
                checkLogDataPtr();
                return m_logData->setFileName(p_fileName);
            }
        }


        //---------------------------------------------------------------------
        bool BaseLog::setFilePath(const QString& p_filePath)
        //---------------------------------------------------------------------
        {
            // Call appropriate setFileName method
            if (m_useXlog == true)
            {
                checkXlogDataPtr();
                return m_xlogData->setFilePath(p_filePath);
            }
            else
            {
                checkLogDataPtr();
                return m_logData->setFilePath(p_filePath);
            }
        }


        //---------------------------------------------------------------------
        void BaseLog::setLogLevels(sqi::log::LogLevels p_logLevels)
        //---------------------------------------------------------------------
        {
            // Call appropriate setLogLevels method
            if (m_useXlog == true)
            {
                checkXlogDataPtr();
                m_xlogData->setLogLevels(p_logLevels);
            }
            else
            {
                checkLogDataPtr();
                m_logData->setLogLevels(p_logLevels);
            }
        }


        //---------------------------------------------------------------------
        void BaseLog::resetLogLevels()
        //---------------------------------------------------------------------
        {
            // Call appropriate resetLogLevels method
            if (m_useXlog == true)
            {
                checkXlogDataPtr();
                m_xlogData->resetLogLevels();
            }
            else
            {
                checkLogDataPtr();
                m_logData->resetLogLevels();
            }
        }


        //---------------------------------------------------------------------
        void BaseLog::enableFlushAllInRelease()
        //---------------------------------------------------------------------
        {
            // Only for LogData (not for XLogData).
            if (m_useXlog == false)
            {
                checkLogDataPtr();
                m_logData->enableFlushAllInRelease();
            }
        }


        //---------------------------------------------------------------------
        void BaseLog::disableFlushAllInRelease()
        //---------------------------------------------------------------------
        {
            // Only for LogData (not for XLogData).
            if (m_useXlog == false)
            {
                checkLogDataPtr();
                m_logData->disableFlushAllInRelease();
            }
        }









        //---------------------------------------------------------------------
        bool open(const QString& p_path, const QString& p_fileName)
        //---------------------------------------------------------------------
        {
            return(BaseLog::instance()->open(p_path, p_fileName));
        }

        //---------------------------------------------------------------------
        void close()
        //---------------------------------------------------------------------
        {
            BaseLog::instance()->close();
            BaseLog::resetInstance();
        }

        //---------------------------------------------------------------------
        void log(const QString& p_prefix, const QString& p_message, sqi::log::LogLevels p_logLevels)
        //---------------------------------------------------------------------
        {
            BaseLog::instance()->log(p_prefix, p_message, p_logLevels); 
        }

        //---------------------------------------------------------------------
        void msg(const QString&     p_message, sqi::log::LogLevels p_logLevels)
        //---------------------------------------------------------------------
        {
            log("MSG", p_message, p_logLevels); 
        }

        //---------------------------------------------------------------------
        void err(const QString&     p_message, sqi::log::LogLevels p_logLevels)
        //---------------------------------------------------------------------
        {
            log("ERR", p_message, p_logLevels); 
        }

        //---------------------------------------------------------------------
        void msg(const std::string& p_message, sqi::log::LogLevels p_logLevels) 
        //---------------------------------------------------------------------
        {
            msg(QString::fromStdString(p_message),p_logLevels);  
        }

        //---------------------------------------------------------------------
        void err(const std::string& p_message, sqi::log::LogLevels p_logLevels)
        //---------------------------------------------------------------------
        {
            err(QString::fromStdString(p_message),p_logLevels);  
        }

        //---------------------------------------------------------------------
        void msg(const char*        p_message, sqi::log::LogLevels p_logLevels)
        //---------------------------------------------------------------------
        {
            msg(QString(p_message),p_logLevels);  
        }

        //---------------------------------------------------------------------
        void err(const char*        p_message, sqi::log::LogLevels p_logLevels)
        //---------------------------------------------------------------------
        {
            err(QString(p_message),p_logLevels);  
        }

        //---------------------------------------------------------------------
        bool setFileName(const QString& p_fileName)
        //---------------------------------------------------------------------
        {
            return BaseLog::instance()->setFileName(p_fileName); 
        }

        //---------------------------------------------------------------------
        bool setFilePath(const QString& p_filePath) 
        //---------------------------------------------------------------------
        {
            return BaseLog::instance()->setFilePath(p_filePath); 
        }

        //---------------------------------------------------------------------
        const QString getAbsoluteFilePath()
        //---------------------------------------------------------------------
        {
            return BaseLog::instance()->getAbsoluteFilePath(); 
        }

        //---------------------------------------------------------------------
        const QString getFileName() 
        //---------------------------------------------------------------------
        {
            return BaseLog::instance()->getFileName(); 
        }

        //---------------------------------------------------------------------
        const QString getFilePath()
        //---------------------------------------------------------------------
        {
            return BaseLog::instance()->getFilePath(); 
        }

        //---------------------------------------------------------------------
        void enableXlog() 
        //---------------------------------------------------------------------
        {
            BaseLog::instance()->enableXlog() ; 
        }

        //---------------------------------------------------------------------
        void disableXlog()
        //---------------------------------------------------------------------
        {
            BaseLog::instance()->disableXlog();
        }

        //---------------------------------------------------------------------
        void setLogLevels(sqi::log::LogLevels p_logLevels)
        //---------------------------------------------------------------------
        {
            BaseLog::instance()->setLogLevels(p_logLevels);
        }

        //---------------------------------------------------------------------
        void resetLogLevels()
        //---------------------------------------------------------------------
        {
            BaseLog::instance()->resetLogLevels();
        }

        //---------------------------------------------------------------------
        void enableFlushAllInRelease()
        //---------------------------------------------------------------------
        {
            BaseLog::instance()->enableFlushAllInRelease();
        }

        //---------------------------------------------------------------------
        void disableFlushAllInRelease()
        //---------------------------------------------------------------------
        {
            BaseLog::instance()->disableFlushAllInRelease();
        }

    };
};
