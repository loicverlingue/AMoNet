#include <QDir>

#include "sqi/Log/Log.h"


namespace sqi
{
    namespace log
    {

        //---------------------------------------------------------------------
        LogData* LogData::instance()
        //---------------------------------------------------------------------
        {
            static LogData s_log;
            return &s_log;
        }


        //---------------------------------------------------------------------
        LogData::LogData() :
        //---------------------------------------------------------------------
              m_userSpecifiedLogLevels(false),
              m_logLevels(sqi::log::Default),
              m_stream(&m_file),
              m_filePath(QString()),
              m_fileName(QString()),
              m_flushAllInRelease(false)
        {
        }


        //---------------------------------------------------------------------
        QDateTime LogData::now()
        //---------------------------------------------------------------------
        {
            return QDateTime::currentDateTime();
        }


        //---------------------------------------------------------------------
        bool LogData::open(const QString& p_path, const QString& p_fileName)
        //---------------------------------------------------------------------
        {
            // Add this first test now that log file can be opened whenever the user wants to.
            if (m_file.isOpen() == true)
                return false;

            if (p_path.isEmpty() == true || p_path == ".") // "." is the default value
            {
                if (m_filePath.isEmpty() == true)
                {
                    // Value forced by user to 'empty' in order to use default value
                    m_filePath = ".";
                }
                // else
                   //use current m_logFilePath
            }
            else
                m_filePath = p_path;

            // check if directory exists
            QDir dir;
            QString logPath(m_filePath);
            if (dir.exists(logPath)==false)
                dir.mkdir(logPath);



            if (p_fileName.isEmpty() == true)
            {
                if (m_fileName.isEmpty() == true)
                {
                    // Use default value "date_and_time specific format
                    m_fileName = "Log" + now().toString("yyyyMMddhhmmsszzz");
                }
                //else
                   // use current m_logFileName
            }
            else
                m_fileName = p_fileName;



            bool l_res = false;
            {
                QMutexLocker mutexLocker(&m_mutex);
                m_file.setFileName( m_filePath + "/" + m_fileName );
                l_res=m_file.open(QIODevice::WriteOnly | QIODevice::Text);
            }

            log(QString("MSG"), QString("OPEN"));
#ifndef NDEBUG
            log(QString("MSG"), QString("MODE DEBUG"));
#endif
            return (l_res);
        }


        //---------------------------------------------------------------------
        void LogData::close()
        //---------------------------------------------------------------------
        {
            log("MSG","CLOSE");

            if (m_file.isOpen() == true)
            {
                QMutexLocker mutexLocker(&m_mutex);
                m_file.close();
            }
        }


        //---------------------------------------------------------------------
        void LogData::log(const QString& p_prefix, const QString& p_message, sqi::log::LogLevels p_logLevels)
        //---------------------------------------------------------------------
        {
            LogLevels logLevels;
            if (m_userSpecifiedLogLevels == true)
            {
                logLevels = m_logLevels;
            }
            else
            {
                logLevels = p_logLevels;
            }

            QMutexLocker mutexLocker(&m_mutex);
            QString strDateTime = now().toString("yyyy.MM.dd-hh:mm:ss.zzz");
            std::stringstream output(std::stringstream::out);
            output << p_prefix.toStdString() << " " << strDateTime.toStdString() << " | " << p_message.toStdString() << std::endl;


            // >>>>>>>>>> Fix the issue #369
#ifndef NDEBUG
            if (logLevels.testFlag(sqi::log::DebugInLogFile) == true
#else
            if (logLevels.testFlag(sqi::log::ReleaseInLogFile) == true
#endif      // <<<<<<<<<< end of fix the issue #369
                &&
                m_file.isOpen() == true)
            {
                m_stream << output.str().c_str();

#ifdef NDEBUG
                // since flush implies significative performance loss, in release mode, flush only log::err
                if (p_prefix == "ERR" || m_flushAllInRelease == true)
#endif
                    m_stream.flush();
            }

#ifndef NDEBUG
            if (logLevels.testFlag(sqi::log::DebugInConsole) == true)
#else
            if (logLevels.testFlag(sqi::log::ReleaseInConsole) == true)
#endif
                std::cerr << output.str();
        }


        //---------------------------------------------------------------------
        const QString LogData::getFileName() const
        //---------------------------------------------------------------------
        {
            return m_fileName;
        }


        //---------------------------------------------------------------------
        const QString LogData::getFilePath() const
        //---------------------------------------------------------------------
        {
            return m_filePath;
        }


        //---------------------------------------------------------------------
        const QString LogData::getAbsoluteFilePath() const
        //---------------------------------------------------------------------
        {
            QFileInfo logFileInfo(m_file);
            return logFileInfo.absoluteFilePath();;
        }


        //---------------------------------------------------------------------
        bool LogData::setFileName(const QString& p_fileName)
        //---------------------------------------------------------------------
        {
            if (m_file.isOpen() == true)
                return false;

            m_fileName = p_fileName;
            return true;
        }


        //---------------------------------------------------------------------
        bool LogData::setFilePath(const QString& p_filePath)
        //---------------------------------------------------------------------
        {
            if (m_file.isOpen() == true)
                return false;

            m_filePath = p_filePath;
            return true;
        }


        //---------------------------------------------------------------------
        const QString LogData::getLogFileName()
        //---------------------------------------------------------------------
        {
            return getFileName();
        }


        //---------------------------------------------------------------------
        void LogData::setLogLevels(sqi::log::LogLevels p_logLevels)
        //---------------------------------------------------------------------
        {
            m_userSpecifiedLogLevels = true;
            m_logLevels = p_logLevels;
        }


        //---------------------------------------------------------------------
        void LogData::resetLogLevels()
        //---------------------------------------------------------------------
        {
            m_userSpecifiedLogLevels = false;
            m_logLevels = sqi::log::Default;
        }


        //---------------------------------------------------------------------
        void LogData::enableFlushAllInRelease()
        //---------------------------------------------------------------------
        {
            m_flushAllInRelease = true;
        }


        //---------------------------------------------------------------------
        void LogData::disableFlushAllInRelease()
        //---------------------------------------------------------------------
        {
            m_flushAllInRelease = false;
        }
    };

};
