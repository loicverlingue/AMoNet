#include "sqi/Log/XFile.h"
#include <iostream>
#include <QTextCodec>
#include "sqi/Global/NewMLP.h"


namespace sqi
{
    namespace log
    {



        static QString encodeText(const QString &str,
                                  QTextStream &s,
                                  const bool encodeQuotes = true,
                                  const bool performAVN = false,
                                  const bool encodeEOLs = false);



        //-----------------------------------------------------------------------------
        XFile::XFileElt::XFileElt(QDomDocument& p_doc, const QString& p_name,QTextStream& p_stream)
        //-----------------------------------------------------------------------------
        :m_factory(p_doc),m_posInStream(-1),m_docStream(p_stream)
        {
            m_xmlElement = m_factory.createElement(p_name);
        }


        //-----------------------------------------------------------------------------
        void XFile::XFileElt::begin(int indent,int depth, bool p_quickMode)
        //-----------------------------------------------------------------------------
        {
            if ( !p_quickMode )
            {
                m_docStream.flush();
                //save the current position
                m_posInStream = m_docStream.pos();
            }
            for ( int i = 0; i < indent * depth; i++ )
                m_docStream << " ";

            //write the element
            m_docStream << QLatin1Char('<') << m_xmlElement.tagName();

            //write all attributes
            const QDomNamedNodeMap& map = m_xmlElement.attributes();
            if (!map.isEmpty()) 
            {
                for (int i = 0; i < map.count(); ++i) 
                {
                    m_docStream << ' ';
                    m_docStream << map.item(i).toAttr().name() << "=\"" << encodeText(map.item(i).toAttr().value(),m_docStream, true, true) << "\"";

                }
            }

            //if there is already some child nodes : close the opening balise
            if ( m_xmlElement.hasChildNodes() )
                m_docStream << QLatin1Char('>');

            if ( !p_quickMode )
            {
                m_docStream.flush();
                m_insertionPos = m_docStream.pos();
            }
        }


        //-----------------------------------------------------------------------------
        void XFile::XFileElt::close(int indent,int depth, bool p_quickMode)
        //-----------------------------------------------------------------------------
        {
            if ( !m_xmlElement.hasChildNodes() )
                //if no child nodes => close immediately "/>"
                m_docStream << '/' << '>';
            else if ( m_xmlElement.lastChild().isText() )
                //if last child element is text =>close on current line 
                m_docStream << '<' << '/' << m_xmlElement.tagName() << '>';
            else if ( m_xmlElement.lastChild().isComment() )
            {
                //if last child is a comment
               for ( int i = 0; i < indent * depth; i++ )
                   m_docStream << ' ';
               m_docStream << '<' << '/' << m_xmlElement.tagName() << '>';
            }
            else 
            {
               //else : last child is an element : go to line an indent before writing the closing balise
               m_docStream << endl;
               for ( int i = 0; i < indent * depth; i++ )
                   m_docStream << ' ';
               m_docStream << '<' << '/' << m_xmlElement.tagName() << '>';
               
            }
            if ( !p_quickMode )
            {
                m_docStream.flush();
                m_closePos = m_docStream.pos();
            }
        }


        //-----------------------------------------------------------------------------
        bool XFile::XFileElt::update(int indent,int depth)
        //-----------------------------------------------------------------------------
        {
            //go to the beginning of current element
            if ( m_posInStream < 0 )
                return false;
            m_docStream.seek(m_posInStream);

            //launch update
            protectedUpdate(indent,depth);
            return true;
        }


        //-----------------------------------------------------------------------------
        void XFile::XFileElt::protectedUpdate(int indent, int depth)
        //-----------------------------------------------------------------------------
        {
            //begin element
            begin(indent,depth);
            m_docStream.flush(); //debug purpose

            QList<XFileElt*>::iterator it = m_children.begin();
            QList<XFileElt*>::iterator itend = m_children.end();
            bool prevWasText = false;
            //for all children
            for ( int i = 0; i < m_xmlElement.childNodes().count(); i++ )
            {
                if ( m_xmlElement.childNodes().at(i).isElement() )
                {
                    //if it's an element
                    if ( it == itend )
                        std::cerr << "FATAL ERROR" << std::endl;

                    //if the prev node was not a text => go to line
                    if ( !prevWasText )
                        m_docStream << endl;

                    //!write the corresponding XFileElt (depth +1 to indent correctly)
                    (*it)->protectedUpdate(indent,depth+1);
                    it++;
                    prevWasText = false;
                }
                else
                {

                    const QDomNode& node = m_xmlElement.childNodes().at(i);
                    if ( node.isText() )
                    {
                        //if it's a text node => save it and update flag 
                        m_xmlElement.childNodes().at(i). save(m_docStream,(depth+1)*indent);
                        prevWasText = true;
                    }
                    else              
                    {
                        //if it's not a text node (comment or CData)
                        if ( !prevWasText )
                        {
                            m_docStream << endl;
                            m_xmlElement.childNodes().at(i). save(m_docStream,(depth+1)*indent);
                        }
                        else
                            m_xmlElement.childNodes().at(i).save(m_docStream,0);

                        //update flag
                        prevWasText = false;
                    }
                       
                }
            }

            m_docStream.flush();
            m_insertionPos = m_docStream.pos();
            close(indent,depth);
        }


        //-----------------------------------------------------------------------------
        void XFile::XFileElt::appendChild(XFileElt* p_child)
        //-----------------------------------------------------------------------------
        {
            if ( !m_xmlElement.hasChildNodes() )
            {        
                //if first child node => close the opening balise (replace /> by >)
                m_docStream << QLatin1Char('>') << endl;
            }
            else if ( m_xmlElement.lastChild().isElement() )
            {
                m_docStream << endl;
            }
            m_docStream.flush();
            m_insertionPos = m_docStream.pos();
            m_xmlElement.appendChild(p_child->element());
            m_children.append(p_child);
        }


        //-----------------------------------------------------------------------------
        void XFile::XFileElt::insertText(const QString &p_text, bool p_quickMode)
        //-----------------------------------------------------------------------------
        {
            if ( !m_xmlElement.hasChildNodes() )
            {
                //if first child node => close the opening balise (replace /> by >)
                m_docStream << QLatin1Char('>');
            }
            QDomText txt = m_factory.createTextNode(p_text);
            m_xmlElement.appendChild(txt);
            txt.save(m_docStream,-1);
            if ( !p_quickMode )
                m_docStream.flush();
                m_insertionPos = m_docStream.pos();
        }


        //-----------------------------------------------------------------------------
        void XFile::XFileElt::insertComment(const QString &p_text, int p_indent, int p_depth, bool p_quickMode)
        //-----------------------------------------------------------------------------
        {
            if ( !m_xmlElement.hasChildNodes() )
            {
                //if first child node => close the opening balise (replace /> by >)
                m_docStream << QLatin1Char('>');
            }
            if ( m_xmlElement.lastChild().isElement() )
            {
                //if last child was not text => go to line and indent
                m_docStream << endl;
                for ( int i = 0; i < p_indent * ( p_depth + 1); i++ )
                    m_docStream << ' ';
            }

            
            QDomComment txt = m_factory.createComment(p_text);
            m_xmlElement.appendChild(txt);
            txt.save(m_docStream,-1);
            if ( !p_quickMode )
            {
                m_docStream.flush();
                m_insertionPos = m_docStream.pos();
            }
        }


        //-----------------------------------------------------------------------------
        void XFile::XFileElt::insertCData(const QString &p_text, int p_indent, int p_depth, bool p_quickMode)
        //-----------------------------------------------------------------------------
        {
            if ( !m_xmlElement.hasChildNodes() )
            {
                //if first child node => close the opening balise (replace /> by >)
                m_docStream << QLatin1Char('>');
            }
            if ( m_xmlElement.lastChild().isElement() )
            {
                //if last child was not text => go to line and indent
                m_docStream << endl;
                for ( int i = 0; i < p_indent * ( p_depth + 1); i++ )
                    m_docStream << ' ';
            }
            else if ( m_xmlElement.lastChild().isComment() )
            {
                for ( int i = 0; i < p_indent * ( p_depth ); i++ )
                    m_docStream << ' ';
            }


            QDomCDATASection txt = m_factory.createCDATASection(p_text);
            m_xmlElement.appendChild(txt);
            txt.save(m_docStream,-1);
            if ( !p_quickMode )
            {
                m_docStream.flush();
                m_insertionPos = m_docStream.pos();
            }
        }



        //-----------------------------------------------------------------------------
        XFile::XFile(const QString& p_docType /*= "XFile"*/,int indent /*= 4*/)
        //-----------------------------------------------------------------------------
                    : m_doc(p_docType),
                      m_indent(indent),
                      m_quickMode(false),
                      m_numberOfQuickModeAsked(0)
        {
        }


        //-----------------------------------------------------------------------------
        QDomDocument XFile::getCloneDom()
        //-----------------------------------------------------------------------------
        {
            return m_doc.cloneNode().toDocument();
        }


        //-----------------------------------------------------------------------------
        void XFile::startElement(const QString& p_name)
        //-----------------------------------------------------------------------------
        {
            if ( !isOpen() )
                return;
            XFileElt* xElt = newMLP XFileElt(m_doc,p_name,m_stream);
            bool lastElementIsText = false;
           
            if ( !m_currents.empty() )
            {
                lastElementIsText = m_currents.top()->element().lastChild().isText();
                m_currents.top()->appendChild(xElt);
            }
            else 
                m_doc.appendChild(xElt->element());

            m_currents.push(xElt);
            
            if ( !m_quickMode )
            {
                xElt->begin((!lastElementIsText)?m_indent:0,m_currents.count()-1);
                closeCurrents();
            }
            else
            {
                xElt->begin((!lastElementIsText)?m_indent:0,m_currents.count()-1,true);
            }
        }


        //-----------------------------------------------------------------------------
        void XFile::startElement(const QString& p_name, const Attribute& p_attribute )
        //-----------------------------------------------------------------------------
        {
            if ( !isOpen() )
                return;
            XFileElt* xElt = newMLP XFileElt(m_doc,p_name,m_stream);
            bool lastElementIsText = false;
            if ( !m_currents.empty() )
            {
                lastElementIsText = m_currents.top()->element().lastChild().isText();
                m_currents.top()->appendChild(xElt);
            }
            else 
                m_doc.appendChild(xElt->element());

            m_currents.push(xElt);    
            xElt->element().setAttribute(p_attribute.first,p_attribute.second);

            if ( !m_quickMode )
            {
                xElt->begin((!lastElementIsText)?m_indent:0,m_currents.count()-1);
                closeCurrents();
            }
            else
            {
                xElt->begin((!lastElementIsText)?m_indent:0,m_currents.count()-1,true);
            }
        }


        //-----------------------------------------------------------------------------
        void XFile::startElement(const QString& p_name, const AttributesList& p_attributesList )
        //-----------------------------------------------------------------------------
        {
            if ( !isOpen() )
                return;
            XFileElt* xElt = newMLP XFileElt(m_doc,p_name,m_stream);
            bool lastElementIsText = false;
            if ( !m_currents.empty() )
            {
                lastElementIsText = m_currents.top()->element().lastChild().isText();
                m_currents.top()->appendChild(xElt);
            }
            else 
                m_doc.appendChild(xElt->element());

            m_currents.push(xElt);
            AttributesList::const_iterator it, itend = p_attributesList.constEnd();
            for ( it = p_attributesList.constBegin(); it != itend; ++it )
            {
                xElt->element().setAttribute((*it).first,(*it).second);
            }

            if ( !m_quickMode )
            {
                xElt->begin((!lastElementIsText)?m_indent:0,m_currents.count()-1);        
                closeCurrents(); 
            }
            else
            {
                xElt->begin((!lastElementIsText)?m_indent:0,m_currents.count()-1,true);
            }
        }


        //-----------------------------------------------------------------------------
        void XFile::endElement()
        //-----------------------------------------------------------------------------
        {
            if ( !isOpen() )
                return;
            qint64 newInsertionPos = 0;
            if ( !m_quickMode )
            {
                newInsertionPos = m_currents.top()->closePos();
                m_stream.seek(newInsertionPos); 
            }
            else
            {
                m_currents.top()->close(m_indent,m_currents.count()-1,true);
            }
            
            XFileElt* xElt = m_currents.pop();
            delete xElt;
            if ( m_currents.isEmpty() )//new root element? => should not happen in our cases
                m_stream << endl;
            else if ( !m_quickMode ) 
                //go to line to begin the new root.
                m_currents.top()->setInsertionPos(newInsertionPos);
        }


        //-----------------------------------------------------------------------------
        void XFile::endAllElementsExceptRoot()
        //-----------------------------------------------------------------------------
        {
            while ( m_currents.count() > 1 )
            {
                endElement();
            }
        }


        //-----------------------------------------------------------------------------
        void XFile::closeCurrents()
        //-----------------------------------------------------------------------------
        {
            if ( !isOpen() )
                return;
            //close all current elements
            QStack<XFileElt*> cpy = m_currents;
            while ( !cpy.isEmpty() )
            {
                cpy.top()->close(m_indent,cpy.count()-1);
                cpy.pop();
            }
            endWrite();
        }


        //-----------------------------------------------------------------------------
        void XFile::closeCurrentsExceptTop()
        //-----------------------------------------------------------------------------
        {
            if ( !isOpen() )
                return;
            QStack<XFileElt*> cpy = m_currents;
            cpy.pop(); //do not close the top element
            while ( !cpy.isEmpty() )
            {
                cpy.top()->close(m_indent,cpy.count()-1);
                cpy.pop();
            }
            endWrite();
        }


        //-----------------------------------------------------------------------------
        void XFile::writeAttribute(const QString& p_name, const QString& p_value)
        //-----------------------------------------------------------------------------
        {
            if ( !isOpen() )
                return;

            XFileElt* top = m_currents.top();
            if ( !m_quickMode )
            {
                top->element().setAttribute(p_name,p_value);
                top->update(m_indent,m_currents.count()-1); //could be very long
                closeCurrentsExceptTop();
            }
            else
            {
                if ( top->element().hasChildNodes() )
                    return;
                
                top->element().setAttribute(p_name,p_value);
                m_stream << ' ';
                m_stream << p_name << "=\"" << encodeText(p_value,m_stream, true, true) << "\"";

                //TODO
                //m_currents.top()->quickWriteAttribute(p_name, p_value); 
            }
        }


        //-----------------------------------------------------------------------------
        void XFile::writeAttributes(const XFile::AttributesList& p_attributesList)
        //-----------------------------------------------------------------------------
        {
            if ( !isOpen() )
                return;
            XFileElt* elt = m_currents.top();
            if ( !m_quickMode )
            {
                AttributesList::const_iterator it, itend = p_attributesList.constEnd();
                for ( it = p_attributesList.constBegin(); it != itend; ++it )
                {
                    elt->element().setAttribute((*it).first,(*it).second);
                }
                m_currents.top()->update(m_indent,m_currents.count()-1);
                closeCurrentsExceptTop();
            }
            else
            {
                if ( elt->element().hasChildNodes() )
                    return;

                AttributesList::const_iterator it, itend = p_attributesList.constEnd();
                for ( it = p_attributesList.constBegin(); it != itend; ++it )
                {
                    QString name((*it).first);
                    QString value((*it).second);
                    elt->element().setAttribute(name,value);
                    m_stream << ' ';
                    m_stream << name << "=\"" << encodeText(value,m_stream, true, true) << "\"";
                }

            }
            

        }


        //-----------------------------------------------------------------------------
        void XFile::writeText(const QString& p_text)
        //-----------------------------------------------------------------------------
        {
            if ( !isOpen() )
                return;
            if ( !m_quickMode )
            {
                m_currents.top()->insertText(p_text);
                closeCurrents();
            }
            else
                m_currents.top()->insertText(p_text,true);
        }


        //-----------------------------------------------------------------------------
        void XFile::writeTextElement(const QString& p_name, const QString& p_text)
        //-----------------------------------------------------------------------------
        {
            startElement(p_name);
            writeText(p_text);
            endElement();
        }


        //-----------------------------------------------------------------------------
        void XFile::writeComment(const QString& p_text)
        //-----------------------------------------------------------------------------
        {
            if ( !isOpen() )
                return;
            
            if ( !m_quickMode )
            {
                m_currents.top()->insertComment(p_text,m_indent, m_currents.count() -1);
                closeCurrents();
            }
            else
                m_currents.top()->insertComment(p_text,m_indent, m_currents.count() -1,true);
        }


        //-----------------------------------------------------------------------------
        void XFile::writeCData(const QString& p_text)
        //-----------------------------------------------------------------------------
        {
            if ( !isOpen() )
                return;

            if ( !m_quickMode )
            {
                m_currents.top()->insertCData(p_text,m_indent, m_currents.count() -1);
                closeCurrents();
            }
            else
                m_currents.top()->insertCData(p_text,m_indent, m_currents.count() -1,true);
        }


        //-----------------------------------------------------------------------------
        void XFile::activateQuickMode()
        //-----------------------------------------------------------------------------
        {
            if ( isOpen() )
            {
                m_quickMode = true;
                m_numberOfQuickModeAsked++;
            }
        }


        //-----------------------------------------------------------------------------
        void XFile::desactivateQuickMode()
        //-----------------------------------------------------------------------------
        {
            if ( m_quickMode )
            {
                m_numberOfQuickModeAsked--;
                if ( m_numberOfQuickModeAsked == 0)
                {
                    m_quickMode = false;
                    m_stream.flush();
                    qint64 newInsertionPos = m_stream.pos();
                    if ( !m_currents.isEmpty() )
                        m_currents.top()->setInsertionPos(newInsertionPos);
                    closeCurrents();
                }
            }
        }


        //-----------------------------------------------------------------------------
        bool XFile::open(const QString& p_fileName)
        //-----------------------------------------------------------------------------
        {
            //if ( isOpen() )
            //    return false;
            m_file.setFileName(p_fileName);
            if ( !m_file.open(QIODevice::WriteOnly) )
            {
                std::cerr << "cannot open file : " << p_fileName.toStdString() << std::endl;
                return false;
            }
            
            m_stream.reset();
            
            m_stream.setDevice(&m_file);
            m_stream.setCodec("ISO 8859-1");
            QDomProcessingInstruction processingInstruction = m_doc.createProcessingInstruction( "xml", "version=\"1.0\" encoding=\"ISO-8859-1\"");
            m_doc.appendChild(
                processingInstruction
            );

            processingInstruction.save(m_stream,m_indent);
            m_doc.doctype().save(m_stream,m_indent);

            return true;
        }


        //-----------------------------------------------------------------------------
        void XFile::close()
        //-----------------------------------------------------------------------------
        {
            if ( !isOpen() )
                return;
            m_file.close();
        }


        //-----------------------------------------------------------------------------
        void XFile::endWrite()
        //-----------------------------------------------------------------------------
        {
            m_stream << endl;
            m_stream.flush();
            while ( !m_stream.atEnd() )
            {
                m_stream << ' ';
                m_stream.flush();
            }
            m_stream.seek(m_currents.top()->insertionPos());

        }


        //-----------------------------------------------------------------------------
        bool XFile::saveDomAs(const QString& p_fileName)
        //-----------------------------------------------------------------------------
        {
            QFile file(p_fileName);
            if ( !file.open(QIODevice::WriteOnly) )
                return false;

            QTextStream stream(&file);
            m_doc.save(stream,m_indent);
            return true;
        }


        //-----------------------------------------------------------------------------
        bool XFile::setIndent(int p_indent)
        //-----------------------------------------------------------------------------
        {
            if ( isOpen() || p_indent < 0)
                return false;
            m_indent = p_indent;
            return true;
        }


        //copy of Qt function
        //-----------------------------------------------------------------------------
        static QString encodeText(const QString &str,
                                  QTextStream &s,
                                  const bool encodeQuotes /*= true*/,
                                  const bool performAVN /*= false*/,
                                  const bool encodeEOLs/* = false*/)
        //-----------------------------------------------------------------------------
        {
        #ifdef QT_NO_TEXTCODEC
            Q_UNUSED(s);
        #else
            const QTextCodec *const codec = s.codec();
            Q_ASSERT(codec);
        #endif
            QString retval(str);
            int len = retval.length();
            int i = 0;

            while (i < len) {
                const QChar ati(retval.at(i));

                if (ati == QLatin1Char('<')) {
                    retval.replace(i, 1, QLatin1String("&lt;"));
                    len += 3;
                    i += 4;
                } else if (encodeQuotes && (ati == QLatin1Char('"'))) {
                    retval.replace(i, 1, QLatin1String("&quot;"));
                    len += 5;
                    i += 6;
                } else if (ati == QLatin1Char('&')) {
                    retval.replace(i, 1, QLatin1String("&amp;"));
                    len += 4;
                    i += 5;
                } else if (ati == QLatin1Char('>') && i >= 2 && retval[i - 1] == QLatin1Char(']') && retval[i - 2] == QLatin1Char(']')) {
                    retval.replace(i, 1, QLatin1String("&gt;"));
                    len += 3;
                    i += 4;
                } else if (performAVN &&
                           (ati == QChar(0xA) ||
                            ati == QChar(0xD) ||
                            ati == QChar(0x9))) {
                    const QString replacement(QLatin1String("&#x") + QString::number(ati.unicode(), 16) + QLatin1Char(';'));
                    retval.replace(i, 1, replacement);
                    i += replacement.length();
                    len += replacement.length() - 1;
                } else if (encodeEOLs && ati == QChar(0xD)) {
                    retval.replace(i, 1, QLatin1String("&#xd;")); // Replace a single 0xD with a ref for 0xD
                    len += 4;
                    i += 5;
                } else {
        #ifndef QT_NO_TEXTCODEC
                    if(codec->canEncode(ati))
                        ++i;
                    else
        #endif
                    {
                        // We have to use a character reference to get it through.
                        const ushort codepoint(ati.unicode());
                        const QString replacement(QLatin1String("&#x") + QString::number(codepoint, 16) + QLatin1Char(';'));
                        retval.replace(i, 1, replacement);
                        i += replacement.length();
                        len += replacement.length() - 1;
                    }
                }
            }

            return retval;
        }

    };
};
