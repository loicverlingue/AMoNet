#ifndef _BaseLog_
#define _BaseLog_

#include <QDateTime>
#include <QFile>
#include <QMutex>


namespace sqi
{
    //--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    namespace log
    //--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    {
        class LogData;
        class XLogData;

        /*!
        \brief This enum describes the levels available on a log.

        This enum is also implemented through QFlags: Q_DECLARE_FLAGS(LogLevels, LogLevel).
        Log levels can therefore be combined using the bitwise \c OR operator (use of \b sqi::log::LogLevels).
        
        \par Examples
        In the following code excerpt, the log "A message" will appear in the console in Debug AND Release mode, and
        will appear in the generated log file in Release mode ONLY.
        \code
        sqi::log::msg("A message", sqi::log::ReleaseOnly | sqi::log::DebugInConsole);
        // another usage:
        sqi::log::msg("Another message", sqi::log::DebugInLogFile);
        \endcode

        \note
        To have the same policy for any log of the application, e.g. temporarily display all logs in the console
        in Release mode: please use setLogLevels().
        */
        enum LogLevel {
            NoLog                  = 0x00, //!< Do not display anything anywhere.
            DebugInConsole         = 0x01, //!< Only display log in the console in Debug mode.
            DebugInLogFile         = 0x02, //!< Only display log in the Log File in Debug mode.
            ReleaseInConsole       = 0x04, //!< Only display log in the console in Release mode.
            ReleaseInLogFile       = 0x08, //!< Only display log in the Log File in Release mode.
            Default                = LogLevel::DebugInConsole | LogLevel::DebugInLogFile | ReleaseInLogFile, //!< Default: Log appears in console in Debug mode only, and appears in the Log Files in Debug AND Release modes.
            DebugOnly              = DebugInConsole | DebugInLogFile,     //!< Display log in console and in Log File in Debug mode only.
            ReleaseOnly            = ReleaseInConsole | ReleaseInLogFile, //!< Display log in console and in Log File in Release mode only.
            ConsoleOnly            = DebugInConsole | ReleaseInConsole,   //!< Display log in console only (debug and release modes).
            LogFileOnly            = DebugInLogFile | ReleaseInLogFile,   //!< Display log in Log File only (debug and release modes).
            LogAll                 = DebugOnly | ReleaseOnly              //!< Display log in all circumstances.
        };
        Q_DECLARE_FLAGS(LogLevels, LogLevel)
        Q_DECLARE_OPERATORS_FOR_FLAGS(LogLevels)

        /****************************************************************************//**
        * \class BaseLog
        * \brief Class for log handling, right above Qt level
        *
        * This class should \b NOT be explicitly instanciated. A 'base' singleton will be created
        * when 'generic' method will be called such as open, close, log.
        ********************************************************************************/
        class BaseLog
        {
        public:
            //! constructs a static instance
            static BaseLog* instance() ;
            //! reset the static instance
            static void resetInstance() ;
            virtual ~BaseLog();

            //! Call appropriate object when this function is called through the \em generic sqi::log::open
            virtual bool open(const QString& p_path = ".", const QString& p_fileName = "");
            //! Call appropriate object when this function is called through the \em generic sqi::log::close
            virtual void close();
            //! Call appropriate object when this function is called through the \em generic sqi::log::log
            virtual void log(const QString& p_prefix, const QString& p_message, sqi::log::LogLevels p_logLevels);
            //! Call appropriate object when this function is called through the \em generic sqi::log::setLogLevels
            virtual void setLogLevels(sqi::log::LogLevels p_logLevels);
            //! Call appropriate object when this function is called through the \em generic sqi::log::resetLogLevels 
            virtual void resetLogLevels();

            //! \returns the file name of the current log (Null QString if empty or not set).
            const QString getFileName() ;
            //! \returns the file path of the current log (Null QString if empty or not set).
            const QString getFilePath() ;
            //! \returns the absolute path and file name of the current log file (Null QString if empty or not set).
            const QString getAbsoluteFilePath() ;
            //! Call the appropriate LogData object when this function is called through the \em generic sqi::log::enableFlushAllInRelease 
            void enableFlushAllInRelease();
            //! Call the appropriate LogData object when this function is called through the \em generic sqi::log::disableFlushAllInRelease 
            void disableFlushAllInRelease();
            /*!
            \brief Set the log file Name

            Log file name is set if log file is not already opened and if p_fileName is not empty

            \param[in] p_fileName Name of the log file.
            \returns true if log file name has been set, false otherwise
            */
            bool setFileName(const QString& p_fileName);
            /*!
            \brief Set the log file Path

            Log file path is set if log file is not already opened and if p_filePath is not empty

            \param[in] p_filePath Path to locate the log file.
            \returns true if log file path has been set, false otherwise
            */
            bool setFilePath(const QString& p_filePath);

            //! Set m_useXlog to true
            void enableXlog();
            //! Set m_useXlog to false
            void disableXlog();

        private:
            static BaseLog* s_log; 
            void checkXlogDataPtr();
            void checkLogDataPtr();

        protected:
            //! Protected ctor due to singleton implementation
            BaseLog();



            bool           m_useXlog;
            LogData *      m_logData;
            XLogData *     m_xlogData;
        };



//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//      Common functionalities accessible directly through sqi::log namespace
//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------




        /*!
            \brief Creates and open a log file.

            Sets m_file as p_path/Log20090306121651007 if date is March 6th 2009 and time is 12:16:51:007 & opens it in m_stream
            if p_path does not exist, create the corresponding directory.

            \note \b Path and \b FileName set using setFilePath or setLogFileName are used if no or empty \c p_path or
            \c p_fileName are given as parameter of this method.

            \param[in] p_path Path to locate the log file. To use default path ("."), \b either leave
                              the field empty if setFilePath() has not previously been called, \b or set the file path
                              to "." using sqi::log::setFilePath("."), \b or reset file path to an empty string -- using
                              sqi::log::setFilePath(QString()) -- to then leave the field empty.
            \param[in] p_fileName Name of the log file. To use default name, either leave the field empty, or if
                              setFileName has been previously called set it to an empty QString (using sqi::log::setFileName(QString())).
            \returns false if opening failed or was already opened
        */
        bool open(const QString& p_path = ".", const QString& p_fileName = "");
        void close();


        void log(const QString& p_prefix, const QString& p_message, sqi::log::LogLevels p_logLevels = sqi::log::Default);
        void msg(const QString&     p_message, sqi::log::LogLevels p_logLevels = sqi::log::Default);
        void err(const QString&     p_message, sqi::log::LogLevels p_logLevels = sqi::log::Default);
        void msg(const std::string& p_message, sqi::log::LogLevels p_logLevels = sqi::log::Default);
        void err(const std::string& p_message, sqi::log::LogLevels p_logLevels = sqi::log::Default);
        void msg(const char*        p_message, sqi::log::LogLevels p_logLevels = sqi::log::Default);
        void err(const char*        p_message, sqi::log::LogLevels p_logLevels = sqi::log::Default);

        /*!
        \brief Set the log file Name

        Log file name is set if log file is not already opened and if p_fileName is not empty

        \param[in] p_fileName Name of the log file.
        \returns true if log file name has been set, false otherwise
        */
        bool setFileName(const QString& p_fileName);
        /*!
        \brief Set the log file Path
        
        Log file path is set if log file is not already opened and if p_filePath is not empty

        \param[in] p_filePath Path to locate the log file.
        \returns true if log file path has been set, false otherwise
        */
        bool setFilePath(const QString& p_filePath);
        //! \returns the absolute path and file name of the current log file (Null QString if empty or not set).
        const QString getAbsoluteFilePath();
        //! \returns the file name of the current log (Null QString if empty or not set).
        const QString getFileName();
        //! \returns the file path of the current log (Null QString if empty or not set).
        const QString getFilePath();
        //! \brief Enable the use of XLogData to generate log file.
        void enableXlog();
        /*!
        \brief Disable the use of XLogData to generate log file.

        Use the default LogData format from this point on.
        */
        void disableXlog();

        /*!
        \brief Let user set the log level policy for log entries.

        The p_logLevel in parameter will be used and will \b overrule any other custom
        logLevel used in existing log, msg or err entry.
        To reset changes, use resetLogLevels().<br>

        \par Example:
        \code
        sqi::log::setLogLevels(sqi::log::ReleaseOnly);
        sqi::log::open("aDirectory");
        
        // further down in the code:
        sqi::log::msg("DEBUG message: In method m", sqi::log::DebugInConsole);
            // eventhough the previous message should only be displayed in the console in Debug mode,
            // since setLogLevels has been used, this message will be displayed in release (only) mode
            // in the console AND in the Log File.
        \endcode
        \param[in] p_logLevels Log level to be used on all log, msg or err entry.
        */
        void setLogLevels(sqi::log::LogLevels p_logLevels);
        /*!
        \brief Cancel any changes made while using setLogLevels()

        The custom log level used in log, msg or err will no longer be overriden by LogLevels
        set previously by the call to setLogLevels().
        */
        void resetLogLevels();
        /*! \brief Enable the fact that all log will be flushed at all times.

        On LogData, all logs will be flushed (even in release mode) if sqi::log::LogLevels allows it.

        \note No effect on XLogData.
        */
        void enableFlushAllInRelease();
        /*!
        \brief Disable the fact that flush will be performed on all log entry of LogData.

        Use the default behavior from this point on: flush is performed in release mode only for "ERR" prefix ; 
        and always in debug mode (if sqi::log::LogLevels allows it).

        \note No effect on XLogData.
        */
        void disableFlushAllInRelease();
    }
}






//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//      Classes to allow << overloading.
//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------





#include <iostream>
#include <sstream>
#include <QMutexLocker>

namespace sqi
{
    namespace log
    {
        //---------------------------------------------------------------------------------------------------------------------------------------------------------
        class LogStream
        //---------------------------------------------------------------------------------------------------------------------------------------------------------
        {
        public:
            LogStream() {}

        protected:
            std::ostringstream m_output;
            QMutex m_mutex;
        };

        //---------------------------------------------------------------------------------------------------------------------------------------------------------
        class LogMsg : public LogStream
        //---------------------------------------------------------------------------------------------------------------------------------------------------------
        {
            friend LogMsg& msg() ;
            static LogMsg s_stream;
        public:
            LogMsg() {}

            template <typename T>
                inline LogMsg& operator<<(T p_data);

            inline LogMsg& operator<<(std::ostream& (*p_manip)(std::ostream&) );
        };

        //---------------------------------------------------------------------------------------------------------------------------------------------------------
        class LogErr : public LogStream
        //---------------------------------------------------------------------------------------------------------------------------------------------------------
        {
            friend LogErr& err() ;
            static LogErr s_stream;
        public:
            LogErr() {}

            template <typename T>
                inline LogErr& operator<<(T p_data);

            inline LogErr& operator<<(std::ostream& (*p_manip)(std::ostream&) );
        };


        //---------------------------------------------------------------------------------------------------------------------------------------------------------
        inline LogMsg& msg() { return LogMsg::s_stream; }
        inline LogErr& err() { return LogErr::s_stream; }

        //---------------------------------------------------------------------------------------------------------------------------------------------------------
        template <typename T>
            inline LogMsg& LogMsg::operator<<(T p_data)
        //---------------------------------------------------------------------------------------------------------------------------------------------------------
        {
            QMutexLocker locker(&m_mutex);
            m_output << p_data;
            return *this;
        }


        //---------------------------------------------------------------------------------------------------------------------------------------------------------
        inline LogMsg& LogMsg::operator<<(std::ostream& (*p_manip)(std::ostream&) )
        //---------------------------------------------------------------------------------------------------------------------------------------------------------
        {
            QMutexLocker locker(&m_mutex);
#if defined __GNUC__
            // Reported bug in GCC compiler (reject)
            // See http://gcc.gnu.org/bugzilla/show_bug.cgi?id=11407
            if ( *p_manip == static_cast< std::ostream& (*)(std::ostream&) > (&std::endl<char, std::char_traits<char> >) )
#else
            if ( *p_manip == &std::endl )
#endif
            {
                msg(m_output.str());
                m_output.str( "" );
            }
            else
            {
                (*p_manip) (m_output);            // or // output << p_manip;
            }
            return *this;
        }

        //---------------------------------------------------------------------------------------------------------------------------------------------------------
        template <typename T>
            inline LogErr& LogErr::operator<<(T p_data)
        //---------------------------------------------------------------------------------------------------------------------------------------------------------
        {
            QMutexLocker locker(&m_mutex);
            m_output << p_data;
            return *this;
        }


        //---------------------------------------------------------------------------------------------------------------------------------------------------------
        inline LogErr& LogErr::operator<<(std::ostream& (*p_manip)(std::ostream&) )
        //---------------------------------------------------------------------------------------------------------------------------------------------------------
        {
            QMutexLocker locker(&m_mutex);
#if defined __GNUC__
            // Reported bug in GCC compiler (reject)
            // See http://gcc.gnu.org/bugzilla/show_bug.cgi?id=11407
            if ( *p_manip == static_cast< std::ostream& (*)(std::ostream&) > (&std::endl<char, std::char_traits<char> >) )
#else
            if ( *p_manip == &std::endl )
#endif
            {
                err(m_output.str());
                m_output.str( "" );
            }
            else
            {
                (*p_manip) (m_output);            // or // output << p_manip;
            }
            return *this;
        }

    }
}

#endif // _BaseLog_
