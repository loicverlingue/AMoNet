#ifndef _XFile_
#define _XFile_

#include <QPair>
#include <QString>
#include <QList>
#include <QStack>
#include <QDomElement>
#include <QDomDocument>
#include <QFile>
#include <QTextStream>


namespace sqi
{

    //--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    namespace log
    //--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    {

        class XFile
        {
        private:
            class XFileElt; //private because it's an helper implementation, user should not use this class directly.
        public:

            typedef QPair<QString,QString> Attribute; //an attribute is a pair of 2 strings : Attribute.first is the name, Attribute.second is the value.
            typedef QList<Attribute> AttributesList; //A list of attributes

            XFile(const QString& p_docType = "SQI_xlog",int indent = 4);

            //!start a new xml element called p_name
            void startElement(const QString& p_name);

            //!start a new xml element called p_name, and having some attributes described in p_attributesList
            //!use it instead of :
            //!startElement(p_name);
            //!writeAttributes(p_attributesList);
            //!because it is more efficient (write all in once)
            void startElement(const QString& p_name, const AttributesList& p_attributesList );
            void startElement(const QString& p_name, const Attribute& p_attribute );

            //!end current element, current element becomes the parent (or none if the root is closed)
            void endElement();
            void endAllElementsExceptRoot(); //! close all remaining elements opened except root
            
            //!add one attribute to current element
            //!if an attribute p_name already exists, its value will be replaced by p_value
            //!it rewrite all the current element, so it could be a long operation
            void writeAttribute(const Attribute& p_value);
            void writeAttribute(const QString& p_name, const QString& p_value);
            
            //!add a list of attributes to current element
            //!if one or more attributes already exists, their values will be replaced.
            //!use it instead of consecutive calls to writeAttribute, it's more efficient    
            void writeAttributes(const AttributesList&);

            //!add a text to current element
            void writeText(const QString& p_text);
            //!write a simple text element
            void writeTextElement(const QString& p_name, const QString& p_text);

            //!add a comment to current element
            void writeComment(const QString& p_text);

            //!add a CData section to current element
            void writeCData( const QString & text );
            void writeCData( const QByteArray& p_array);
            
            //!open Xlog in p_fileName
            bool open(const QString& p_fileName);

            //!close Xlog
            void close();

            //!save a copy of current state of Xlog in p_fileName
            bool saveDomAs(const QString& p_fileName);

            //!set the indent size (default is 4)
            //!cannot be changed if the log is already open
            //!p_indent cannot be negative.
            //!returns true if these conditions are matched
            bool setIndent(int p_indent);
            

            bool isOpen() const { return m_file.isOpen();}

            //when you activate the quick mode => you cannot use the function writeAttribute (TODO => maybe possible just after the startElement)
            //the file will not be xml valid until you call desactivateQuickMode
            //activate/desactivate works as a stack if you call twice activateQuickMode(), you must call twice desactivateQuickMode to effectively desactivate the quick mode
            void activateQuickMode();
            void desactivateQuickMode(); //! close all remaining elements opened in quickmode
            
            QDomDocument getCloneDom();
            
        protected:

            void endWrite();
            void closeCurrents();
            void closeCurrentsExceptTop();

        protected:
            QTextStream m_stream;
            QFile m_file;
            QStack<XFileElt*> m_currents;
            QDomDocument m_doc;

            int m_indent;

            bool m_quickMode;
            int m_numberOfQuickModeAsked;
            qint64 m_endOfFile;

        };


        class XFile::XFileElt
        {
        public:
            XFileElt(QDomDocument& p_doc,const QString& p_name, QTextStream& p_stream); //maybe must be protected => only created by XLog???

            void begin(int p_indent,int p_depth, bool p_quickMode = false); //!write the opening part of the element
            void close(int p_indent,int p_depth, bool p_quickMode = false); //!close the element

            bool update(int p_indent,int p_depth); //!update element and subelements => close itself

            void appendChild(XFileElt* p_child); //!add a new XLogElt as a child
            void insertText(const QString &p_text, bool p_quickMode = false); //!insert the text to this XLogElt
            void insertComment(const QString &p_comment, int p_indent, int p_depth, bool p_quickMode = false);//!insert comment to this XLogElt
            void insertCData(const QString &p_text, int p_indent, int p_depth, bool p_quickMode = false); //!insert a cdata section

            inline qint64 insertionPos() const { return m_insertionPos;}; //!where the next item must be inserted?
            inline qint64 closePos() const { return m_closePos;}; //!position in stream where this element ends
            void setInsertionPos(qint64 p_newIns); //!use it to update insertion pos (no check!)
            inline bool hasChildElements() const { return !m_children.isEmpty();}; //!is it a leaf element?

            QDomElement element() { return m_xmlElement; }; //!corresponding dom element


        protected:
            void protectedUpdate(int,int);
        protected:
            QDomDocument& m_factory; //DomDocument which owns this element
            QDomElement m_xmlElement; //corresponding dom element

            qint64      m_posInStream; //beginning pos of this element in m_docStream
            qint64      m_insertionPos; //current insertion pointer in m_docStream
            qint64      m_closePos; //current end of this element in m_docStream
            

            QTextStream& m_docStream; //the stream where this element is written

            QList<XFileElt*> m_children; // list of all direct children

            //bool m_quickModeEndOK;

        };

        inline void XFile::XFileElt::setInsertionPos(qint64 p_newIns)
        {
            m_insertionPos = p_newIns;
        }

    }
}

#endif // _XFile_
