#include <QDir>

#include "sqi/Log/XLog.h"

namespace sqi
{
    namespace log
    {

        //---------------------------------------------------------------------
        XLogData* XLogData::instance()
        //---------------------------------------------------------------------
        {
            static XLogData s_log;
            return &s_log;
        }


        //---------------------------------------------------------------------
        XLogData::XLogData() :
        //---------------------------------------------------------------------
               XFile("SQI_xlog", 4),
               m_userSpecifiedLogLevels(false),
               m_logLevels(sqi::log::Default),
               m_filePath(QString()),
               m_fileName(QString()),
               m_currentFrame(0)
        {
        }


        //---------------------------------------------------------------------
        QDateTime XLogData::now()
        //---------------------------------------------------------------------
        {
            return QDateTime::currentDateTime();
        }


        //---------------------------------------------------------------------
        bool XLogData::open(const QString& p_path, const QString& p_fileName)
        //---------------------------------------------------------------------
        {
            // Add this first test now that log file can be opened whenever the user wants to.
            if (m_file.isOpen() == true)
                return false;

            // Reset current frame number
            m_currentFrame = 0;

            if (p_path.isEmpty() == true || p_path == ".") // "." is the default value
            {
                if (m_filePath.isEmpty() == true)
                {
                    // Value forced by user to 'empty' in order to use default value
                    m_filePath = ".";
                }
                // else
                   //use current m_logFilePath
            }
            else
                m_filePath = p_path;

            // check if directory exists
            QDir dir;
            QString logPath(m_filePath);
            if (dir.exists(logPath)==false)
                dir.mkdir(logPath);



            if (p_fileName.isEmpty() == true)
            {
                if (m_fileName.isEmpty() == true)
                {
                    // Use default value "date_and_time specific format
                    m_fileName = "Log" + now().toString("yyyyMMddhhmmsszzz") + ".xml";
                }
                //else
                   // use current m_logFileName
            }
            else
                m_fileName = p_fileName;



            bool l_res = false;
            {
                QMutexLocker mutexLocker(&m_mutex);
                l_res = XFile::open(m_filePath + "/" + m_fileName);
            }

            if (l_res == true)
            {
                QMutexLocker mutexLocker(&m_mutex);
                startElement("SQI_xlog"); // Will be closed in the close() method
                XFile::writeAttribute("version", "1.0");
            }

            if (l_res == true)
            {
                log(QString("MSG"), QString("[XLogData::open] OPEN"));
#ifndef NDEBUG
                log(QString("MSG"), QString("[XLogData] MODE DEBUG"));
#endif
            }

            return (l_res);
        }


        //---------------------------------------------------------------------
        void XLogData::close()
        //---------------------------------------------------------------------
        {
            log("MSG","[XLogData::close] CLOSE");

            QMutexLocker mutexLocker(&m_mutex);

            endElement(); // closes ASTeK_xlog

            XFile::close();
        }


        //---------------------------------------------------------------------
        void XLogData::log(const QString& p_prefix, const QString& p_message, sqi::log::LogLevels p_logLevels)
        //---------------------------------------------------------------------
        {
            LogLevels logLevels;
            if (m_userSpecifiedLogLevels == true)
            {
                logLevels = m_logLevels;
            }
            else
            {
                logLevels = p_logLevels;
            }

            QMutexLocker mutexLocker(&m_mutex);
            QString strDateTime = now().toString("yyyy.MM.dd-hh:mm:ss.zzz");

            // >>>>>>>>>> Fix the issue #369
#ifndef NDEBUG
            if (logLevels.testFlag(sqi::log::DebugInLogFile) == true
#else
            if (logLevels.testFlag(sqi::log::ReleaseInLogFile) == true
#endif      // <<<<<<<<<< end of fix the issue #369
                &&
                m_file.isOpen() == true)
            {
                m_currentFrame++;

                startElement("xlog");

                startElement("prefix");
                writeText   (p_prefix);
                endElement  (        );

                startElement("date"     );
                writeText   (strDateTime);
                endElement  (           );

                startElement("frame"                          );
                writeText   (QString("%1").arg(m_currentFrame));
                endElement  (                                 );

                startElement("message");
                writeText   (p_message);
                endElement  (         );

                endElement(); // closes xlog
            }

#ifndef NDEBUG
            if (logLevels.testFlag(sqi::log::DebugInConsole) == true)
#else
            if (logLevels.testFlag(sqi::log::ReleaseInConsole) == true)
#endif
            {
                std::stringstream output(std::stringstream::out);
                output << p_prefix.toStdString() << " " << strDateTime.toStdString() << " | " << p_message.toStdString() << std::endl;

                std::cerr << output.str();
            }
        }


        //---------------------------------------------------------------------
        const QString XLogData::getFileName() const
        //---------------------------------------------------------------------
        {
            return m_fileName;
        }


        //---------------------------------------------------------------------
        const QString XLogData::getFilePath() const
        //---------------------------------------------------------------------
        {
            return m_filePath;
        }


        //---------------------------------------------------------------------
        const QString XLogData::getAbsoluteFilePath() const
        //---------------------------------------------------------------------
        {
            QFileInfo logFileInfo(m_file);
            return logFileInfo.absoluteFilePath();
        }


        //---------------------------------------------------------------------
        bool XLogData::setFileName(const QString& p_fileName)
        //---------------------------------------------------------------------
        {
            if (m_file.isOpen() == true)
                return false;

            m_fileName = p_fileName;
            return true;
        }


        //---------------------------------------------------------------------
        bool XLogData::setFilePath(const QString& p_filePath)
        //---------------------------------------------------------------------
        {
            if (m_file.isOpen() == true)
                return false;

            m_filePath = p_filePath;
            return true;
        }


        //---------------------------------------------------------------------
        void XLogData::setLogLevels(sqi::log::LogLevels p_logLevels)
        //---------------------------------------------------------------------
        {
            m_userSpecifiedLogLevels = true;
            m_logLevels = p_logLevels;
        }


        //---------------------------------------------------------------------
        void XLogData::resetLogLevels()
        //---------------------------------------------------------------------
        {
            m_userSpecifiedLogLevels = false;
            m_logLevels = sqi::log::Default;
        }


    };
};
