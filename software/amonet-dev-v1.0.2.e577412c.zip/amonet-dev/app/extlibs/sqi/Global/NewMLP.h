#ifndef _NEW_MLP_
#define _NEW_MLP_

//! \file NewMLP.h
//! \brief New operator to manage memory leak. NewMLPReportingHook.h may be
//! used with this.
//! \author Christophe Thiesset <christophe.thiesset@surgiqual-institute.com>
//! \date August 2013
//! \copyright Copyright (c) 2013 All Right Reserved, http://www.surgiqual-institute.com/

// // 'Things' to manage memory leak through ASTeK newMLP operator.
// #if defined(_WIN32) && defined(_DEBUG)
//     #define _CRTDBG_MAP_ALLOC
//     #include <stdlib.h>
//     #include <crtdbg.h>
// #endif

// //-----------------------------------------------------------------------------
// int main( int argc, char *argv[] )
// //-----------------------------------------------------------------------------
// {
//     // 'Things' to manage memory leak through ASTeK newMLP operator.
// #if defined(_MSC_VER) && defined(_DEBUG)
//     _CrtSetDbgFlag ( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF | _CRTDBG_DELAY_FREE_MEM_DF );
// #endif
//     ...
//     ...
//     // If using the NewMLPReportingHook.h (don't forget to include it), then finish with:
// #if defined(_MSC_VER) && defined(_DEBUG)
//     setFilterDebugHook();
// #endif
//
// return 0;
// }



//Memory leaks detection
#if defined(_WIN32) && defined(_DEBUG)
    #include <crtdbg.h>
    #ifndef DEBUG_NEW
        #define DEBUG_NEW new( _NORMAL_BLOCK, __FILE__, __LINE__ )
        #define newMLP DEBUG_NEW
    #endif
#else
    #define newMLP new
#endif

#endif // _NEW_MLP_
