#include "sqi/Global/GeneralDefs.h"

namespace sqi
{
//    const char* VERSION = "0.3Dev";
};
