namespace sqi
{
    template <typename T>
    inline bool delPtr(T*& p_ptr)
    {
        if (p_ptr)
        {
            delete p_ptr;
#if defined( _MSC_VER ) && ( _MSC_VER <= 1500 )
            p_ptr = 0;
#else
            p_ptr = nullptr;
#endif
            return true;
        }
        else
            return false;
    }

    template <typename T>
    inline bool delTable(T*& p_tablePtr)
    {
        if (p_tablePtr)
        {
            delete [] p_tablePtr;
#if defined( _MSC_VER ) && ( _MSC_VER <= 1500 )
            p_tablePtr = 0;
#else
            p_tablePtr = nullptr;
#endif
            return true;
        }
        else
            return false;
    }

    template <typename T>
    inline bool delVtkPtr(T*& p_vtkPtr)
    {
        if (p_vtkPtr)
        {
            p_vtkPtr->Delete();
#if defined( _MSC_VER ) && ( _MSC_VER <= 1500 )
            p_vtkPtr = 0;
#else
            p_vtkPtr = nullptr;
#endif
            return true;
        }
        else
            return false;
    }
    template <typename T>
    inline bool delPtr(const T& p_ptr)
    {
        if (p_ptr)
        {
            delete p_ptr;
            //p_ptr = 0;
            return true;
        }
        else
            return false;
    }

    template <typename T>
    inline bool delTable(const T& p_tablePtr)
    {
        if (p_tablePtr)
        {
            delete [] p_tablePtr;
            //p_tablePtr = 0;
            return true;
        }
        else
            return false;
    }

    template <typename T>
    inline bool delVtkPtr(const T& p_vtkPtr)
    {
        if (p_vtkPtr)
        {
            p_vtkPtr->Delete();
            //p_vtkPtr = 0;
            return true;
        }
        else
            return false;
    }
}
