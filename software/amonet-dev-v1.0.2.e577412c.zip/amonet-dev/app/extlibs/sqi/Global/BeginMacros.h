#include "sqi/Global/NewMLP.h"
#ifndef TYPE_SELF
#define TYPE_SELF(T) \
    public:         \
        typedef T Self
#endif

/*#ifndef DEF_PARAMETER
#define DEF_PARAMETER(X, Type)                                  \
    protected:                                                  \
        Type m##X;                                              \
    public:                                                     \
        const Type& get##X() const { return m##X; }             \
        void set##X(const Type& p##X) { m##X = p##X; }
#endif
*/


#ifndef CREATE_FUNC
#define CREATE_FUNC(T)    \
    public:               \
        static T* create() { return newMLP Self; }
#endif

#ifndef DEVICE_CREATE_FUNC
#define DEVICE_CREATE_FUNC   CREATE_FUNC(DeviceDriver)
#endif

#ifndef KERNEL_OBSERVER_CREATE_FUNC
#define KERNEL_OBSERVER_CREATE_FUNC   CREATE_FUNC(KernelHooker)
#endif

#ifndef DEVICE_DATA_ACCESS
#define DEVICE_DATA_ACCESS(T)   \
            inline T* data() { return dynamic_cast<T*>(m_data); }    \
            inline const T* data() const { return dynamic_cast<const T*>(m_data); }  \
            virtual void getData(DeviceData& p_data) const { if (!m_data) return; lock(); dynamic_cast<T&>(p_data)=(* data());      unlock(); }    \
            virtual void setData(const DeviceData& p_data) { if (!m_data) return; lock(); (*data())=dynamic_cast<const T&>(p_data); unlock(); }
#endif

#ifndef DM_OBJECT
#define DM_OBJECT(T) \
            TYPE_SELF(T); \
            static const std::string& TYPE() ; \
            virtual const std::string& type() const { return TYPE(); } \
            static sqi::dm::Object* createObject() { return static_cast<Object*>(newMLP Self); } \
            static void registerType() { sqi::dm::ObjectFactory::instance()->registerType<Self>(TYPE()); } \
            static Self & cast(Object& p_object) { return dynamic_cast<Self&>(p_object); } \
            static const Self & cast(const Object& p_object) { return dynamic_cast<const Self&>(p_object); } \
            virtual Object* copy() const      {   return static_cast<Object*>(newMLP  Self(*this)); }
#endif

#ifndef DM_TPL_OBJECT
#define DM_TPL_OBJECT(T,X) \
            TYPE_SELF(T); \
            static const std::string& TYPE() { static const std::string s_type( X ); return s_type; } \
            virtual const std::string& type() const { return TYPE(); } \
            static sqi::dm::Object* createObject() { return static_cast<Object*>(newMLP Self); } \
            static void registerType() { sqi::dm::ObjectFactory::instance()->registerType<Self>(TYPE()); } \
            static Self & cast(Object& p_object) { return dynamic_cast<Self&>(p_object); } \
            static const Self & cast(const Object& p_object) { return dynamic_cast<const Self&>(p_object); } \
            virtual Object* copy() const      {   return static_cast<Object*>(newMLP  Self(*this)); }
#endif

#ifndef DM_IMPLEMENT_OBJECT
#define DM_IMPLEMENT_OBJECT(T,X) \
            const std::string& T::TYPE() \
            { \
                static const std::string s_type( X ); \
                return s_type; \
            }
#endif

// ISSUE 0000003, 2010-02-15 JLE -->
// Must define static member function TYPE() before it is instantiated
#ifndef DM_DECLARE_TPL_OBJECT_TYPE
#define DM_DECLARE_TPL_OBJECT_TYPE(T, X) \
     template<> inline const std::string & T::TYPE() { static const std::string s_type( X ); return s_type; };
#endif
// <-- ISSUE 0000003

#ifdef __GNUC__
#define PRETTY_FUNCTION __PRETTY_FUNCTION__
#else
#define PRETTY_FUNCTION ""
#endif

#include <sstream>
#ifndef HERE
#define HERE \
    (dynamic_cast<std::ostringstream&>(std::ostringstream(std::string("")) << "In file " << __FILE__ << " at line " << __LINE__ << ": [" << PRETTY_FUNCTION << "] ")).str()
#endif

// exception to RegDev here : macro is lower case to imitate for() statement
#ifndef iter
#define iter(TYPE,I,CONT)  for (TYPE::iterator I=CONT.begin();I!=CONT.end(); I++)
#endif

// exception to RegDev here : macro is lower case to imitate for() statement
#ifndef const_iter
#define const_iter(TYPE,I,CONT)  for (TYPE::const_iterator I=CONT.begin();I!=CONT.end(); I++)
#endif

//#include <cassert>
//#ifndef ASSERT
//#ifndef NDEBUG
//    #define ASSERT(X) log::err(HERE + "Assertion failed")
//#else
//    #define ASSERT(X) assert(x)
//#endif
//#endif
