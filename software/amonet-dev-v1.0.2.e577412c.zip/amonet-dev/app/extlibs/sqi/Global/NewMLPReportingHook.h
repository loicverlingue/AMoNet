#ifndef _NEW_MLP_REPORTING_HOOK_
#define _NEW_MLP_REPORTING_HOOK_

//! \file NewMLPReportingHook.h
//! \brief Function allowing to 'remove', for example, Qt memory leaks
//! in the report displayed in 'output'. This version displays only
//! memory leak comming from known .cpp file.
//! \author Christophe Thiesset <christophe.thiesset@surgiqual-institute.com>
//! \date August 2013
//! \copyright Copyright (c) 2013 All Right Reserved, http://www.surgiqual-institute.com/
//!
//! Pointed by DGM.
//! Source: http://winfig.com/detecting-memory-leaks-in-qt-applications-with-visual-studio/


#if defined(_MSC_VER) && defined(_DEBUG)

    #define _CRTDBG_MAP_ALLOC
    
    #include <stdlib.h>
    #include <crtdbg.h>
    #include <string.h>

    _CRT_REPORT_HOOK prevHook;
    int reportingHook(int reportType, char* userMessage, int* retVal)
    {
        // This function is called several times for each memory leak.
        // Each time a part of the error message is supplied.
        // This holds number of subsequent detail messages after
        // a leak was reported
        const int numFollowupDebugMsgParts = 2;
        static bool ignoreMessage = false;
        static int debugMsgPartsCount = 0;
        // check if the memory leak reporting starts
        if ((strncmp(userMessage,"Detected memory leaks!\n", 10) == 0) || ignoreMessage)
        {
            // check if the memory leak reporting ends
            if (strncmp(userMessage,"Object dump complete.\n", 10) == 0)
            {
                _CrtSetReportHook(prevHook);
                ignoreMessage = false;
            }
            else
            {
                ignoreMessage = true;
            }

            // something from our own code?
            if(strstr(userMessage, ".cpp") == NULL && strstr(userMessage, ".hpp") == NULL)
            {
                if(debugMsgPartsCount++ < numFollowupDebugMsgParts)
                    return 0; // give it back to _CrtDbgReport() to be printed to the console
                else
                    return 1; // ignore it
            }
            else
            {
                debugMsgPartsCount = 0;
                // give it back to _CrtDbgReport() to be printed to the console
                return 0;
            }
        } else
            // give it back to _CrtDbgReport() to be printed to the console
            return 0;
    }

    // This function MUST be called at the END of the main() before the return.
    //     #if defined(_MSC_VER) && defined(_DEBUG)
    //       setFilterDebugHook();
    //     #endif
    void setFilterDebugHook()
    {
        //change the report function to only report memory leaks from program code
        prevHook = _CrtSetReportHook(reportingHook);
    }

#else

    void setFilterDebugHook() {}

#endif

#endif // _NEW_MLP_REPORTING_HOOK_
