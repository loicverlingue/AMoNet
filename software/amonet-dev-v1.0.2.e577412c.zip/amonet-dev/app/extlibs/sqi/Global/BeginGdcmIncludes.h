// Might be convenient for clients but AsTeK should NOT use it!
    #if defined ( _MSC_VER ) && ( _MSC_VER <= 1500 )
        #pragma warning( disable: 4396 4996 )
    #endif
