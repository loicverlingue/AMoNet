    #if defined ( _MSC_VER ) && ( _MSC_VER <= 1500 )
        #pragma warning( default: 4396 4996 )
    #endif
