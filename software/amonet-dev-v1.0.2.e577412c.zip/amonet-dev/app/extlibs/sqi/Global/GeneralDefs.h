#ifndef _GeneralDefs_
#define _GeneralDefs_

namespace sqi
{
    extern const char* VERSION;

    template <typename T>
    inline bool delPtr(T*& p_ptr);

    template <typename T>
    inline bool delTable(T*& p_tablePtr);

    template <typename T>
    inline bool delVtkPtr(T*& p_vtkPtr);

    template <typename T>
    inline bool delPtr(const T& p_ptr);

    template <typename T>
    inline bool delTable(const T& p_tablePtr);

    template <typename T>
    inline bool delVtkPtr(const T& p_vtkPtr);
}

#include "GeneralDefs.hpp"

#endif // _GeneralDefs_
