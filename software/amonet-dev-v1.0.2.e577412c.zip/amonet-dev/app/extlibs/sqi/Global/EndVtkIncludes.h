// reactivate 'deprecated' warning

    #ifdef  __DEPRECATED_WAS_SET
        #define __DEPRECATED
        #undef  __DEPRECATED_WAS_SET
    #endif
