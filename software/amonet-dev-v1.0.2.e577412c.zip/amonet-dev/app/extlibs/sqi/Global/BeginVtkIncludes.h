// suppress 'deprecated' warning for Vtk includes

    #ifdef  __DEPRECATED
        #define __DEPRECATED_WAS_SET
        #undef  __DEPRECATED
    #endif
