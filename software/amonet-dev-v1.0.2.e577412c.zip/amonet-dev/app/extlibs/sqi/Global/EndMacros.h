/*#ifdef DEF_PARAMETER
#undef DEF_PARAMETER
#endif

*/
#ifdef TYPE_SELF
#undef TYPE_SELF
#endif

#ifdef CREATE_FUNC
#undef CREATE_FUNC
#endif

#ifdef DEVICE_CREATE_FUNC
#undef DEVICE_CREATE_FUNC
#endif

#ifdef KERNEL_OBSERVER_CREATE_FUNC
#undef KERNEL_OBSERVER_CREATE_FUNC
#endif

#ifdef DEVICE_DATA_ACCESS
#undef DEVICE_DATA_ACCESS
#endif

#ifdef DM_OBJECT
#undef DM_OBJECT
#endif

#ifdef DM_IMPLEMENT_OBJECT
#undef DM_IMPLEMENT_OBJECT
#endif

#ifdef DM_TPL_OBJECT
#undef DM_TPL_OBJECT
#endif

#ifdef DM_DECLARE_TPL_OBJECT_TYPE
#undef DM_DECLARE_TPL_OBJECT_TYPE
#endif

#ifdef PRETTY_FUNCTION
#undef PRETTY_FUNCTION
#endif

#ifdef HERE
#undef HERE
#endif

#ifdef iter
#undef iter
#endif

#ifdef const_iter
#undef const_iter
#endif
