<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr">
<context>
    <name>AbstractView</name>
    <message>
        <source>AMONET</source>
        <translation>AMoNet</translation>
    </message>
    <message>
        <source>THANKS_BMS</source>
        <translation>Remerciement à la fondation BMS pour le soutien au développement de l’interface.</translation>
    </message>
    <message>
        <source>AMONET_DISCLAMER_%1_%2_%3_%4</source>
        <translation>AMoNet est dédié à la prédiction de survie à partir du séquençage ciblé somatique des patients affectés du/des cancer(s) %1. AMoNet est une intelligence artificielle entrainée sur une cohorte de %2 en relation avec l’indication. Les méthodes sont détaillées dans la publication %3. Pour des développement spécifiques (nouvelles listes de gènes, indications, etc…) merci de contacter l’équipe AMoNet %4.</translation>
    </message>
    <message>
        <source>PATIENT</source>
        <translation>PATIENT</translation>
    </message>
    <message>
        <source>ENTER_LAST_NAME</source>
        <translation>Nom de famille</translation>
    </message>
    <message>
        <source>ENTER_FIRST_NAME</source>
        <translation>Prénom</translation>
    </message>
    <message>
        <source>ENTER_ID</source>
        <translation>Identifiant patient</translation>
    </message>
    <message>
        <source>ENTER_CLINICAL_INFOS</source>
        <translation>Informations cliniques</translation>
    </message>
</context>
<context>
    <name>ErrorPopup</name>
    <message>
        <source>ERROR</source>
        <translation>Erreur</translation>
    </message>
    <message>
        <source>VALID</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>FirstPageView</name>
    <message>
        <source>PATIENT_MUTATION</source>
        <translation>DONNEES DE MUTATION DU PATIENT</translation>
    </message>
    <message>
        <source>SEARCH_A_GENE</source>
        <translation>Nom du gène (nomenclature HUGO)</translation>
    </message>
    <message>
        <source>CHOOSE_PATIENT_DATA</source>
        <translation>Fichier de données de mutation du patient</translation>
    </message>
    <message>
        <source>THERAPY</source>
        <translation>THERAPIE</translation>
    </message>
    <message>
        <source>COMPUTE</source>
        <translation>LANCER LA PREDICTION</translation>
    </message>
    <message>
        <source>LOAD</source>
        <translation>Charger un fichier</translation>
    </message>
    <message>
        <source>ADVANCED</source>
        <translation>Avancé</translation>
    </message>
</context>
<context>
    <name>LoadingPopup</name>
    <message>
        <source>LOADING</source>
        <translation>Prédiction en cours...</translation>
    </message>
</context>
<context>
    <name>MutationComboBox</name>
    <message>
        <source>NO_MUTATION</source>
        <translation>Pas de mutation</translation>
    </message>
    <message>
        <source>NON_PATHOGENIC_MUTATION</source>
        <translation>Mutation non pathogénique</translation>
    </message>
    <message>
        <source>UNKNOWN_PATHOGENIC_MUTATION</source>
        <translation>Mutation de pathogénicité inconnue</translation>
    </message>
    <message>
        <source>PATHOGENIC_MUTATION</source>
        <translation>Mutation pathogénique</translation>
    </message>
</context>
<context>
    <name>PredictionGraphView</name>
    <message>
        <source>SURVIVAL_TIME_IN_MONTH</source>
        <translation>Temps (mois)</translation>
    </message>
    <message>
        <source>SURVIVAL_RATE_IN_%</source>
        <translation>Probabilité de survie (%)</translation>
    </message>
</context>
<context>
    <name>SecondPageView</name>
    <message>
        <source>GRAPH_TITLE</source>
        <translation>COURBE DE SURVIE</translation>
    </message>
    <message>
        <source>LAST_CONVERGENCE_VALUE_TEXT - %1%</source>
        <translation>Changement des noeuds de sortie lors de la dernière itération: %1%</translation>
    </message>
    <message>
        <source>MODIFY</source>
        <translation>Modifier les données</translation>
    </message>
    <message>
        <source>SAVE_RESULTS</source>
        <translation>Enregistrer</translation>
    </message>
    <message>
        <source>CHOOSE_A_FOLDER</source>
        <translation>Dossier d&apos;enregistrement</translation>
    </message>
</context>
<context>
    <name>TherapyItem</name>
    <message>
        <source>INHIBITION</source>
        <translation>Inhibition</translation>
    </message>
    <message>
        <source>ACTIVATION</source>
        <translation>Activation</translation>
    </message>
    <message>
        <source>UNKNOWN</source>
        <translation>Erreur</translation>
    </message>
</context>
<context>
    <name>gui::ExporterModel</name>
    <message>
        <source>NO_THERAPY</source>
        <translation>Aucune thérapie</translation>
    </message>
</context>
<context>
    <name>gui::MutationsModel</name>
    <message>
        <source>ERROR_READ_FILE</source>
        <translation>Lecture du fichier impossible. Merci de vous référer au manuel utilisateur pour plus de détails sur le format de fichier ou contactez le support.</translation>
    </message>
</context>
<context>
    <name>gui::TherapyModel</name>
    <message>
        <source>NO_THERAPY</source>
        <translation>Pas de thérapie</translation>
    </message>
    <message>
        <source>ERROR_READ_FILE</source>
        <translation>Lecture du fichier impossible. Merci de vous référer au manuel utilisateur pour plus de détails sur le format de fichier ou contactez le support.</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <source>AMONET</source>
        <translation type="vanished">AMoNet_FR</translation>
    </message>
    <message>
        <source>CANT_LOAD_NETWORK</source>
        <translation>Lecture du modèle entraîné impossible. Merci de vous référer au manuel utilisateur pour plus de détails ou contactez le support.</translation>
    </message>
    <message>
        <source>CANT_LOAD_TIMES_INTERVAL</source>
        <translation>Lecture des données d&apos;apprentissage impossible. Merci de vous référer au manuel utilisateur pour plus de détails ou contactez le support.</translation>
    </message>
</context>
</TS>
