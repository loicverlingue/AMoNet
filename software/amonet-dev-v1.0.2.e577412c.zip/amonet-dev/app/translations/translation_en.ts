<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en">
<context>
    <name>AbstractView</name>
    <message>
        <source>AMONET</source>
        <translation>AMoNet</translation>
    </message>
    <message>
        <source>THANKS_BMS</source>
        <translation>Thanks to the BMS fundation for supporting the development of the interface.</translation>
    </message>
    <message>
        <source>AMONET_DISCLAMER_%1_%2_%3_%4</source>
        <translation>AMoNet is intended for the survival prediction from somatic targetted sequencing of patients affected by %1 cancer. AMoNet is an artifical intelligence trained on a cohort of %2 related to the indication. The methods used are detailed in %3. For specific developments (new list of genes, indications, etc…) please contact the AMoNet team %4.</translation>
    </message>
    <message>
        <source>PATIENT</source>
        <translation>PATIENT</translation>
    </message>
    <message>
        <source>ENTER_LAST_NAME</source>
        <translation>Last name</translation>
    </message>
    <message>
        <source>ENTER_FIRST_NAME</source>
        <translation>First name</translation>
    </message>
    <message>
        <source>ENTER_ID</source>
        <translation>Patient ID</translation>
    </message>
    <message>
        <source>ENTER_CLINICAL_INFOS</source>
        <translation>Clinical information</translation>
    </message>
</context>
<context>
    <name>ErrorPopup</name>
    <message>
        <source>ERROR</source>
        <translation>Error</translation>
    </message>
    <message>
        <source>VALID</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>FirstPageView</name>
    <message>
        <source>PATIENT_MUTATION</source>
        <translation>PATIENT MUTATION DATA</translation>
    </message>
    <message>
        <source>SEARCH_A_GENE</source>
        <translation>Gene name (HUGO nomenclature)</translation>
    </message>
    <message>
        <source>CHOOSE_PATIENT_DATA</source>
        <translation>Patient mutation data file</translation>
    </message>
    <message>
        <source>THERAPY</source>
        <translation>THERAPY</translation>
    </message>
    <message>
        <source>COMPUTE</source>
        <translation>LAUNCH PREDICTION</translation>
    </message>
    <message>
        <source>LOAD</source>
        <translation>Load from file</translation>
    </message>
    <message>
        <source>ADVANCED</source>
        <translation>Advanced</translation>
    </message>
</context>
<context>
    <name>LoadingPopup</name>
    <message>
        <source>LOADING</source>
        <translation>Predicting...</translation>
    </message>
</context>
<context>
    <name>MutationComboBox</name>
    <message>
        <source>NO_MUTATION</source>
        <translation>No mutation</translation>
    </message>
    <message>
        <source>NON_PATHOGENIC_MUTATION</source>
        <translation>Non pathogenic mutation</translation>
    </message>
    <message>
        <source>UNKNOWN_PATHOGENIC_MUTATION</source>
        <translation>Mutation of unknown pathogenicity</translation>
    </message>
    <message>
        <source>PATHOGENIC_MUTATION</source>
        <translation>Pathogenic mutation</translation>
    </message>
</context>
<context>
    <name>PredictionGraphView</name>
    <message>
        <source>SURVIVAL_TIME_IN_MONTH</source>
        <translation>Time (months)</translation>
    </message>
    <message>
        <source>SURVIVAL_RATE_IN_%</source>
        <translation>Survival probability (%)</translation>
    </message>
</context>
<context>
    <name>SecondPageView</name>
    <message>
        <source>GRAPH_TITLE</source>
        <translation>SURVIVAL CURVE</translation>
    </message>
    <message>
        <source>LAST_CONVERGENCE_VALUE_TEXT - %1%</source>
        <translation>Update of output nodes in last iteration: %1%</translation>
    </message>
    <message>
        <source>MODIFY</source>
        <translation>Modify data</translation>
    </message>
    <message>
        <source>SAVE_RESULTS</source>
        <translation>Save</translation>
    </message>
    <message>
        <source>CHOOSE_A_FOLDER</source>
        <translation>Save directory</translation>
    </message>
</context>
<context>
    <name>TherapyItem</name>
    <message>
        <source>INHIBITION</source>
        <translation>Inhibition</translation>
    </message>
    <message>
        <source>ACTIVATION</source>
        <translation>Activation</translation>
    </message>
    <message>
        <source>UNKNOWN</source>
        <translation>Error</translation>
    </message>
</context>
<context>
    <name>gui::ExporterModel</name>
    <message>
        <source>NO_THERAPY</source>
        <translation>No therapy</translation>
    </message>
</context>
<context>
    <name>gui::MutationsModel</name>
    <message>
        <source>ERROR_READ_FILE</source>
        <translation>Could not read the file. Please refer to the user manual for details on file format or contact the support.</translation>
    </message>
</context>
<context>
    <name>gui::TherapyModel</name>
    <message>
        <source>NO_THERAPY</source>
        <translation>No therapy</translation>
    </message>
    <message>
        <source>ERROR_READ_FILE</source>
        <translation>Could not read the file. Please refer to the user manual for details on file format or contact the support.</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <source>AMONET</source>
        <translation type="vanished">AMoNet_EN</translation>
    </message>
    <message>
        <source>CANT_LOAD_NETWORK</source>
        <translation>Could not read the trained model. Please refer to the user manual for details or contact the support.</translation>
    </message>
    <message>
        <source>CANT_LOAD_TIMES_INTERVAL</source>
        <translation>Could not read the training data. Please refer to the user manual for details or contact the support.</translation>
    </message>
</context>
</TS>
