//! \file PredictionComputationTestU.cpp
//! \brief Implements PredictionComputationTestU
//! \author http://www.surgiqual-institute.com/
//! \date SomeMonth SomeYear

// Qt
#include <qdebug.h>
#include <qstring.h>
#include <qmap.h>
#include <qloggingcategory.h>
// Project
#include "PredictionComputationTestU.h"
#include "io/Importer.h"
#include "data/NetworkStateData.h"
#include "data/MutationType.h"

//---------------------------------------------------------------------------------
PredictionComputationTestU::PredictionComputationTestU()
    : m_precision{1e-4}
{
    QString filePath = "data/encrypted_AMoNet_network.csv";
	QString decryptedData = io::Importer::decryptNetworkData(filePath);
	m_network = std::make_shared<data::NetworkData>(decryptedData);
	m_valMut = 100;
	m_minStepForward = 10;
}


////////////////////
// PUBLIC METHODS //
////////////////////

//---------------------------------------------------------------------------------
void PredictionComputationTestU::setUp()
{
}


//---------------------------------------------------------------------------------
void PredictionComputationTestU::tearDown()
{
}



///////////
// TESTS //
///////////


//---------------------------------------------------------------------------------
void PredictionComputationTestU::test_prediction()
{
	// wait for the network to be fully loaded
	while (!m_network->getIsLoadingSuccessful()) {}
	auto MUT = io::Importer::loadTestPatientsDataFromCSV("data/test_patients_MUT.csv");
	auto output = io::Importer::loadTestPatientsDataFromCSV("data/test_patients_outputs.csv");
	auto patients = MUT.keys();
	QMap<QString, QMap<QString, double>> computedOutput;
	auto netGenes = m_network->getGenesNames();

	for (int i = 0; i < MUT.size(); i++)
	{
		auto currentMUT = MUT.value(patients.at(i));
		auto genes = currentMUT.keys();

		// update network for the current patient
		for (int j = 0; j < netGenes->size(); j++)
		{
			int index = genes.indexOf(netGenes->at(j));
			if (index >= 0)
			{
				m_network->modifyGeneMutation(j, currentMUT.value(genes.at(index)));
			}
		}

		// compute the output data
		computedOutput.insert(patients.at(i), algo::PredictionComputation::predictSurvivalRate(m_network, m_valMut, m_minStepForward).toQMap());
	}
	
	for (int i = 0; i < patients.size(); i++)
	{
		// check error for each patient
		checkError(output.value(patients.at(i)), computedOutput.value(patients.at(i)));
	}
}

void PredictionComputationTestU::checkError(const QMap<QString, double>& p_pred1, const QMap<QString, double>& p_pred2)
{
	auto names = p_pred1.keys();
	for (int i = 0; i < names.size(); i++)
	{
		// compute the relative error
		double error = abs(p_pred2.value(names.at(i)) - p_pred1.value(names.at(i)));
		CPPUNIT_ASSERT(error < m_precision);
	}
}
