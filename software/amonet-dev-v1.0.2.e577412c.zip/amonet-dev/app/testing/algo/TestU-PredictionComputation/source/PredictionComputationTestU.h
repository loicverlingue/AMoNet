#ifndef _PredictionComputationTestU_ 
#define _PredictionComputationTestU_
 
//! \file PredictionComputationTestU.h
//! \brief Defines PredictionComputationTestU
//! \author http://www.surgiqual-institute.com/
//! \date SomeMonth SomeYear


// CppUnit
#include <cppunit/extensions/HelperMacros.h>

// Qt
#include <qstring.h>
#include <qmap.h>
// Add dependencies here
#include "data/NetworkData.h"

// Project - CUT (Class Under Test)
#include "algo/PredictionComputation.h"


//-----------------------------------------------------------------------------
//! \class PredictionComputationTestU
//! \brief ...
class PredictionComputationTestU : public CppUnit::TestFixture
{    
    CPPUNIT_TEST_SUITE(PredictionComputationTestU);

    // Register tests
    CPPUNIT_TEST(test_prediction);
   
    CPPUNIT_TEST_SUITE_END();


    // constr / destr / operator
public:
    //! \brief Default constructor
    explicit PredictionComputationTestU();

    //! \brief Default destructor
    virtual ~PredictionComputationTestU() = default;

    // methods / functions
public:
    //! \brief Set up context before running a test.
    virtual void setUp();

    //! \brief Clean up after the test run.
    virtual void tearDown();

protected:
private:


    // tests
private:
    void test_prediction();

    // methods
    //! \brief check if the error between 2 predictions 
    void checkError(const QMap<QString, double>& p_pred1, const QMap<QString, double>& p_pred2);
    // members
protected:
private:
    //! \brief Threshold for floating-point numbers comparisons.
    double m_precision;

    // \brief Min number of iteractions
    int m_minStepForward;

    //! \brief Mutation coefficient
    double m_valMut;

    //! \brief Network data
    std::shared_ptr<data::NetworkData> m_network = std::make_shared<data::NetworkData>();
};

#endif // _PredictionComputationTestU_
