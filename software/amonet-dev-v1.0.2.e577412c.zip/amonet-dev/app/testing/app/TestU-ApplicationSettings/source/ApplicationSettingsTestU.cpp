//! \file ApplicationSettingsTestU.cpp
//! \brief Implements ApplicationSettingsTestU
//! \author http://www.surgiqual-institute.com/
//! \date SomeMonth SomeYear

// Qt
#include <qdebug.h>

// Project
#include "ApplicationSettingsTestU.h"


//---------------------------------------------------------------------------------
ApplicationSettingsTestU::ApplicationSettingsTestU()
    : m_precision{1e-4}
{
}


////////////////////
// PUBLIC METHODS //
////////////////////

//---------------------------------------------------------------------------------
void ApplicationSettingsTestU::setUp()
{
}


//---------------------------------------------------------------------------------
void ApplicationSettingsTestU::tearDown()
{
}



///////////
// TESTS //
///////////


//---------------------------------------------------------------------------------
void ApplicationSettingsTestU::test_loadSettings()
{
    // New line after the test name
    qInfo() << "";

    // Data
    QString filePath("data/test.ini");
    app::ApplicationSettings appSettings;
    std::shared_ptr<QSettings> settings = std::make_shared<QSettings>();

    // Compute
    CPPUNIT_ASSERT_NO_THROW(app::ApplicationSettings::LOAD_SETTINGS(filePath, &settings));

    // Check
    QString stringValue = app::ApplicationSettings::GET_SETTINGS_VALUE<QString>("test/stringValue", settings);
    CPPUNIT_ASSERT(QStringLiteral("TEST") == stringValue);
    int numberValue = app::ApplicationSettings::GET_SETTINGS_VALUE<int>("test/numberValue", settings);
    CPPUNIT_ASSERT_EQUAL(42, numberValue);
}

//---------------------------------------------------------------------------------
void ApplicationSettingsTestU::test_loadNoFile()
{
    // New line after the test name
    qInfo() << "";

    // Data
    QString filePath("unexistent/file/path");
    app::ApplicationSettings appSettings;
    std::shared_ptr<QSettings> settings = std::make_shared<QSettings>();

    // Compute
    CPPUNIT_ASSERT_THROW(app::ApplicationSettings::LOAD_SETTINGS(filePath, &settings), std::logic_error);

    // Check
}
