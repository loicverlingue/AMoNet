
// std
#include <iostream>

// CppUnit
#include <cppunit/TestCase.h>
#include <cppunit/TestFixture.h>
#include <cppunit/ui/text/TextTestRunner.h>
#include <cppunit/extensions/HelperMacros.h>
#include <cppunit/extensions/TestFactoryRegistry.h>
#include <cppunit/TestResult.h>
#include <cppunit/TestResultCollector.h>
#include <cppunit/TestRunner.h>
#include <cppunit/BriefTestProgressListener.h>
#include <cppunit/TextTestProgressListener.h>
#include <cppunit/CompilerOutputter.h>
#include <cppunit/XmlOutputter.h>
#include <cppunit/TextOutputter.h>

// Qt
#include <qdatetime.h>
#include <qcoreapplication.h>
#include <qfile.h>
#include <qtextstream.h>

// Project - CUT (Class Under Test)
#include "ApplicationSettingsTestU.h"


//-----------------------------------------------------------------------------
CPPUNIT_TEST_SUITE_REGISTRATION(ApplicationSettingsTestU);
int main(int argc, char* argv[])
{
#if defined(_MSC_VER) && defined(_DEBUG)
    _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#endif

    // informs test-listener about testresults
    CppUnit::TestResult testresult;

    // register listener for collecting the test-results
    CppUnit::TestResultCollector collectedresults;
    testresult.addListener(&collectedresults);

    // register listener for per-test progress output
    CppUnit::BriefTestProgressListener progress;
    testresult.addListener(&progress);

    // insert test-suite at test-runner by registry
    CppUnit::TestRunner testrunner;
    testrunner.addTest(CppUnit::TestFactoryRegistry::getRegistry().makeTest());
    testrunner.run(testresult);
    
    // output results in compiler-format
    CppUnit::CompilerOutputter compileroutputter(&collectedresults, std::cerr);
    compileroutputter.write();

    // Output XML for Jenkins CPPunit plugin
    //
    //   For now, infos are put in the name of the file. But to see how continuous
    // integration will be made, those infos may go in the xml file (as in astek),
    // or not (if jenkins does not allow it).
    QString xmlLogFileName = "Log/Log" + (QDateTime::currentDateTime()).toString("yyyyMMddhhmmsszzz");

#ifndef NDEBUG
    xmlLogFileName += "_Debug";
#else
    xmlLogFileName += "_Release";
#endif

#ifdef _MSC_VER
#if defined( _MSC_VER ) && ( _MSC_VER <= 1800 )
#pragma warning( disable: 4996 )
#endif
    {
        std::string ideName = "VS";
#if (_MSC_VER == 1800)
        {
            ideName += "2013";
        }
#endif
        xmlLogFileName = xmlLogFileName + "_" + QString(ideName.c_str());

        xmlLogFileName = xmlLogFileName + "_" + QString(getenv("USERNAME"));
    }
#if defined( _MSC_VER ) && ( _MSC_VER <= 1800 )
#pragma warning( default: 4996 )
#endif
#endif

    std::ofstream xmlFileOut(xmlLogFileName.toStdString() + ".xml");
    CppUnit::XmlOutputter xmlOut(&collectedresults, xmlFileOut);
    xmlOut.write();

    int returnValue = (collectedresults.wasSuccessful()) ? EXIT_SUCCESS : EXIT_FAILURE;
    return returnValue;
}

