#ifndef _ApplicationSettingsTestU_ 
#define _ApplicationSettingsTestU_
 
//! \file ApplicationSettingsTestU.h
//! \brief Defines ApplicationSettingsTestU
//! \author http://www.surgiqual-institute.com/
//! \date SomeMonth SomeYear


// CppUnit
#include <cppunit/extensions/HelperMacros.h>

// Add dependencies here

// Project - CUT (Class Under Test)
#include "app/ApplicationSettings.h"


//-----------------------------------------------------------------------------
//! \class ApplicationSettingsTestU
//! \brief ...
class ApplicationSettingsTestU : public CppUnit::TestFixture
{    
    CPPUNIT_TEST_SUITE(ApplicationSettingsTestU);

    // Register tests
    CPPUNIT_TEST(test_loadSettings);
    CPPUNIT_TEST(test_loadNoFile);
   
    CPPUNIT_TEST_SUITE_END();


    // constr / destr / operator
public:
    //! \brief Default constructor
    explicit ApplicationSettingsTestU();

    //! \brief Default destructor
    virtual ~ApplicationSettingsTestU() = default;

    // methods / functions
public:
    //! \brief Set up context before running a test.
    virtual void setUp();

    //! \brief Clean up after the test run.
    virtual void tearDown();

protected:
private:


    // tests
private:
    void test_loadSettings();
    void test_loadNoFile();


    // members
protected:
private:
    //! \brief Threshold for floating-point numbers comparisons.
    double m_precision;

};

#endif // _ApplicationSettingsTestU_
