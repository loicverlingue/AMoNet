Qt5LinguistTools cmake config override
========================================

The cmake files of the Qt5LinguistTools package are overriden because this bug:
https://bugreports.qt.io/browse/QTBUG-27936
