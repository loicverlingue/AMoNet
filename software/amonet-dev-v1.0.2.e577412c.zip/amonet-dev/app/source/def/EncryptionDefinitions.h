#ifndef _def_EncryptionDefinitions_
#define _def_EncryptionDefinitions_

//! \file EncryptionDefinitions.h
//! \brief Defines EncryptionDefinitions
//! \author http://www.surgiqual-institute.com/
//! \date March 2021


// Qt
#include <qglobal.h>


namespace def
{
    constexpr quint64 	  AMONET_ENCRYPT_KEY = Q_UINT64_C(0x6df60dd3d2117afa);
} // def

#endif // _def_EncryptionDefinitions_
