#ifndef _models_Registry_
#define _models_Registry_

//! \file Registry.h
//! \brief Defines Registry
//! \author http://www.surgiqual-institute.com/
//! \date December 2020


// Library dependencies

// Project dependencies


namespace gui
{
    //! \class Registry
    //! \brief ...
    class Registry
    {
        // constructor / destructor / operator
    public:
        //! \brief Default constructor
        explicit Registry() = delete;

        //! \brief Destructor
        virtual ~Registry() = delete;

        //! \brief Copy constructor
        //! \param[in] p_other Object to copy
        Registry(const Registry& p_other) = delete;

        //! \brief Copy assignment operator
        //! \param[in] p_other Object to copy
        Registry& operator=(const Registry& p_other) = delete;

        //! \brief Move constructor
        //! \param[in] p_other Object to move
        Registry(Registry&& p_other) = delete;

        //! \brief Move assignment operator
        //! \param[in] p_other Object to move
        Registry& operator=(Registry&& p_other) = delete;

        // get / set
    public:
    protected:
    private:

        // methods / functions / slots
    public:

        //! Registers the types of all the models
        static void REGISTER_QML_TYPES();

    protected:
    private:

        // members
    protected:
    private:

    };

} // gui

#endif // _models_Registry_
