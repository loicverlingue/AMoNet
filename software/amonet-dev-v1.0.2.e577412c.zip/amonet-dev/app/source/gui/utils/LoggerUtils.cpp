//! \file LoggerUtils.cpp
//! \brief Implements LoggerUtils
//! \author http://www.surgiqual-institute.com/
//! \date May 2020

// Qt
#include <qqml.h>
#include <qdebug.h>
#include <qscreen.h>

// Project dependencies
#include "LoggerUtils.h"
#include "app/Application.h"
#include "io/LogService.h"
#include "io/Log.h"


namespace gui
{

    LoggerUtils::LoggerUtils(QObject* p_parent)
        : QObject(p_parent)
    {
    }

    void LoggerUtils::REGISTER_QML_TYPE()
    {
        qmlRegisterSingletonType<LoggerUtils>(
            "gui.utils", 1, 0, "Logger",
            [](QQmlEngine* engine, QJSEngine* scriptEngine) -> QObject*
            {
                Q_UNUSED(engine)
                Q_UNUSED(scriptEngine)

                return new LoggerUtils();
            }
        );
    }

    float LoggerUtils::getScreenWidth() const
    {
        return app::Application::instance()->primaryScreen()->size().width();
    }

    float LoggerUtils::getScreenHeight() const
    {
        return app::Application::instance()->primaryScreen()->size().height();
    }

    float LoggerUtils::getDpiRatio() const
    {
        qInfo() << app::Application::instance()->primaryScreen()->logicalDotsPerInch();
        return 120.0 / app::Application::instance()->primaryScreen()->logicalDotsPerInch();
    }

    float LoggerUtils::getScreenPixelRatio() const
    {
        qInfo() << app::Application::instance()->primaryScreen()->size().width();
        qInfo() << app::Application::instance()->primaryScreen()->size().height();
        return std::min(app::Application::instance()->primaryScreen()->size().width() / 1920.0, app::Application::instance()->primaryScreen()->size().height() / 1080.0);
    }

    void LoggerUtils::debug(const QString& p_msg)
    {
        io::LogService::getInstance().LogDebug(p_msg);
    }

    void LoggerUtils::info(const QString& p_msg)
    {
        io::LogService::getInstance().LogInfo(p_msg);
    }

    void LoggerUtils::warning(const QString& p_msg)
    {
        io::LogService::getInstance().LogWarning(p_msg);
    }

    void LoggerUtils::error(const QString& p_msg)
    {
        io::LogService::getInstance().LogError(p_msg);
    }

} // gui
