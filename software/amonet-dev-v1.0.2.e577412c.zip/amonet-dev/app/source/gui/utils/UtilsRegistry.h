#ifndef _gui_UtilsRegistry_
#define _gui_UtilsRegistry_

//! \file UtilsRegistry.h
//! \brief Defines UtilsRegistry
//! \author http://www.surgiqual-institute.com/
//! \date February 2020


// Library dependencies

// Project dependencies


namespace gui
{
    //! \class UtilsRegistry
    //! \brief Static class for registering utils types to teh QML engine.
    class UtilsRegistry
    {
        // constructor / destructor / operator
    public:
        //! \brief Default constructor
        explicit UtilsRegistry() = delete;

        //! \brief Destructor
        virtual ~UtilsRegistry() = delete;

        //! \brief Copy constructor
        //! \param[in] p_other Object to copy
        UtilsRegistry(const UtilsRegistry& p_other) = delete;

        //! \brief Copy assignment operator
        //! \param[in] p_other Object to copy
        UtilsRegistry& operator=(const UtilsRegistry& p_other) = delete;

        //! \brief Move constructor
        //! \param[in] p_other Object to move
        UtilsRegistry(UtilsRegistry&& p_other) = delete;

        //! \brief Move assignment operator
        //! \param[in] p_other Object to move
        UtilsRegistry& operator=(UtilsRegistry&& p_other) = delete;

        // get / set
    public:
    protected:
    private:

        // methods / functions / slots
    public:

        //! Registers the types of all the models
        static void REGISTER_QML_TYPES();

    protected:
    private:

        // members
    protected:
    private:

    };

} // gui

#endif // _gui_UtilsRegistry_
