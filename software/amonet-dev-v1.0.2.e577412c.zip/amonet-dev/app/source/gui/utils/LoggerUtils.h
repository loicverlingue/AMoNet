#ifndef _gui_LoggerUtils_
#define _gui_LoggerUtils_

//! \file LoggerUtils.h
//! \brief Defines LoggerUtils
//! \author http://www.surgiqual-institute.com/
//! \date May 2020


// Qt
#include <qobject.h>

// Project dependencies


namespace gui
{
    //! \class LoggerUtils
    //! \brief Exposes the log functions to the QML
    class LoggerUtils : public QObject
    {
        Q_OBJECT
           
            Q_PROPERTY(float screenWidth READ getScreenWidth CONSTANT)
            Q_PROPERTY(float screenHeight READ getScreenHeight CONSTANT)
            Q_PROPERTY(float dpiRatio READ getDpiRatio CONSTANT)
            Q_PROPERTY(float screenPixelRatio READ getScreenPixelRatio CONSTANT)

            // constructor / destructor / operator
    public:
        //! \brief Default constructor
        explicit LoggerUtils(QObject* p_parent = nullptr);

        //! \brief Destructor
        virtual ~LoggerUtils() = default;

        //! \brief Copy constructor
        //! \param[in] p_other Object to copy
        LoggerUtils(const LoggerUtils& p_other) = default; // To implement if copying is non-trivial

        //! \brief Copy assignment operator
        //! \param[in] p_other Object to copy
        LoggerUtils& operator=(const LoggerUtils& p_other) = default; // To implement if copying is non-trivial

        //! \brief Move constructor
        //! \param[in] p_other Object to move
        LoggerUtils(LoggerUtils&& p_other) = default; // To implement if moving is non trivial

        //! \brief Move assignment operator
        //! \param[in] p_other Object to move
        LoggerUtils& operator=(LoggerUtils&& p_other) = default; // To implement if moving is non trivial

        // get / set
    public:
        float getScreenWidth() const;
        float getScreenHeight() const;
        float getDpiRatio() const;
        float getScreenPixelRatio() const;
    protected:
    private:

        // methods / functions
    public:

        //! \brief Registers this class as a QML type
        static void REGISTER_QML_TYPE();

        //! \brief Logs a debug message
        //! \param[in] p_msg Message to log
        Q_INVOKABLE void debug(const QString &p_msg);

        //! \brief Logs a info message
        //! \param[in] p_msg Message to log
        Q_INVOKABLE void info(const QString &p_msg);

        //! \brief Logs a warning message
        //! \param[in] p_msg Message to log
        Q_INVOKABLE void warning(const QString &p_msg);

        //! \brief Logs a error message
        //! \param[in] p_msg Message to log
        Q_INVOKABLE void error(const QString &p_msg);

    protected:
    private:

        // signals
    signals:

        // slots
    public slots:


        // members
    protected:
    private:

    };

} // gui

#endif // _gui_LoggerUtils_

