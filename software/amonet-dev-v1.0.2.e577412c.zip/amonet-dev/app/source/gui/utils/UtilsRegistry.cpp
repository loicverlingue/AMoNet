//! \file UtilsRegistry.cpp
//! \brief Implements UtilsRegistry
//! \author http://www.surgiqual-institute.com/
//! \date February 2020


// Library dependencies

// Project dependencies
#include "UtilsRegistry.h"
#include "gui/utils/LoggerUtils.h"

namespace gui
{

    void UtilsRegistry::REGISTER_QML_TYPES()
    {
        LoggerUtils::REGISTER_QML_TYPE();
    }

} // gui
