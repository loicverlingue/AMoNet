#ifndef _gui_SurvivalModel_
#define _gui_SurvivalModel_

//! \file SurvivalModel.h
//! \brief Defines SurvivalModel
//! \author http://www.surgiqual-institute.com/
//! \date April 2021


// Qt
#include <qobject.h>
#include <qqml.h>
// Project dependencies
#include "data/PatientData.h"

namespace gui
{
    //! \class SurvivalModel
    //! \brief handles the  survival data for PredictionGraphView.qml
    class SurvivalModel : public QObject
    {
        Q_OBJECT
            Q_PROPERTY(QVariantList survivalPred READ getSurvivalPred NOTIFY signalSurvivalPredChanged)
            Q_PROPERTY(int monthPerScale READ getMonthPerScale NOTIFY signalSurvivalPredChanged)
            Q_PROPERTY(int percentPerScale READ getPercentPerScale NOTIFY signalSurvivalPredChanged)
            Q_PROPERTY(QString therapyName READ getTherapyName NOTIFY signalTherapyNameChanged)
            Q_PROPERTY(double lastConvergence READ getLastConvergence NOTIFY signalLastConvergenceChanged)

        // constructor / destructor / operator
    public:
        //! \brief Default constructor
        explicit SurvivalModel(QObject* p_parent = nullptr);

        //! \brief Destructor
        virtual ~SurvivalModel() = default;

        //! \brief Copy constructor
        //! \param[in] p_other Object to copy
        SurvivalModel(const SurvivalModel& p_other) = default; // To implement if copying is non-trivial

        //! \brief Copy assignment operator
        //! \param[in] p_other Object to copy
        SurvivalModel& operator=(const SurvivalModel& p_other) = default; // To implement if copying is non-trivial

        //! \brief Move constructor
        //! \param[in] p_other Object to move
        SurvivalModel(SurvivalModel&& p_other) = default; // To implement if moving is non trivial

        //! \brief Move assignment operator
        //! \param[in] p_other Object to move
        SurvivalModel& operator=(SurvivalModel&& p_other) = default; // To implement if moving is non trivial

        // get / set
    public:
        [[nodiscard]]
        //! \brief get the survival prediction
        QVariantList getSurvivalPred() const;

        [[nodiscard]]
        //! \brief get the nb of months per scale
        int getMonthPerScale() const;

        [[nodiscard]]
        //! \brief get the nb of percent per scale
        int getPercentPerScale() const;

        [[nodiscard]]
        //! \brief get the therapy name
        QString getTherapyName() const;

        [[nodiscard]]
        //! \brief get the total convergence
        double getLastConvergence() const;
    protected:
    private:

    signals:
        void signalSurvivalPredChanged();

        void signalTherapyNameChanged();

        void signalLastConvergenceChanged();

        // methods / functions / slots
    public:
        //! \brief register qml type
        static void REGISTER_QML_TYPE();
    protected:
    private:
        //! \brief init the survival prediction
        void initSurvivalPred();

        //! \brief update the survival prediction
        void slotUpdateSurvivalPred();

        // members
    protected:
    private:
        //! \brief patient data
        std::shared_ptr<data::PatientData> m_patientData;

        //! \brief display info : months per scale
        int m_graphMonthPerScale;

        //! \brief display info : percent per scale
        int m_graphPercentPerScale;

        //! \brief survival prediction (list of pairs <month,survivalValue>)
        QVariantList m_survivalPred;

        double m_lastConvergence;
    };

} // gui

#endif // _gui_SurvivalModel_
