#ifndef _gui_PatientModel_
#define _gui_PatientModel_

//! \file PatientModel.h
//! \brief Defines PatientModel
//! \author http://www.surgiqual-institute.com/
//! \date March 2021.


// Library dependencies
#include <qobject.h>
#include <qstring.h>
#include <qqml.h>
// Project dependencies
#include "data/PatientData.h"

namespace gui
{
    //! \class PatientModel
    //! \brief Handle the patient info data
    class PatientModel : public QObject
    {
        Q_OBJECT
            Q_PROPERTY(QString lastName READ getLastName WRITE setLastName NOTIFY signalLastNameChanged)
            Q_PROPERTY(QString firstName READ getFirstName WRITE setFirstName NOTIFY signalFirstNameChanged)
            Q_PROPERTY(QString identifier READ getIdentifier WRITE setIdentifier NOTIFY signalIdentifierChanged)
            Q_PROPERTY(QString clinicalInfo READ getClinicalInfo WRITE setClinicalInfo NOTIFY signalClinicalInfoChanged)

        // constructor / destructor / operator
    public:
        //! \brief Default constructor
        explicit PatientModel(QObject* p_parent = nullptr);

        //! \brief Destructor
        virtual ~PatientModel() = default;

        //! \brief Copy constructor
        //! \param[in] p_other Object to copy
        PatientModel(const PatientModel& p_other) = default; // To implement if copying is non-trivial

        //! \brief Copy assignment operator
        //! \param[in] p_other Object to copy
        PatientModel& operator=(const PatientModel& p_other) = default; // To implement if copying is non-trivial

        //! \brief Move constructor
        //! \param[in] p_other Object to move
        PatientModel(PatientModel&& p_other) = default; // To implement if moving is non trivial

        //! \brief Move assignment operator
        //! \param[in] p_other Object to move
        PatientModel& operator=(PatientModel&& p_other) = default; // To implement if moving is non trivial

        // get / set
    public:
        //! \brief set the patient's last name
        //! \param p_lastName the patient's last name
        void setLastName(const QString& p_lastName);

        //! \brief set the patient's first name
        //! \param p_firstName the patient's first name
        void setFirstName(const QString& p_firstName);

        //! \brief set the patient's identifier
        //! \param p_indentifier the patient's identifier
        void setIdentifier(const QString& p_indentifier);

        //! \brief set the patient's clinical information
        //! \param p_info the patient's clinical information
        void setClinicalInfo(const QString& p_info);

        [[nodiscard]]
        QString getLastName() const;
        [[nodiscard]]
        QString getFirstName() const;
        [[nodiscard]]
        QString getIdentifier() const;
        [[nodiscard]]
        QString getClinicalInfo() const;

    protected:
    private:

        // methods / functions / slots
    public:
        //! \brief register qml type
        static void REGISTER_QML_TYPE();
    protected:
    private:


    signals:
        void signalLastNameChanged();
        void signalFirstNameChanged();
        void signalIdentifierChanged();
        void signalClinicalInfoChanged();

    public slots:
        //! \brief save the patient data
        void slotSaveData();

        // members
    protected:
    private:
        //! \brief Patient's last name
        QString m_lastName = "";

        //! \brief Patient's first name
        QString m_firstName = "";

        //! \brief Patient's id
        QString m_identifier = "";

        //! \brief Patient's clinical informations
        QString m_clinicalInfo = "";

        //! \brief Network data
        std::shared_ptr<data::PatientData> m_patientData;
    };

} // gui

#endif // _gui_PatientModel_
