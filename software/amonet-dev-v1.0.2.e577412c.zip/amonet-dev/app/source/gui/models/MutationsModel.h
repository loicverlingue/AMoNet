#ifndef _gui_MutationsModel_
#define _gui_MutationsModel_

//! \file MutationsModel.h
//! \brief Defines MutationsModel
//! \author http://www.surgiqual-institute.com/
//! \date March 2021.


// Library dependencies
#include <qobject.h>
#include <qqml.h>
#include <qfuturesynchronizer.h>

// Project dependencies
#include "app/Locator.h"
#include "data/NetworkData.h"
#include "data/MutationType.h"

namespace gui
{
    //! \class MutationsModel
    //! \brief Model used to handle the UI interaction with patient's genes and mutations
    class MutationsModel : public QObject
    {
        Q_OBJECT
            Q_PROPERTY(QVariantList geneList READ getGeneList NOTIFY signalGeneListChanged)
            Q_PROPERTY(QString error READ getError NOTIFY signalErrorChanged)
            Q_PROPERTY(bool isLoadingSuccessful READ getIsLoadingSuccessful NOTIFY signalIsLoadingSuccessful)

        // constructor / destructor / operator
    public:
        //! \brief Default constructor
        explicit MutationsModel(QObject* p_parent = nullptr);

        //! \brief Destructor
        virtual ~MutationsModel() = default;

        //! \brief Copy constructor
        //! \param[in] p_other Object to copy
        MutationsModel(const MutationsModel& p_other) = default; // To implement if copying is non-trivial

        //! \brief Copy assignment operator
        //! \param[in] p_other Object to copy
        MutationsModel& operator=(const MutationsModel& p_other) = default; // To implement if copying is non-trivial

        //! \brief Move constructor
        //! \param[in] p_other Object to move
        MutationsModel(MutationsModel&& p_other) = default; // To implement if moving is non trivial

        //! \brief Move assignment operator
        //! \param[in] p_other Object to move
        MutationsModel& operator=(MutationsModel&& p_other) = default; // To implement if moving is non trivial

        // get / set
    public:
        [[nodiscard]]
        //! \brief get the gene list
        //! \return the gene list
        QVariantList getGeneList() const;

        [[nodiscard]]
        QString getError() const;

        [[nodiscard]]
        bool getIsLoadingSuccessful() const;

    protected:
    private:



    signals:
        void signalGeneTypeChanged();
        void signalGeneValueChanged();
        void signalGeneListChanged();
        void signalComputationEnded();
        void signalErrorChanged();
        void signalIsLoadingSuccessful();
    public slots:
        //! \brief update the gene mutation (of the gene list)
        //! \param p_geneIndex index of the gene in the list
        //! \param p_mutationType type of the new mutation
        void slotUpdateGeneMutationType(int p_geneIndex, int p_mutationType);

        //! \brief update the gene mutation (of the gene list)
        //! \param p_geneIndex index of the gene in the list
        //! \param p_mutationValue value of the new mutation
        void slotUpdateGeneMutationValue(int p_geneIndex, float p_mutationValue);

        //! \brief import the patient's mutations from a file
        //! \param p_path path of the file containing the patient's mutations
        void slotImportPatientMutations(const QUrl& p_path);

        //! \brief run the prediction from the mutation data
        void slotComputePrediction();

        // methods / functions / slots
    public:
        //! \brief register qml type
        static void REGISTER_QML_TYPE();
        
    protected:
    private:
        //! \brief initialize the gene list
        void initGeneList();

        //! \brief update the network data
        void slotUpdateNetworkData();

        //! \brief save the gene mutation (in the network data)
        void saveGenesMutations();

        // members
    protected:
    private:
        //! \brief Network data
        std::shared_ptr<data::NetworkData> m_networkData;

        //! \brief gene list
        QVariantList m_geneList;

        //! \brief loading synchroniser
        QFutureSynchronizer<void> m_loadingSynchro;

        //! \brief path to the training data genes.
        QString m_trainingDataGenesPath;

        //! \brief error that occured
        QString m_error;

        //! \brief true if the network is successfully loaded
        bool m_isLoadingSuccessful = false;
    };

} // gui

#endif // _gui_MutationsModel_
