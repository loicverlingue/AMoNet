//! \file LoadModelError.cpp
//! \brief Implements LoadModelError
//! \author http://www.surgiqual-institute.com/
//! \date Jully 2021.


// Library dependencies

// Project dependencies
#include "LoadModelError.h"
#include "app/Locator.h"

namespace gui
{

    LoadModelError::LoadModelError(QObject* p_parent)
        : QObject{p_parent},
        m_patientData{app::Locator::getPatient()},
        m_networkData{app::Locator::getNetwork()}
    {
    }

    bool LoadModelError::getIsPatientDataLoaded() const
    {
        return m_patientData->getIsLoadingSuccessful();
    }

    bool LoadModelError::getIsNetworkDataLoaded() const
    {
        return m_networkData->getIsLoadingSuccessful();
    }

    void LoadModelError::REGISTER_QML_TYPE()
    {
        qmlRegisterSingletonType<LoadModelError>(
            "gui.models", 1, 0, "LoadModelError",
            [](QQmlEngine* engine, QJSEngine* scriptEngine) -> QObject*
            {
                Q_UNUSED(engine)
                    Q_UNUSED(scriptEngine)

                    return new LoadModelError();
            }
        );
    }
} // gui


