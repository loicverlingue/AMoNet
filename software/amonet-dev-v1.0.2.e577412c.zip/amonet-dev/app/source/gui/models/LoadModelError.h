#ifndef _gui_LoadModelError_
#define _gui_LoadModelError_

//! \file LoadModelError.h
//! \brief Defines LoadModelError
//! \author http://www.surgiqual-institute.com/
//! \date Jully 2021.


// Library dependencies
#include <qobject.h>
#include <qstring.h>
#include <qqml.h>
// Project dependencies
#include "data/PatientData.h"
#include "data/NetworkData.h"

namespace gui
{
    //! \class LoadModelError
    //! \brief Handle the load error
    class LoadModelError : public QObject
    {
        Q_OBJECT
            Q_PROPERTY(bool isPatientDataLoaded READ getIsPatientDataLoaded NOTIFY signalIsPatientDataLoaded)
            Q_PROPERTY(bool isNetworkDataLoaded READ getIsNetworkDataLoaded NOTIFY signalIsNetworkDataLoaded)

        // constructor / destructor / operator
    public:
        //! \brief Default constructor
        explicit LoadModelError(QObject* p_parent = nullptr);

        //! \brief Destructor
        virtual ~LoadModelError() = default;

        //! \brief Copy constructor
        //! \param[in] p_other Object to copy
        LoadModelError(const LoadModelError& p_other) = default; // To implement if copying is non-trivial

        //! \brief Copy assignment operator
        //! \param[in] p_other Object to copy
        LoadModelError& operator=(const LoadModelError& p_other) = default; // To implement if copying is non-trivial

        //! \brief Move constructor
        //! \param[in] p_other Object to move
        LoadModelError(LoadModelError&& p_other) = default; // To implement if moving is non trivial

        //! \brief Move assignment operator
        //! \param[in] p_other Object to move
        LoadModelError& operator=(LoadModelError&& p_other) = default; // To implement if moving is non trivial

        // get / set
    public:

        [[nodiscard]]
        bool getIsPatientDataLoaded() const;
        [[nodiscard]]
        bool getIsNetworkDataLoaded() const;

    protected:
    private:

        // methods / functions / slots
    public:
        //! \brief register qml type
        static void REGISTER_QML_TYPE();
    protected:
    private:


    signals:
        void signalIsPatientDataLoaded();
        void signalIsNetworkDataLoaded();

    public slots:

        // members
    protected:
    private:
        //! \brief Patient data
        std::shared_ptr<data::PatientData> m_patientData;

        //! \brief Network data
        std::shared_ptr<data::NetworkData> m_networkData;
    };

} // gui

#endif // _gui_LoadModelError_
