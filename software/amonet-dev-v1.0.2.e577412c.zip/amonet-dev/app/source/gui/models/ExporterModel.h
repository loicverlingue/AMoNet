#ifndef _gui_ExporterModel_
#define _gui_ExporterModel_

//! \file ExporterModel.h
//! \brief Defines ExporterModel
//! \author http://www.surgiqual-institute.com/
//! \date April 2021


// Library dependencies
#include <qobject.h>
#include <qqml.h>
#include <qimage.h>
// Project dependencies


namespace gui
{
    //! \class ExporterModel
    //! \brief Handle the export of data
    class ExporterModel : public QObject
    {
        Q_OBJECT
        // constructor / destructor / operator
    public:
        //! \brief Default constructor
        explicit ExporterModel(QObject* p_parent = nullptr);

        //! \brief Destructor
        virtual ~ExporterModel() = default;

        //! \brief Copy constructor
        //! \param[in] p_other Object to copy
        ExporterModel(const ExporterModel& p_other) = default; // To implement if copying is non-trivial

        //! \brief Copy assignment operator
        //! \param[in] p_other Object to copy
        ExporterModel& operator=(const ExporterModel& p_other) = default; // To implement if copying is non-trivial

        //! \brief Move constructor
        //! \param[in] p_other Object to move
        ExporterModel(ExporterModel&& p_other) = default; // To implement if moving is non trivial

        //! \brief Move assignment operator
        //! \param[in] p_other Object to move
        ExporterModel& operator=(ExporterModel&& p_other) = default; // To implement if moving is non trivial

        // get / set
    public:
    protected:
    private:

    public slots:
        //! \bref save data (export)
        //! \param p_folderUrl path of the saving folder
        //! \param p_image image of the survival graph
        void slotSaveData(const QUrl& p_folderUrl, const QImage& p_image);

        // methods / functions / slots
    public:
        //! \brief register qml type
        static void REGISTER_QML_TYPE();
    protected:
    private:

        // members
    protected:
    private:

    };

} // gui

#endif // _gui_ExporterModel_
