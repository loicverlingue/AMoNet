//! \file SurvivalModel.cpp
//! \brief Implements SurvivalModel
//! \author http://www.surgiqual-institute.com/
//! \date April 2021


// Library dependencies

// Project dependencies
#include "SurvivalModel.h"
#include "app/Locator.h"
#include "app/ApplicationSettings.h"
#include "data/NetworkData.h"
namespace gui
{

    SurvivalModel::SurvivalModel(QObject* p_parent)
        :QObject{p_parent},
        m_patientData{app::Locator::getPatient()}
    {
        // load display settings
        m_graphMonthPerScale = app::Locator::getSettings()->getMainSettingsValue<int>("display/monthPerScale");
        m_graphPercentPerScale = app::Locator::getSettings()->getMainSettingsValue<int>("display/percentPerScale");

        ::QObject::connect(m_patientData.get(), &data::PatientData::signalSurvivalPredictionChanged, this, &SurvivalModel::slotUpdateSurvivalPred);
        initSurvivalPred();
    }

    void SurvivalModel::initSurvivalPred()
    {
        m_survivalPred.clear();
        int monthInterval = m_patientData->getIntervalDuration();
        auto survivalPredState = m_patientData->getSurvivalPrediction();
        if (!survivalPredState.getConvergenceValues().empty())
        {
            m_lastConvergence = 100 * survivalPredState.getConvergenceValues().back();
        }
        for (int i = 0; i < survivalPredState.getSize(); i++)
        {
            QVariantMap pair;
            pair.insert("month", i * monthInterval);
            pair.insert("value", 100*survivalPredState.getGeneState(survivalPredState.getGeneName(i)));
            m_survivalPred << pair;
        }
        emit signalSurvivalPredChanged();
        emit signalTherapyNameChanged();
        emit signalLastConvergenceChanged();
    }

    void SurvivalModel::slotUpdateSurvivalPred()
    {
        initSurvivalPred();
    }

    QVariantList SurvivalModel::getSurvivalPred() const
    {
        return m_survivalPred;
    }

    int SurvivalModel::getMonthPerScale() const
    {
        return m_graphMonthPerScale;
    }

    int SurvivalModel::getPercentPerScale() const
    {
        return m_graphPercentPerScale;
    }

    double SurvivalModel::getLastConvergence() const
    {
        return m_lastConvergence;
    }

    void SurvivalModel::REGISTER_QML_TYPE()
    {
        qmlRegisterType<SurvivalModel>("gui.models", 1, 0, "SurvivalModel");
    }

    QString SurvivalModel::getTherapyName() const
    {
        return app::Locator::getNetwork()->getTherapy()->getName();
    }

} // gui


