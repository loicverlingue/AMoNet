//! \file ModelsRegistry.cpp
//! \brief Implements ModelsRegistry
//! \author http://www.surgiqual-institute.com/
//! \date February 2020


// Library dependencies
#include <qqml.h>

// Project dependencies
#include "ModelsRegistry.h"
#include "gui/models/PatientModel.h"
#include "gui/models/MutationsModel.h"
#include "gui/models/SurvivalModel.h"
#include "gui/models/TherapyModel.h"
#include "gui/models/ExporterModel.h"
#include "gui/models/InformationsModel.h"
#include "gui/models/LoadModelError.h"
#include "data/MutationType.h"

namespace gui
{

    void ModelsRegistry::REGISTER_QML_TYPES()
    {
        PatientModel::REGISTER_QML_TYPE();
        MutationsModel::REGISTER_QML_TYPE();
        SurvivalModel::REGISTER_QML_TYPE();
        TherapyModel::REGISTER_QML_TYPE();
        ExporterModel::REGISTER_QML_TYPE();
        InformationsModel::REGISTER_QML_TYPE();
        LoadModelError::REGISTER_QML_TYPE();
        qmlRegisterUncreatableType<data::MutationTypeClass>("data.models", 1, 0, "MutationType", "Not creatable as it is an enum type");
    }

} // gui
