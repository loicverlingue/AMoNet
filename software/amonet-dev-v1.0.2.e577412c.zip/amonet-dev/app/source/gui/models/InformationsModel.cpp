//! \file InformationsModel.cpp
//! \brief Implements InformationsModel
//! \author http://www.surgiqual-institute.com/
//! \date Jully 2021.


// Library dependencies

// Project dependencies
#include "InformationsModel.h"
#include "app/Locator.h"
#include "app/ApplicationSettings.h"

namespace gui
{

    InformationsModel::InformationsModel(QObject* p_parent)
        : QObject{p_parent},
        m_publication{ app::Locator::getSettings()->getMainSettingsValue<QString>("informations/publication") },
        m_trainingData{ app::Locator::getSettings()->getMainSettingsValue<QString>("informations/trainingData") },
        m_supportMail{ app::Locator::getSettings()->getMainSettingsValue<QString>("informations/supportMail") }
    {
        QString language = app::Locator::getSettings()->getMainSettingsValue<QString>("languages/applicationLanguage");
        m_cancer = app::Locator::getSettings()->getMainSettingsValue<QString>("informations/cancer_" + language);
    }

    QString InformationsModel::getCancer() const
    {
        return m_cancer;
    }

    QString InformationsModel::getTrainingData() const
    {
        return m_trainingData;
    }

    QString InformationsModel::getPublication() const
    {
        return m_publication;
    }

    QString InformationsModel::getSupportMail() const
    {
        return m_supportMail;
    }

    void InformationsModel::REGISTER_QML_TYPE()
    {
        qmlRegisterSingletonType<InformationsModel>(
            "gui.models", 1, 0, "InformationsModel",
            [](QQmlEngine* engine, QJSEngine* scriptEngine) -> QObject*
            {
                Q_UNUSED(engine)
                    Q_UNUSED(scriptEngine)

                    return new InformationsModel();
            }
        );
    }
} // gui


