#ifndef _gui_InformationsModel_
#define _gui_InformationsModel_

//! \file InformationsModel.h
//! \brief Defines InformationsModel
//! \author http://www.surgiqual-institute.com/
//! \date Jully 2021.


// Library dependencies
#include <qobject.h>
#include <qstring.h>
#include <qqml.h>
// Project dependencies

namespace gui
{
    //! \class InformationsModel
    //! \brief Handle the application info data
    class InformationsModel : public QObject
    {
        Q_OBJECT
            Q_PROPERTY(QString cancer READ getCancer NOTIFY signalCancerChanged)
            Q_PROPERTY(QString trainingData READ getTrainingData NOTIFY signalTrainingDataChanged)
            Q_PROPERTY(QString publication READ getPublication NOTIFY signalPublicationChanged)
            Q_PROPERTY(QString supportMail READ getSupportMail NOTIFY signalSupportMailChanged)

        // constructor / destructor / operator
    public:
        //! \brief Default constructor
        explicit InformationsModel(QObject* p_parent = nullptr);

        //! \brief Destructor
        virtual ~InformationsModel() = default;

        //! \brief Copy constructor
        //! \param[in] p_other Object to copy
        InformationsModel(const InformationsModel& p_other) = default; // To implement if copying is non-trivial

        //! \brief Copy assignment operator
        //! \param[in] p_other Object to copy
        InformationsModel& operator=(const InformationsModel& p_other) = default; // To implement if copying is non-trivial

        //! \brief Move constructor
        //! \param[in] p_other Object to move
        InformationsModel(InformationsModel&& p_other) = default; // To implement if moving is non trivial

        //! \brief Move assignment operator
        //! \param[in] p_other Object to move
        InformationsModel& operator=(InformationsModel&& p_other) = default; // To implement if moving is non trivial

        // get / set
    public:

        [[nodiscard]]
        QString getCancer() const;
        [[nodiscard]]
        QString getTrainingData() const;
        [[nodiscard]]
        QString getPublication() const;
        [[nodiscard]]
        QString getSupportMail() const;

    protected:
    private:

        // methods / functions / slots
    public:
        //! \brief register qml type
        static void REGISTER_QML_TYPE();
    protected:
    private:


    signals:
        void signalCancerChanged();
        void signalTrainingDataChanged();
        void signalPublicationChanged();
        void signalSupportMailChanged();

    public slots:

        // members
    protected:
    private:
        //! \brief cancer name
        QString m_cancer = "";

        //! \brief publications
        QString m_publication = "";

        //! \brief training data
        QString m_trainingData = "";

        //! \brief support mail
        QString m_supportMail = "";
    };

} // gui

#endif // _gui_PatientModel_
