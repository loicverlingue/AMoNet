#ifndef _gui_TherapyModel_
#define _gui_TherapyModel_

//! \file TherapyModel.h
//! \brief Defines TherapyModel
//! \author http://www.surgiqual-institute.com/
//! \date April 2021.


// Library dependencies
#include <qobject.h>
#include <qqml.h>
#include <qstringlist.h>
#include <qmap.h>
#include <qvariant.h>
// Project dependencies


namespace gui
{
    //! \class TherapyModel
    //! \brief Handle the therapy data
    class TherapyModel : public QObject
    {
        Q_OBJECT
            Q_PROPERTY(QStringList therapyList READ getTherapyList NOTIFY signalTherapyListChanged)
            Q_PROPERTY(QVariantList currentTherapy READ getCurrentTherapyToDisplay NOTIFY signalCurrentTherapyChanged)
            Q_PROPERTY(QString error READ getError NOTIFY signalErrorChanged)

        // constructor / destructor / operator
    public:
        //! \brief Default constructor
        explicit TherapyModel(QObject* p_parent = nullptr);

        //! \brief Destructor
        virtual ~TherapyModel() = default;

        //! \brief Copy constructor
        //! \param[in] p_other Object to copy
        TherapyModel(const TherapyModel& p_other) = default; // To implement if copying is non-trivial

        //! \brief Copy assignment operator
        //! \param[in] p_other Object to copy
        TherapyModel& operator=(const TherapyModel& p_other) = default; // To implement if copying is non-trivial

        //! \brief Move constructor
        //! \param[in] p_other Object to move
        TherapyModel(TherapyModel&& p_other) = default; // To implement if moving is non trivial

        //! \brief Move assignment operator
        //! \param[in] p_other Object to move
        TherapyModel& operator=(TherapyModel&& p_other) = default; // To implement if moving is non trivial

        // get / set
    public:
        [[nodiscard]]
        //! \brief get the therapy list
        //! \return the therapy list
        QStringList getTherapyList();

        [[nodiscard]]
        //! \brief get the current therapy's list of gene
        //! \return the current therapy's list of gene
        QVariantList getCurrentTherapyToDisplay();

        [[nodiscard]]
        QString getError() const;
    protected:
    private:

    signals:
        void signalTherapyListChanged();
        void signalCurrentTherapyChanged();
        void signalErrorChanged();

    public slots:
        //! \brief load chosen therapy
        //! \param p_name name of the therapy to import
        void slotImportTherapy(const QString& p_name);

        //!\brief save the therapy in the network
        void slotSaveTherapy();

        // methods / functions / slots
    public:
        //! \brief register qml type
        static void REGISTER_QML_TYPE();
    protected:
    private:
        //! \brief load the therapy list
        void loadTherapyList();

        // members
    protected:
    private:
        //! \brief List of available therapy 
        QStringList m_therapyList;

        //! \brief No therapy indicator
        QString m_noTherapy;

        //! \brief name of the folder containing the therapy files
        QString m_therapyFolderName;

        //! \brief therapy name
        QString m_currentTherapyName;

        //! \brief list of genes affected by the current therapy (do be displayed with qml)
        QVariantList m_currentTherapyToDisplay;

        //! \brief list of genes affected by the current therapy
        QMap<QString, double> m_currentTherapyEffect;

        //! \brief error that occured
        QString m_error;
    };

} // gui

#endif // _gui_TherapyModel_
