//! \file TherapyModel.cpp
//! \brief Implements TherapyModel
//! \author http://www.surgiqual-institute.com/
//! \date April 2021


// Qt
#include <qdir.h>
#include <QCoreApplication>

// Project dependencies
#include "TherapyModel.h"
#include "app/Locator.h"
#include "app/ApplicationSettings.h"
#include "io/Importer.h"
#include "io/ImporterException.h"
#include "data/NetworkData.h"
#include "app/FileLocation.h"

namespace gui
    {
    
    TherapyModel::TherapyModel(QObject* p_parent)
    :QObject{ p_parent }
    {
        m_noTherapy = tr("NO_THERAPY");
        m_currentTherapyName = m_noTherapy;
         m_therapyFolderName =  app::FileLocation::getInputDirPath(  app::Locator::getSettings()->getMainSettingsValue<QString>("therapy/therapyFolderName"));
        loadTherapyList();
    }
    
    QStringList TherapyModel::getTherapyList()
    {
        return m_therapyList;
    }
    
    QVariantList TherapyModel::getCurrentTherapyToDisplay()
    {
        return m_currentTherapyToDisplay;
    }
    
    void TherapyModel::slotImportTherapy(const QString& p_name)
    {
        // clear lists
        m_currentTherapyToDisplay.clear();
        m_currentTherapyEffect.clear();
        
        m_currentTherapyName = p_name;
        
        auto therapyPath = m_therapyFolderName + "/" + m_currentTherapyName + ".csv";
        
        try
        {
            if (m_currentTherapyName != m_noTherapy)
            {
                // load the current therapy
                m_currentTherapyEffect = io::Importer::loadPatientMutationsFromCSV(therapyPath, true);
                for (const auto& gene : m_currentTherapyEffect.keys())
                {
                    // set up the displayed list
                    QVariantMap pair;
                    pair.insert("geneName", gene);
                    pair.insert("value", m_currentTherapyEffect.value(gene));
                    m_currentTherapyToDisplay << pair;
                }
            }
            
            emit signalCurrentTherapyChanged();
        }
        catch (io::CImporterException& p_importerException)
        {
            qInfo() << p_importerException.what();
            m_error = tr("ERROR_READ_FILE") + " " + therapyPath;
            emit signalErrorChanged();
        }
    }
    
    void TherapyModel::slotSaveTherapy()
    {
        app::Locator::getNetwork()->updateTherapy(m_currentTherapyName, m_currentTherapyEffect);
    }
    
    void TherapyModel::REGISTER_QML_TYPE()
    {
        qmlRegisterType<TherapyModel>("gui.models", 1, 0, "TherapyModel");
    }
    
    void TherapyModel::loadTherapyList()
    {
        qInfo() << "Loading therapies from: " << m_therapyFolderName;
        
        // open folder
        QDir therapyDir(m_therapyFolderName);
        
        // retrieve the list of file in the therapy folder
        auto rawList = therapyDir.entryList(QDir::Files);
        
        // remove the extension
        for (int i = 0; i < rawList.size(); i++)
        {
            rawList.operator[](i).remove(".csv");
        }
        
        // add to the therapy list
        m_therapyList.clear();
        m_therapyList.append(m_noTherapy);
        m_therapyList.append(rawList);
        
        emit signalTherapyListChanged();
    }
    
    QString TherapyModel::getError() const
    {
        return m_error;
    }
    
    } // gui


