//! \file PatientModel.cpp
//! \brief Implements PatientModel
//! \author http://www.surgiqual-institute.com/
//! \date March 2021.


// Library dependencies

// Project dependencies
#include "PatientModel.h"
#include "app/Locator.h"

namespace gui
{

    PatientModel::PatientModel(QObject* p_parent)
        : QObject{p_parent},
        m_patientData{app::Locator::getPatient()}
    {
    }

    void PatientModel::setLastName(const QString& p_lastName)
    {
        if (m_lastName != p_lastName)
        {
            m_lastName = p_lastName;
            emit signalLastNameChanged();
        }
    }

    void PatientModel::setFirstName(const QString& p_firstName)
    {
        if (m_firstName != p_firstName)
        {
            m_firstName = p_firstName;
            emit signalFirstNameChanged();
        }
    }

    void PatientModel::setIdentifier(const QString& p_indentifier)
    {
        if (m_identifier != p_indentifier)
        {
            m_identifier = p_indentifier;
            emit signalIdentifierChanged();
        }
    }

    void PatientModel::setClinicalInfo(const QString& p_info)
    {
        if (m_clinicalInfo != p_info)
        {
            m_clinicalInfo = p_info;
            emit signalClinicalInfoChanged();
        }
    }

    QString PatientModel::getLastName() const
    {
        return m_lastName;
    }

    QString PatientModel::getFirstName() const
    {
        return m_firstName;
    }

    QString PatientModel::getIdentifier() const
    {
        return m_identifier;
    }

    QString PatientModel::getClinicalInfo() const
    {
        return m_clinicalInfo;
    }

    void PatientModel::REGISTER_QML_TYPE()
    {
        qmlRegisterSingletonType<PatientModel>(
            "gui.models", 1, 0, "PatientModel",
            [](QQmlEngine* engine, QJSEngine* scriptEngine) -> QObject*
            {
                Q_UNUSED(engine)
                    Q_UNUSED(scriptEngine)

                    return new PatientModel();
            }
        );
    }

    void PatientModel::slotSaveData()
    {
        m_patientData->setLastName(m_lastName);
        m_patientData->setFirstName(m_firstName);
        m_patientData->setIdentifier(m_identifier);
        m_patientData->setClinicalInfo(m_clinicalInfo);
    }
} // gui


