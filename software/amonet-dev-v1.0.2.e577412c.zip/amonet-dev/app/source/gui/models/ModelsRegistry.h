#ifndef _models_ModelsRegistry_
#define _models_ModelsRegistry_

//! \file ModelsRegistry.h
//! \brief Defines ModelsRegistry
//! \author http://www.surgiqual-institute.com/
//! \date March 2021


// Library dependencies

// Project dependencies


namespace gui
{
    //! \class ModelsRegistry
    //! \brief Static class for registering models types to teh QML engine.
    class ModelsRegistry
    {
        // constructor / destructor / operator
    public:
        //! \brief Default constructor
        explicit ModelsRegistry() = delete;

        //! \brief Destructor
        virtual ~ModelsRegistry() = delete;

        //! \brief Copy constructor
        //! \param[in] p_other Object to copy
        ModelsRegistry(const ModelsRegistry& p_other) = delete;

        //! \brief Copy assignment operator
        //! \param[in] p_other Object to copy
        ModelsRegistry& operator=(const ModelsRegistry& p_other) = delete;

        //! \brief Move constructor
        //! \param[in] p_other Object to move
        ModelsRegistry(ModelsRegistry&& p_other) = delete;

        //! \brief Move assignment operator
        //! \param[in] p_other Object to move
        ModelsRegistry& operator=(ModelsRegistry&& p_other) = delete;

        // get / set
    public:
    protected:
    private:

        // methods / functions / slots
    public:

        //! Registers the types of all the models
        static void REGISTER_QML_TYPES();

    protected:
    private:

        // members
    protected:
    private:

    };

} // gui

#endif // _models_ModelsRegistry_
