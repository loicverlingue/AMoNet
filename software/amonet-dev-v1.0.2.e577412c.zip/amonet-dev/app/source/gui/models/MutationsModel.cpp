//! \file MutationsModel.cpp
//! \brief Implements MutationsModel
//! \author http://www.surgiqual-institute.com/
//! \date March 2021.


// Library dependencies
#include <qfile.h>
#include <qregexp.h>
#include <QtConcurrent/qtconcurrentrun.h>
#include <QCoreApplication>

// Project dependencies
#include "MutationsModel.h"
#include "data/GeneData.h"
#include "data/MutationType.h"
#include "data/PatientData.h"
#include "io/Importer.h"
#include "io/ImporterException.h"
#include "algo/PredictionComputation.h"
#include "app/Locator.h"
#include "app/ApplicationSettings.h"
#include "app/FileLocation.h"

namespace gui
{
    MutationsModel::MutationsModel(QObject* p_parent)
        : QObject{ p_parent }, 
        m_networkData{app::Locator::getNetwork()}
    {
        ::QObject::connect(m_networkData.get(), &data::NetworkData::signalNetworkChanged, this, &MutationsModel::slotUpdateNetworkData);
        try
        {
            m_trainingDataGenesPath = app::FileLocation::getInputFilePath(  app::Locator::getSettings()->getMainSettingsValue<QString>("data/trainingModelGenesPath"));

            // init geneList
            initGeneList();

            m_isLoadingSuccessful = true;
        }
        catch (io::CImporterException& p_importerException)
        {
            qInfo() << p_importerException.what();
            m_error = tr("ERROR_READ_FILE") + " " + m_trainingDataGenesPath;
            m_isLoadingSuccessful = false;
            emit signalErrorChanged();
        }
    }

    QVariantList MutationsModel::getGeneList() const
    {
        return m_geneList;
    }

    void MutationsModel::slotUpdateGeneMutationType(int p_geneIndex, int p_mutationType)
    {      
        QVariantMap pair;
        pair.insert("geneIndex", p_geneIndex);
        pair.insert("geneName", m_geneList.value(p_geneIndex).value<QVariantMap>().value("geneName").value<QString>());
        pair.insert("geneMutationType", p_mutationType);
        pair.insert("geneMutationValue", data::mutationTypeToDouble(data::mutationTypeFromInt(p_mutationType)));
        pair.insert("geneIndexInNetwork", m_geneList.value(p_geneIndex).value<QVariantMap>().value("geneIndexInNetwork").value<int>());

        m_geneList.operator[](p_geneIndex).setValue<QVariantMap>(pair);
       
        emit signalGeneTypeChanged();
    }

    void MutationsModel::slotUpdateGeneMutationValue(int p_geneIndex, float p_mutationValue)
    {
        QVariantMap pair;
        pair.insert("geneIndex", p_geneIndex);
        pair.insert("geneName", m_geneList.value(p_geneIndex).value<QVariantMap>().value("geneName").value<QString>());
        pair.insert("geneMutationType", data::mutationTypeToInt(data::mutationTypeFromDouble(p_mutationValue)));
        pair.insert("geneMutationValue", p_mutationValue);
        pair.insert("geneIndexInNetwork", m_geneList.value(p_geneIndex).value<QVariantMap>().value("geneIndexInNetwork").value<int>());

        m_geneList.operator[](p_geneIndex).setValue<QVariantMap>(pair);

        emit signalGeneValueChanged();
    }

    void MutationsModel::slotImportPatientMutations(const QUrl& p_path)
    {
        QString filePath = p_path.toLocalFile();
        qInfo() << "[MutationsModel::slotImportPatientMutations][filePath]" << filePath;

        // load the mutations from the file
        try 
        {
            auto patientMutations = io::Importer::loadPatientMutationsFromCSV(filePath, false);

            for (int i = 0; i < m_geneList.size(); i++)
            {
                QString geneName = m_geneList.value(i).value<QVariantMap>().value("geneName").value<QString>();

                // if the file data contains a gene of the list, apply the new value of mutation
                if (patientMutations.contains(geneName))
                {
                    QVariantMap pair;
                    pair.insert("geneIndex", i);
                    pair.insert("geneName", geneName);
                    pair.insert("geneMutationType", data::mutationTypeToInt(data::mutationTypeFromDouble(patientMutations.value(geneName))));
                    pair.insert("geneMutationValue", patientMutations.value(geneName));
                    pair.insert("geneIndexInNetwork", m_geneList.value(i).value<QVariantMap>().value("geneIndexInNetwork").value<int>());
                    m_geneList.operator[](i).setValue<QVariantMap>(pair);
                }
                else
                {
                    QVariantMap pair;
                    pair.insert("geneIndex", i);
                    pair.insert("geneName", geneName);
                    pair.insert("geneMutationType", data::mutationTypeToInt(data::MutationType::NO_MUTATION));
                    pair.insert("geneMutationValue", data::mutationTypeToDouble(data::MutationType::NO_MUTATION));
                    pair.insert("geneIndexInNetwork", m_geneList.value(i).value<QVariantMap>().value("geneIndexInNetwork").value<int>());
                    m_geneList.operator[](i).setValue<QVariantMap>(pair);
                }
            }
            emit signalGeneListChanged();
        }
        catch (io::CImporterException& p_importerException)
        {
            qInfo() << p_importerException.what();
            m_error = tr("ERROR_READ_FILE") + " " + filePath;
            emit signalErrorChanged();
        }
    }

    void MutationsModel::slotComputePrediction()
    {
        // save the mutations data in the network
        saveGenesMutations();

        m_loadingSynchro.addFuture(QtConcurrent::run(
            [this]()
            {
                int minStepForward = app::Locator::getSettings()->getMainSettingsValue<int>("prediction/minStepForward");
                double valMut = app::Locator::getSettings()->getMainSettingsValue<double>("prediction/valMut");
                // start prediction computation
                auto outputs = algo::PredictionComputation::predictSurvivalRate(m_networkData, valMut, minStepForward);
                app::Locator::getPatient()->setSurvivalPrediction(outputs);

                qInfo() << "=======OUTPUTS=======";
                qInfo() << "output1 : " << outputs.getGeneState("Output1");
                qInfo() << "output2 : " << outputs.getGeneState("Output2");
                qInfo() << "output3 : " << outputs.getGeneState("Output3");
                qInfo() << "output4 : " << outputs.getGeneState("Output4");
                qInfo() << "output5 : " << outputs.getGeneState("Output5");
                qInfo() << "output6 : " << outputs.getGeneState("Output6");
                qInfo() << "output7 : " << outputs.getGeneState("Output7");
                qInfo() << "output8 : " << outputs.getGeneState("Output8");
                qInfo() << "output9 : " << outputs.getGeneState("Output9");
                qInfo() << "output10 : " << outputs.getGeneState("Output10");

                emit signalComputationEnded();
            }
        ));
    }

    void MutationsModel::REGISTER_QML_TYPE()
    {
        qmlRegisterType<MutationsModel>("gui.models", 1, 0, "MutationsModel");
    }

    void MutationsModel::initGeneList()
    {
        qInfo() << "Initializing genes list from: " << m_trainingDataGenesPath;
        
        QStringList trainingMutations = io::Importer::loadTrainingDataMutationsFromCSV(m_trainingDataGenesPath);
        m_geneList.clear();
        
        auto geneList = m_networkData->getGenes();
        int nbGeneInList = 0;
        for (int i = 0; i < geneList->size(); i++)
        {
            // add every genes to the list which are present in the training data
            if (trainingMutations.indexOf(geneList->at(i).getName()) != -1)
            {
                QVariantMap pair;
                pair.insert("geneIndex", nbGeneInList++);
                pair.insert("geneName", geneList->at(i).getName());
                pair.insert("geneMutationType", data::mutationTypeToInt(data::mutationTypeFromDouble(geneList->at(i).getMutationValue())));
                pair.insert("geneMutationValue", geneList->at(i).getMutationValue());
                pair.insert("geneIndexInNetwork", i);
                m_geneList << pair;
            }
        }
    }

    void MutationsModel::slotUpdateNetworkData()
    {
        m_networkData = app::Locator::getNetwork();
        initGeneList();
        emit signalGeneListChanged();
    }

    void MutationsModel::saveGenesMutations()
    {
        for (int i = 0; i < m_geneList.size(); i++)
        {
            m_networkData->modifyGeneMutation(
                m_geneList.value(i).value<QVariantMap>().value("geneIndexInNetwork").value<int>(),
                m_geneList.value(i).value<QVariantMap>().value("geneMutationValue").value<double>());
        }
    }

    QString MutationsModel::getError() const
    {
        return m_error;
    }

    bool MutationsModel::getIsLoadingSuccessful() const
    {
        return m_isLoadingSuccessful;
    }

} // Namespace


