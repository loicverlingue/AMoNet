//! \file ExporterModel.cpp
//! \brief Implements ExporterModel
//! \author http://www.surgiqual-institute.com/
//! \date April 2021


// Library dependencies
#include <qdir.h>
#include <qdatetime.h>
#include <qimage.h>
#include <qloggingcategory.h>
// Project dependencies
#include "ExporterModel.h"
#include "app/Locator.h"
#include "io/Exporter.h"
#include "data/NetworkData.h"
#include "data/GeneData.h"
#include "app/ApplicationSettings.h"

namespace gui
{

    ExporterModel::ExporterModel(QObject* p_parent)
        : QObject{ p_parent }
    {
    }
    void ExporterModel::slotSaveData(const QUrl& p_folderUrl, const QImage& p_image)
    {
        QString folderPath = p_folderUrl.toLocalFile();
        qInfo() << "[ExporterModel::slotSaveData][folderPath]" << folderPath;

        QString timestamp = QDateTime::currentDateTime().toString("yyyy-MM-dd-hh-mm-ss");
        QString exportPath = folderPath + "/AMoNet_Export_" + timestamp + "_v" + app::Locator::getVersion();
        
        // create the export folder if necessary
        QDir exportDir(exportPath);
        if (!exportDir.exists())
        {
            exportDir.mkpath(exportDir.absolutePath());
        }

        //! retieve patient data
        auto patientData = app::Locator::getPatient();

        // export patient data as text file
        io::Exporter::exportPatientData(patientData, exportPath, "patient_info");
        io::Exporter::exportPrediction(patientData->getSurvivalPrediction(), patientData->getIntervalDuration(), exportPath, "output");
        io::Exporter::exportConvergence(patientData->getSurvivalPrediction(), patientData->getIntervalDuration(), exportPath, "convergence_output_nodes");
        io::Exporter::exportGraph(p_image, exportPath, "output");
        auto network = app::Locator::getNetwork();
        std::shared_ptr<QList<data::GeneData>> genes = network->getGenes();
        QMap<QString, double> geneToExport;
        for (data::GeneData& gene : *genes)
        {
            geneToExport[gene.getName()] = gene.getMutationValue();
        }
        io::Exporter::exportPatientMutationsToCSV(geneToExport, exportPath, "patient_mutation_data");
        auto therapyName = network->getTherapy()->getName();
        if (therapyName != tr("NO_THERAPY")) {
            QString therapyFolder = app::Locator::getSettings()->getMainSettingsValue<QString>("therapy/therapyFolderName");
            QFile::copy(therapyFolder + "/" + network->getTherapy()->getName() + ".csv", exportPath + "/" + network->getTherapy()->getName() + ".csv");
        }
    }

    void ExporterModel::REGISTER_QML_TYPE()
    {
        qmlRegisterType<ExporterModel>("gui.models", 1, 0, "ExporterModel");
    }

} // gui


