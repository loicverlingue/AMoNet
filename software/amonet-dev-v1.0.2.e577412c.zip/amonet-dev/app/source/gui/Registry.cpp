//! \file Registry.cpp
//! \brief Implements Registry
//! \author http://www.surgiqual-institute.com/
//! \date December 2020


// Library dependencies

// Project dependencies
#include "Registry.h"


namespace gui
{

    void Registry::REGISTER_QML_TYPES()
    {
        // TODO register models here
    }

} // gui
