//! \file Locator.cpp
//! \brief Implements Locator
//! \author http://www.surgiqual-institute.com/
//! \date September 2020


// Library dependencies

// Project dependencies
#include "Locator.h"
#include "app/Application.h"


namespace app
{

	std::shared_ptr<data::NetworkData> Locator::getNetwork()
	{
		return app::Application::instance()->m_network;
	}

	std::shared_ptr<app::ApplicationSettings> Locator::getSettings()
	{
		return app::Application::instance()->m_settings;
	}

	std::shared_ptr<data::PatientData> Locator::getPatient()
	{
		return app::Application::instance()->m_patient;
	}

    QString Locator::getVersion()
    {
        return app::Application::instance()->applicationVersion();
    }

} // app


