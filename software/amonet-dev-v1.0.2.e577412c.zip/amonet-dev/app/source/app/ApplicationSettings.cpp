//! \file ApplicationSettings.cpp
//! \brief Implements ApplicationSettings
//! \author http://www.surgiqual-institute.com/
//! \date February 2020


// Qt
#include <qfileinfo.h>
#include <qdebug.h>
#include <QCoreApplication>

// Project dependencies
#include "ApplicationSettings.h"
#include "utils/Exceptions.h"
#include "app/FileLocation.h"

namespace app
{
    std::shared_ptr<const QSettings> ApplicationSettings::getMainSettings() const
    {
        return m_mainSettings;
    }

    void ApplicationSettings::load()
    {
        QString settingsPath = FileLocation::getInputFilePath("settings.ini");
        LOAD_SETTINGS(settingsPath, &m_mainSettings);
    }

    void ApplicationSettings::LOAD_SETTINGS(const QString& p_iniFilePath, std::shared_ptr<QSettings>* p_settings)
    {
        if (!QFileInfo(p_iniFilePath).exists())
        {
            THROW_VERBOSE_EXCEPTION(std::logic_error, "Settings files does not exist: " + p_iniFilePath);
        }
        *p_settings = std::make_shared<QSettings>(p_iniFilePath, QSettings::Format::IniFormat);
        if ((*p_settings)->status() != QSettings::NoError)
        {
            THROW_VERBOSE_EXCEPTION(std::logic_error, "Error when loading settings file");
        }
        qDebug() << "Settings loaded from" << p_iniFilePath;
    }

} // app


