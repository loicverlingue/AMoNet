//! \file Application.cpp
//! \brief Implements Application
//! \author http://www.surgiqual-institute.com/
//! \date March 2021

// Qt
#include <qqmlcontext.h>
#include <qloggingcategory.h>
#include <qicon.h>
#include <qstring.h>
#include <qfile.h>
#include <qdatetime.h>
#include <qdir.h>

// Project dependencies
#include "Application.h"
#include "Version.h"
#include "ApplicationSettings.h"
#include "gui/Registry.h"
#include "gui/utils/UtilsRegistry.h"
#include "gui/models/ModelsRegistry.h"
#include "io/LogService.h"
#include "io/Log.h"
#include "encryption/SimpleCrypt.h"
#include "def/EncryptionDefinitions.h"
#include "data/NetworkData.h"
#include "io/Importer.h"
#include "io/ImporterException.h"
#include "FileLocation.h"

namespace app
    {
    Application::Application(int &argc, char **argv)
    : QGuiApplication(argc, argv)
    {
    }
    
    Application::~Application()
    {
        qInstallMessageHandler(nullptr);
    }
    
    std::shared_ptr<const ApplicationSettings> Application::getSettings() const
    {
        return m_settings;
    }
    
    void Application::init()
    {
        // init and loadings
        initLogs();
        loadSettings();
        initAppInfo();
        initDisplaySettings();
        initTranslations();
        loadNetwork();
        initPatient();
        
        // Register qml types
        gui::UtilsRegistry::REGISTER_QML_TYPES();
        gui::ModelsRegistry::REGISTER_QML_TYPES();
        loadEngine();
        
#if defined(__APPLE__)
        // copy user editable files in Apple home dir if necessary
        QDir().mkpath(FileLocation::getAmonetAppleHomeDirPath());
        
        if(!FileLocation::isFileExistsInAppleHomeDir(m_settingsFileName)){
            FileLocation::copyFromAppleBundleResourceToAppleHomeDir(m_settingsFileName);
        }
        
        if(!FileLocation::isFileExistsInAppleHomeDir(m_networkDataFileName)){
            FileLocation::copyFromAppleBundleResourceToAppleHomeDir(m_networkDataFileName);
        }
        
        if(!FileLocation::isDirExistsInAppleHomeDir(m_therapyDirName)){
            FileLocation::copyFromAppleBundleResourceToAppleHomeDir(m_therapyDirName);
        }
        
        if(!FileLocation::isFileExistsInAppleHomeDir(m_trainingModelTimePath)){
            FileLocation::copyFromAppleBundleResourceToAppleHomeDir(m_trainingModelTimePath);
        }
        
        if(!FileLocation::isFileExistsInAppleHomeDir(m_trainingModelGenesPath)){
            FileLocation::copyFromAppleBundleResourceToAppleHomeDir(m_trainingModelGenesPath);
        }
#endif
    }
    
    Application* Application::instance()
    {
        return dynamic_cast<Application*>(QApplication::instance());
    }
    
    void Application::loadSettings()
    {
        m_settings = std::make_unique<ApplicationSettings>();
        m_settings->load();
        
        m_networkDataFileName = m_settings->getMainSettingsValue<QString>("data/networkFilePath");
        m_language = m_settings->getMainSettingsValue<QString>("languages/applicationLanguage");
        m_trainingModelTimePath = m_settings->getMainSettingsValue<QString>("data/trainingModelTimePath");
        m_therapyDirName = m_settings->getMainSettingsValue<QString>("therapy/therapyFolderName");
        m_trainingModelGenesPath = m_settings->getMainSettingsValue<QString>("data/trainingModelGenesPath");
    }
    
    void Application::initAppInfo()
    {
        // App icon
        setWindowIcon(QIcon("://icons/windowIcon"));
        
        // App info
        setOrganizationName(PROJECT_ORGANIZATION);
        setApplicationVersion(QString("%1.%2").arg(PROJECT_VERSION).arg(GIT_COMMIT_HASH));
        setOrganizationDomain(PROJECT_DOMAIN);
        setApplicationName(PROJECT_NAME);
        
        // Info logs
        qInfo() << "App version:" << applicationVersion().toStdString().c_str();
        
        // Debug logs
        qDebug() << "Qt compile version:" << QT_VERSION_STR;
        qDebug() << "Qt runtime version:" << qVersion();
#ifndef NDEBUG
        QLoggingCategory::setFilterRules(QStringLiteral("qt.qml.binding.removal.info=true"));
#endif
    }
    
    void Application::initDisplaySettings()
    {
        // Set MSAA samples for shapes
        QSurfaceFormat format;
        format.setSamples(m_settings->getMainSettingsValue<int>("display/msaaSamples"));
        QSurfaceFormat::setDefaultFormat(format);
    }
    
    void Application::initTranslations()
    {
        m_translator = std::make_unique<QTranslator>();
        QString translationFilePath = FileLocation::getTranslationFilePath(m_language);
        if (!m_translator->load(translationFilePath))
        {
            qCritical() << "Could not load translations from" << translationFilePath;
        }
        else
        {
            qDebug() << "Translations loaded from" << translationFilePath;
        }
        if (!installTranslator(m_translator.get()))
        {
            qCritical() << "Could not install translator";
        }
        else
        {
            qDebug() << "Translator installed";
        }
    }
    
    void Application::loadEngine()
    {
        // Register types
        gui::Registry::REGISTER_QML_TYPES();
        
        // Init QML engine
        m_engine = std::make_unique<QQmlApplicationEngine>();
        
        // Load QML engine
        m_engine->load(QUrl(QStringLiteral("qrc:/main.qml")));
    }
    
    void Application::initLogs()
    {
        std::string logDirectory = FileLocation::getLogDirectory();
        std::cout << "Initializing log with: logDirectory = " << logDirectory << std::endl;
        io::LogService::getInstance().Initialize(logDirectory, "log"+ QDateTime::currentDateTime().toString("yyyyMMddhhmmsszzz").toStdString(), io::CLogLevel::ELogLevel::DEBUG);
        io::LogService::getInstance().LogInfo("Initial log");
        QString appVersion = "App Version : " + applicationVersion();
        io::LogService::getInstance().LogInfo(appVersion);
        
        qInstallMessageHandler(&Application::REDIRECT_QT_LOGS);
    }
    
    void Application::loadNetwork()
    {
        try {
            auto networkFilePath = FileLocation::getInputFilePath(m_networkDataFileName);
            QString decryptedData = io::Importer::decryptNetworkData(networkFilePath);
            m_network = std::make_shared<data::NetworkData>(decryptedData);
        }
        catch (io::CImporterException& p_importerException)
        {
            qInfo() << p_importerException.what();
            m_network = std::make_shared<data::NetworkData>();
        }
    }
    
    void Application::initPatient()
    {
        m_patient = std::make_shared<data::PatientData>(FileLocation::getInputFilePath(m_trainingModelTimePath));
    }
    
    void Application::REDIRECT_QT_LOGS(QtMsgType p_type, const QMessageLogContext& p_context, const QString& p_msg)
    {
        // Fix warning - can't use this parameter
        (void)p_context;
        QString prefix;
        switch (p_type) {
            case QtMsgType::QtCriticalMsg: {
                prefix = "QtCriticalMsg";
                break;
            }
            case QtMsgType::QtDebugMsg: {
                prefix = "QtDebugMsg";
                break;
            }
            case QtMsgType::QtFatalMsg: {
                prefix = "QtFatalMsg";
                break;
            }
            case QtMsgType::QtInfoMsg: {
                prefix = "QtInfoMsg";
                break;
            }
            case QtMsgType::QtWarningMsg: {
                prefix = "QtWarningMsg";
                break;
            }
            default: {
                prefix = "Unknown";
                break;
            }
        }
        auto message = QString("[%0] %1").arg(prefix).arg(p_msg);
        io::LogService::getInstance().LogDebug(message);
    }
    
    void Application::encryptNetworkData()
    {
        QFile file("saved_AMoNet_network.csv");
        if (!file.open(QIODevice::ReadOnly))
        {
            io::LogService::getInstance().LogError("Cannot open .csv file");
        }
        else
        {
            // Read file
            QByteArray dataToEncrypt = file.readAll();
            file.close();
            
            // Encrypt data
            SimpleCrypt crypto(def::AMONET_ENCRYPT_KEY);
            QByteArray encryptedFileContent = crypto.encryptToByteArray(dataToEncrypt);
            
            // Write encrypted file
            QFile encryptedFile("encrypted_AMoNet_network.csv");
            encryptedFile.open(QIODevice::WriteOnly);
            encryptedFile.write(encryptedFileContent);
            encryptedFile.close();
            
            qInfo() << "encryption finished";
        }
    }
    
    
    } // app
