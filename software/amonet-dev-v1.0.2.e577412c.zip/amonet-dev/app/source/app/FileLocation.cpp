//! \file FileLocation.cpp
//! \brief Implements FileLocation.h.
//! \author http://www.surgiqual-institute.com/
//! \date December 2021

#include <QString>
#include <QCoreApplication>
#include <QDir>
#include <QFileInfo>
#include <QFile>

#include "FileLocation.h"
#include "ApplicationSettings.h"

namespace app
{
    const std::string FileLocation::getLogDirectory(){
#if defined(__APPLE__)
        return QDir::home().absolutePath().toStdString()  + "/Library/Logs/AMoNet";
#else
        return "log";
#endif
    }
    
    const QString FileLocation::getTranslationFilePath(const QString & p_language){
#if defined(__APPLE__)
        QFileInfo translationFileInfo(getAmonetAppleHomeDirPath() + "/translation_" + p_language);
        if(translationFileInfo.exists() && translationFileInfo.isFile()){
            return translationFileInfo.absolutePath();
        }
        
        return QCoreApplication::applicationDirPath() + "/../Resources/translation_" + p_language;
#else
        return "translation_" + p_language;
#endif
    }

const QString FileLocation::getInputFilePath(const QString & p_fileName){
#if defined(__APPLE__)
        if(isFileExistsInAppleHomeDir(p_fileName)){
            return getAmonetAppleHomeDirPath() + p_fileName;
        } else {
            return getAmonetAppleBundleResourceDirPath() + p_fileName;
        }
#else
        return p_fileName;
#endif
    }
    
    const QString FileLocation::getInputDirPath(const QString & p_dirName){
#if defined(__APPLE__)
        if(isDirExistsInAppleHomeDir(p_dirName)){
            return getAmonetAppleHomeDirPath() + p_dirName;
        } else {
            return getAmonetAppleBundleResourceDirPath() + p_dirName;
        }
#else
        return p_dirName;
#endif
    }
       
#if defined(__APPLE__)
    const QString FileLocation::getAmonetAppleHomeDirPath(){
        return QDir::home().absolutePath() + "/Library/AMoNet/";
    }
    
    const QString FileLocation::getAmonetAppleBundleResourceDirPath(){
        return QCoreApplication::applicationDirPath() + "/../Resources/";
    }
    
    bool FileLocation::isFileExistsInAppleHomeDir(const QString &p_fileName){
        QFileInfo fileInfo(getAmonetAppleHomeDirPath() + p_fileName);
        return fileInfo.exists() && fileInfo.isFile();
    }
    
    bool FileLocation::isDirExistsInAppleHomeDir(const QString & p_dirName){
        QFileInfo dirInfo(getAmonetAppleHomeDirPath() + p_dirName);
        return dirInfo.exists() && dirInfo.isDir();
    }
    
    void FileLocation::copyFromAppleBundleResourceToAppleHomeDir(const QString &p_fileOrDirName){
        QFile::copy(getAmonetAppleBundleResourceDirPath() + p_fileOrDirName, getAmonetAppleHomeDirPath() + p_fileOrDirName);
    }
#endif
    } // app
