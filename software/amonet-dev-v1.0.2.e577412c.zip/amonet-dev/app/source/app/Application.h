#ifndef _app_Application_
#define _app_Application_

//! \file Application.h
//! \brief Defines Application
//! \author http://www.surgiqual-institute.com/
//! \date March 2021


// Qt
#include <qguiapplication.h>
#include <qoffscreensurface.h>
#include <qqmlapplicationengine.h>
#include <qtranslator.h>
#include <qsettings.h>
#include <qapplication.h>

// Project dependencies
#include "utils/Exceptions.h"
#include "data/NetworkData.h"
#include "data/PatientData.h"

namespace app
{
    class ApplicationSettings;
    class Locator;
}

namespace app
{
    //! \class Application
    //! \brief Application singleton
    class Application : public QGuiApplication
    {
       
        friend class Locator;

        // constructor / destructor / operator
    public:
        //! \brief private Constructor
        //! /!\ pay attention to the reference to argc (not same signature as main.cpp !!!!)
        explicit Application(int &argc, char **argv);

        //! \brief Destructor
        ~Application() override;

        //! \brief Copy constructor
        //! \param[in] p_other Object to copy
        Application(const Application& p_other) = delete;

        //! \brief Copy assignment operator
        //! \param[in] p_other Object to copy
        Application& operator=(const Application& p_other) = delete;

        //! \brief Move constructor
        //! \param[in] p_other Object to move
        Application(Application&& p_other) = delete;

        //! \brief Move assignment operator
        //! \param[in] p_other Object to move
        Application& operator=(Application&& p_other) = delete;

        // get / set
    public:

        //! \brief Get application settings.
        [[nodiscard]]
        std::shared_ptr<const ApplicationSettings> getSettings() const;

    protected:
    private:

        // methods / functions / slots
    public:
        //! \brief initialise appdata
        void init();

        //! \brief Gets the instance of the application
        static Application* instance();
    protected:
    private:

        //! \brief Loads the application settings.
        void loadSettings();

        //! \brief Initializes application infos.
        static void initAppInfo();

        //! \brief Initialiezes display settings.
        void initDisplaySettings();

        //! \brief Initializes translations.
        void initTranslations();

        //! \brief Initializes and load QMl engine
        void loadEngine();

        //! \brief Initialize logs
        void initLogs();

        //! \brief initailize the neural network 
        void loadNetwork();

        //! \brief initailize the patient data
        void initPatient();

        //! \brief Redirects Qt logs to the logger.
        static void REDIRECT_QT_LOGS(QtMsgType p_type, const QMessageLogContext& p_context, const QString& p_msg);

        //! \brief temporary function to encrypt the network data
        void encryptNetworkData();

        // members
    protected:
    private:

        //! \brief Applications settings.
        std::shared_ptr<ApplicationSettings> m_settings = nullptr;

        //! \brief qml engine to use the qml system
        std::unique_ptr<QQmlApplicationEngine> m_engine = nullptr;

        //! \brief Translator for managing translations.
        //! \details This objects needs to be instantiated for dynamic translations to work.
        std::unique_ptr<QTranslator> m_translator = nullptr;

        //! \brief Network data
        std::shared_ptr<data::NetworkData> m_network = std::make_shared<data::NetworkData>();

        //! \brief Patient data
        std::shared_ptr<data::PatientData> m_patient = std::make_shared<data::PatientData>();
        
        QString m_settingsFileName = "settings.ini";
        QString m_networkDataFileName;
        QString m_language;
        QString m_trainingModelTimePath;
        QString m_therapyDirName;
        QString m_trainingModelGenesPath;
    };

} // app

#endif // _app_Application_
