#ifndef _app_FileLocation_
#define _app_FileLocation_

//! \file FileLocation.h
//! \brief Defines where the different input application files are located / named.
//! \author http://www.surgiqual-institute.com/
//! \date December 2021

namespace app
    {
    class ApplicationSettings;
    
    class FileLocation {
    public:
        static const std::string getLogDirectory();
        static const QString getTranslationFilePath(const QString & p_language);
        
        static const QString getInputFilePath(const QString & p_fileName);
        static const QString getInputDirPath(const QString & p_dirName);
        
#if defined(__APPLE__)
        static const QString getAmonetAppleHomeDirPath();
        static const QString getAmonetAppleBundleResourceDirPath();
        
        static bool isFileExistsInAppleHomeDir(const QString & p_fileName);
        static bool isDirExistsInAppleHomeDir(const QString & p_dirName);
        
        static void copyFromAppleBundleResourceToAppleHomeDir(const QString & p_fileOrDirName);
#endif
  
    };
    } // app

#endif // _app_FileLocation_
