#ifndef _app_Locator_
#define _app_Locator_

//! \file Locator.h
//! \brief Defines Locator
//! \author http://www.surgiqual-institute.com/
//! \date Macrh 2021


// STL
#include <memory>

// Qt
#include <qstring.h>
#include <qthread.h>

// Project dependencies
namespace app
{
    class ApplicationSettings;
}

namespace data
{
    class NetworkData;
    class PatientData;
}

namespace app
{
    //! \class Locator
    //! \brief Gives access to the services.
    class Locator
    {
        // constructor / destructor / operator
    public:
        //! \brief Default constructor
        explicit Locator() = delete;

        //! \brief Destructor
        virtual ~Locator() = delete;

        //! \brief Copy constructor
        //! \param[in] p_other Object to copy
        Locator(const Locator& p_other) = delete;

        //! \brief Copy assignment operator
        //! \param[in] p_other Object to copy
        Locator& operator=(const Locator& p_other) = delete;

        //! \brief Move constructor
        //! \param[in] p_other Object to move
        Locator(Locator&& p_other) = delete;

        //! \brief Move assignment operator
        //! \param[in] p_other Object to move
        Locator& operator=(Locator&& p_other) = delete;

        // methods / functions / slots
    public:
        //! \brief get the network data
        static std::shared_ptr<data::NetworkData> getNetwork();

        //! \brief get application settings
        static std::shared_ptr<app::ApplicationSettings> getSettings();

        //! \brief get the patient data
        static std::shared_ptr<data::PatientData> getPatient();

        //! \brief get the application version
        static QString getVersion();
    };

} // app

#endif // _app_Locator_
