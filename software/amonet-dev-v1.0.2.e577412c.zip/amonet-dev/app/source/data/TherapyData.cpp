//! \file TherapyData.cpp
//! \brief Implements TherapyData
//! \author http://www.surgiqual-institute.com/
//! \date April 2021


// Library dependencies

// Project dependencies
#include "TherapyData.h"


namespace data
{

    TherapyData::TherapyData()
    {
    }

    void TherapyData::setName(const QString& p_name)
    {
        m_name = p_name;
    }

    void TherapyData::setEffectOnGenes(const QMap<QString, double>& p_effect)
    {
        m_effectOnGenes = p_effect;
    }

    QString TherapyData::getName() const
    {
        return m_name;
    }

    QMap<QString, double> TherapyData::getEffectOnGenes() const
    {
        return m_effectOnGenes;
    }

} // Namespace


