//! \file NetworkStateData.cpp
//! \brief Implements NetworkStateData
//! \author http://www.surgiqual-institute.com/
//! \date March 2021


// Library dependencies
#include <qloggingcategory.h>

// Project dependencies
#include "NetworkStateData.h"


namespace data
{

    NetworkStateData::NetworkStateData()
    {
        m_genesNames.clear();
        m_stateValues.clear();
    }

    NetworkStateData& NetworkStateData::operator=(const NetworkStateData& p_other)
    {
        m_genesNames = p_other.m_genesNames;
        m_stateValues = p_other.m_stateValues;
        m_convergenceValues = p_other.m_convergenceValues;
        return *this;
    }

    double NetworkStateData::getGeneState(const QString& p_name) const
    {
        if (!m_genesNames.contains(p_name))
        {
            qInfo() << "ERROR when parsing network state : gene not found";
            return 0;
        }

        return m_stateValues.at(m_genesNames.indexOf(p_name));

    }

    QString NetworkStateData::getGeneName(const int p_index) const
    {
        return m_genesNames.at(p_index);
    }

    int NetworkStateData::getSize() const
    {
        return m_genesNames.size();
    }

    QMap<QString, double> NetworkStateData::toQMap()
    {
        QMap<QString, double> map;
        for (int i = 0; i < m_genesNames.size(); i++)
        {
            map.insert(m_genesNames.at(i), m_stateValues.at(i));
        }
        return map;
    }

    void NetworkStateData::addGeneState(const QString& p_name, const double p_stateVal)
    {
        m_genesNames.push_back(p_name);
        m_stateValues.push_back(p_stateVal);
    }

    void NetworkStateData::modifyGeneState(const QString& p_name, const double p_stateVal)
    {
        m_stateValues.operator[](m_genesNames.indexOf(p_name)) = p_stateVal;
    }

    bool NetworkStateData::containsGene(const QString& p_name)
    {
        return m_genesNames.contains(p_name);
    }

    std::vector<double> NetworkStateData::getConvergenceValues() const
    {
        return m_convergenceValues;
    }

    void NetworkStateData::setConvergenceValues(std::vector<double>& p_convergenceValues)
    {
        m_convergenceValues = p_convergenceValues;
    }

} // data


