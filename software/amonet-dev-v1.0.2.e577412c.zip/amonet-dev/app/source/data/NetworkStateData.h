#ifndef _data_NetworkStateData_
#define _data_NetworkStateData_

//! \file NetworkStateData.h
//! \brief Defines NetworkStateData
//! \author http://www.surgiqual-institute.com/
//! \date March 2021


// Library dependencies
#include <qobject.h>
#include <qstring.h>
#include <qlist.h>
#include <qstringlist.h>
// Project dependencies


namespace data
{
    //! \class NetworkStateData
    //! \brief Manages the state values of the network
    class NetworkStateData
    {
        // constructor / destructor / operator
    public:
        //! \brief Default constructor
        explicit NetworkStateData();

        //! \brief Destructor
        virtual ~NetworkStateData() = default;

        //! \brief Copy constructor
        //! \param[in] p_other Object to copy
        NetworkStateData(const NetworkStateData& p_other) = default; // To implement if copying is non-trivial

        //! \brief Copy assignment operator
        //! \param[in] p_other Object to copy
        NetworkStateData& operator=(const NetworkStateData& p_other); // To implement if copying is non-trivial

        //! \brief Move constructor
        //! \param[in] p_other Object to move
        NetworkStateData(NetworkStateData&& p_other) = default; // To implement if moving is non trivial

        //! \brief Move assignment operator
        //! \param[in] p_other Object to move
        NetworkStateData& operator=(NetworkStateData&& p_other) = default; // To implement if moving is non trivial

        // get / set
    public:
        [[nodiscard]]
        //! \brief get the state value of a gene
        //! \param p_name name of the gene
        //! \return the state value
        double getGeneState(const QString& p_name) const;

        [[nodiscard]]
        //! \brief get a gene name at a certain index 
        //! \param p_index index of the gene
        //! \return the gene name
        QString getGeneName(const int p_index) const;

        [[nodiscard]]
        //! \brief get the size of the state
        int getSize() const;

        [[nodiscard]]
        //! \brief get the list of convergence values
        std::vector<double> getConvergenceValues() const;

    protected:
    private:

        // methods / functions / slots
    public:
        //! \brief add a gene state
        //! \param p_name name of the gene
        //! \param p_stateVal value of the gene's state
        void addGeneState(const QString& p_name, const double p_stateVal);

        //! \brief modify a gene state
        //! \param p_name name of the gene
        //! \param p_stateVal new value of the gene's state
        void modifyGeneState(const QString& p_name, const double p_stateVal);

        //! \brief find if the state constain a gene
        //! \param p_name name of the gene
        //! \return true if the state contains the gene, false othewise 
        bool containsGene(const QString& p_name);

        //! \brief transform the state into a QMap
        QMap<QString, double> toQMap();

        void setConvergenceValues(std::vector<double>& p_totalConvergence);
    protected:
    private:

        // members
    protected:
    private:
        //! \brief list of gene names
        QStringList m_genesNames;

        //! \brief list of states values
        QList<double> m_stateValues;

        //! \brief list of state convergences values
        std::vector<double> m_convergenceValues;
    };

} // data

#endif // _data_NetworkStateData_
