#ifndef _data_GeneData_
#define _data_GeneData_

//! \file GeneData.h
//! \brief Defines GeneData
//! \author http://www.surgiqual-institute.com/
//! \date March 2021.


// Qt
#include <qobject.h>
#include <qstring.h>
#include <qlist.h>

// Project dependencies
#include "data/ConnectionData.h"    
#include "data/MutationType.h"
namespace data
{
    //! \class GeneData
    //! \brief Handles the gene's data
    class GeneData 
    {
        // constructor / destructor / operator
    public:
        //! \brief Default constructor
        explicit GeneData();

        //! \brief Constructor
        explicit GeneData(const QString& p_name);

        //! \brief Destructor
        virtual ~GeneData() = default;

        //! \brief Copy constructor
        //! \param[in] p_other Object to copy
        GeneData(const GeneData& p_other) = default; // To implement if copying is non-trivial

        //! \brief Copy assignment operator
        //! \param[in] p_other Object to copy
        GeneData& operator=(const GeneData& p_other) = default; // To implement if copying is non-trivial

        //! \brief Move constructor
        //! \param[in] p_other Object to move
        GeneData(GeneData&& p_other) = default; // To implement if moving is non trivial

        //! \brief Move assignment operator
        //! \param[in] p_other Object to move
        GeneData& operator=(GeneData&& p_other) = default; // To implement if moving is non trivial

        // get / set
    public:
        [[nodiscard]]
        //! \brief Get the gene's name
        //! \return the gene's name 
        QString getName() const;

        [[nodiscard]]
        //! \brief Get the list of connection 
        //! \return the list of connections
        std::shared_ptr<QList<data::ConnectionData>> getConnections() const;

        [[nodiscard]]
        //! \brief get the mutation value
        //! \return the mutation value
        double getMutationValue() const;

        //! \brief Set the gene's name
        //! \param p_name Name of the gene
        void setName(const QString& p_name);

        //! \brief set the mutation value
        //! \param p_mutation the mutation value
        void setMutationValue(const double p_mutation);

    protected:
    private:

        // methods / functions / slots
    public:
        //! \brief add a new connection
        //!\ param p_target Target of the connection
        //!\ param p_layer  Layer of the gene
        //! \param p_output output of the gene
        //!\ param p_weight Weight of the connection
        //!\ param p_bias   Bias of the connection
        void addConnection(const QString& p_target, const bool p_isOutput, const int& p_layer,  const double& p_weight, const double& p_bias);

        //! \brief add a new connection
        //!\ param p_connection Connection to add
        void addConnection(const data::ConnectionData& p_connection);

    protected:
    private:

        // members
    protected:
    private:
        //! \brief name of the gene
        QString m_name;

        //! \brief mutation type
        double m_mutationValue = data::mutationTypeToDouble(data::MutationType::NO_MUTATION);

        //! \brief list of connection from this gene
        std::shared_ptr<QList<data::ConnectionData>> m_connectionList = std::make_shared<QList<data::ConnectionData>>();
    };

} // data

#endif // _data_GeneData_
