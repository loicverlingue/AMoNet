#ifndef _data_ConnectionData_
#define _data_ConnectionData_

//! \file ConnectionData.h
//! \brief Defines ConnectionData
//! \author http://www.surgiqual-institute.com/
//! \date March 2021.


// Library dependencies
#include <qobject.h>
#include <qstring.h>
// Project dependencies


namespace data
{
    //! \class ConnectionData
    //! \brief Handles the connection data
    class ConnectionData
    {
        // constructor / destructor / operator
    public:
        //! \brief Default constructor
        explicit ConnectionData();

        //! \brief Constructor
        //!\ param p_target Target of the connection
        //!\ param p_layer  Layer of the source of the connection
        //!\ param p_weight Weight of the connection
        //!\ param p_bias   Bias of the connection
        explicit ConnectionData(const QString& p_target, const bool p_isOutput, const int& p_layer, const double& p_weight, const double& p_bias);

        //! \brief Destructor
        virtual ~ConnectionData() = default;

        //! \brief Copy constructor
        //! \param[in] p_other Object to copy
        ConnectionData(const ConnectionData& p_other) = default; // To implement if copying is non-trivial

        //! \brief Copy assignment operator
        //! \param[in] p_other Object to copy
        ConnectionData& operator=(const ConnectionData& p_other) = default; // To implement if copying is non-trivial

        //! \brief Move constructor
        //! \param[in] p_other Object to move
        ConnectionData(ConnectionData&& p_other) = default; // To implement if moving is non trivial

        //! \brief Move assignment operator
        //! \param[in] p_other Object to move
        ConnectionData& operator=(ConnectionData&& p_other) = default; // To implement if moving is non trivial

        // get / set
    public:
        [[nodiscard]]
        //! \brief get the target
        //! \return the target name
        QString getTarget() const;

        [[nodiscard]]
        //! \brief get the layer
        //! \return the layer
        int getLayer() const;

        [[nodiscard]]
        //! \brief get the outup
        //! \return the output
        bool getIsOutput() const;

        [[nodiscard]]
        //! \brief get the weight
        //! \return the weight of the connection
        double getWeight() const;

        [[nodiscard]]
        //! \brief get the bias
        //! \return the bias of the connection
        double getBias() const;

        //! \brief Set the target of the connection
        //!\ param p_target Target of the connection
        void setTarget(const QString& p_target);

        //! \brief Set the layer of the connection (source)
        //!\ param p_layer Layer of the connection
        void setLayer(const int& p_layer);

        //! \brief Set the output of the connection
        //!\ param p_output output of the connection
        void setIsOutput(const bool p_isOutput);

        //! \brief Set the weight of the connection
        //!\ param p_weight Weight of the connection
        void setWeight(const double& p_weight);

        //! \brief Set the target of the connection
        //!\ param p_bias   Bias of the connection
        void setBias(const double& p_bias);

    protected:
    private:

        // methods / functions / slots
    public:
    protected:
    private:

        // members
    protected:
    private:
        //! \brief target of the connection
        QString m_target = "";

        //! \brief layer of the source of the connection
        int m_layer = 0;

        //! \brief true if the target is an output node, false otherwise
        bool m_isOutput = false;

        //! \brief Weight of the connection
        double m_weight = 0;
        
        //! \brief Bias of the connection
        double m_bias = 0;
    };

} // data

#endif // _data_ConnectionData_
