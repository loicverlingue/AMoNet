#ifndef _data_MutationType_
#define _data_MutationType_

//! \file MutationTypeClass.h
//! \brief Defines MutationTypeClass
//! \author http://www.surgiqual-institute.com/
//! \date March 2021.

// Library dependencies
#include <qobject.h>
// Project dependencies


namespace data
{
    //! \class MutationTypeClass
    //! \brief Handle the type of mutation
    class MutationTypeClass : public QObject
    {
        Q_OBJECT
        // constructor / destructor / operator
    public:
        //! \brief Default constructor
        MutationTypeClass(QObject* p_parent = nullptr) : QObject(p_parent) {}

      
        //! \enum MutationType
        //! \brief Represents the type of a mutation
        enum class MutationType : int
        {
            NO_MUTATION = 0,
            NON_PATHOGENIC_MUTATION,
            UNKNOWN_PATHOGENIC_MUTATION,
            PATHOGENIC_MUTATION
        };
        Q_ENUM(MutationType)
    };

    using MutationType = MutationTypeClass::MutationType;

    //! \brief convert a MutationType to an int
    int mutationTypeToInt(MutationType p_mutation);

    //! \brief convert an int to a MutationType
    MutationType mutationTypeFromInt(int p_mutation);

    //! \brief convert a MutationType to a double
    double mutationTypeToDouble(MutationType p_mutation);

    //! \brief convert a double to a MutationType
    MutationType mutationTypeFromDouble(double p_mutation);

} // data

#endif // _data_MutationType_
