//! \file MutationType.cpp
//! \brief Implements MutationType
//! \author http://www.surgiqual-institute.com/
//! \date Month YYYY.


// Library dependencies

// Project dependencies
#include "MutationType.h"


namespace data
{
	int mutationTypeToInt(MutationType p_mutation)
	{
		return static_cast<int>(p_mutation);
	}
	MutationType mutationTypeFromInt(int p_mutation)
	{
		switch (p_mutation)
		{
		case 0:
		{
			return MutationType::NO_MUTATION;
		}
		case 1:
		{
			return MutationType::NON_PATHOGENIC_MUTATION;
		}
		case 2:
		{
			return MutationType::UNKNOWN_PATHOGENIC_MUTATION;
		}
		case 3:
		{
			return MutationType::PATHOGENIC_MUTATION;
		}
		default:
			return MutationType::NO_MUTATION;
		}
	}
	double mutationTypeToDouble(MutationType p_mutation)
	{
		switch (p_mutation)
		{
		case MutationType::NO_MUTATION:
		{
			return 0.0;
		}
		case MutationType::NON_PATHOGENIC_MUTATION:
		{
			return 0.3;
		}
		case MutationType::UNKNOWN_PATHOGENIC_MUTATION:
		{
			return 0.6;
		}
		case MutationType::PATHOGENIC_MUTATION:
		{
			return 1.0;
		}
		default:
			return 0.0;
		}
	}
	MutationType mutationTypeFromDouble(double p_mutation)
	{
		if (p_mutation < 1e-4)
		{
			return MutationType::NO_MUTATION;
		}
		else if (p_mutation < 0.4)
		{
			return MutationType::NON_PATHOGENIC_MUTATION;
		}
		else if (p_mutation < 0.8)
		{
			return MutationType::UNKNOWN_PATHOGENIC_MUTATION;
		}
		else
		{
			return MutationType::PATHOGENIC_MUTATION;
		}
	}
} // data


