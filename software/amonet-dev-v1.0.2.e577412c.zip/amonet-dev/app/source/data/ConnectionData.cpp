//! \file ConnectionData.cpp
//! \brief Implements ConnectionData
//! \author http://www.surgiqual-institute.com/
//! \date March 2021.


// Library dependencies
#include <qloggingcategory.h>

// Project dependencies
#include "ConnectionData.h"
#include "io/LogService.h"
#include "io/Log.h"

namespace data
{

    ConnectionData::ConnectionData()
    {
    }

    ConnectionData::ConnectionData(const QString& p_target, const bool p_isOutput, const int& p_layer, const double& p_weight, const double& p_bias)
    {
        m_target = p_target;
        m_isOutput = p_isOutput;
        m_layer = p_layer;
        m_weight = p_weight;
        m_bias = p_bias;
    }

    QString ConnectionData::getTarget() const
    {
        return m_target;
    }

    int ConnectionData::getLayer() const
    {
        return m_layer;
    }

    bool ConnectionData::getIsOutput() const
    {
        return m_isOutput;
    }

    double ConnectionData::getWeight() const
    {
        return m_weight;
    }

    double ConnectionData::getBias() const
    {
        return m_bias;
    }

    void ConnectionData::setTarget(const QString& p_target)
    {
        m_target = p_target;
    }

    void ConnectionData::setLayer(const int& p_layer)
    {
        m_layer = p_layer;
    }

    void ConnectionData::setIsOutput(const bool p_isOutput)
    {
        m_isOutput = p_isOutput;
    }

    void ConnectionData::setWeight(const double& p_weight)
    {
        m_weight = p_weight;
    }

    void ConnectionData::setBias(const double& p_bias)
    {
        m_bias = p_bias;
    }

} // data


