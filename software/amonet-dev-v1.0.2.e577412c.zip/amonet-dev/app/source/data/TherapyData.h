#ifndef _data_TherapyData_
#define _data_TherapyData_

//! \file TherapyData.h
//! \brief Defines TherapyData
//! \author http://www.surgiqual-institute.com/
//! \date April 2021


// Library dependencies
#include <qobject.h>
#include <qstring.h>
#include <qmap.h>
// Project dependencies


namespace data
{
    //! \class TherapyData
    //! \brief Handle the therapy data
    class TherapyData
    {
        // constructor / destructor / operator
    public:
        //! \brief Default constructor
        explicit TherapyData();

        //! \brief Destructor
        virtual ~TherapyData() = default;

        //! \brief Copy constructor
        //! \param[in] p_other Object to copy
        TherapyData(const TherapyData& p_other) = default; // To implement if copying is non-trivial

        //! \brief Copy assignment operator
        //! \param[in] p_other Object to copy
        TherapyData& operator=(const TherapyData& p_other) = default; // To implement if copying is non-trivial

        //! \brief Move constructor
        //! \param[in] p_other Object to move
        TherapyData(TherapyData&& p_other) = default; // To implement if moving is non trivial

        //! \brief Move assignment operator
        //! \param[in] p_other Object to move
        TherapyData& operator=(TherapyData&& p_other) = default; // To implement if moving is non trivial

        // get / set
    public:
        //! \brief set the therapy name
        //! \param p_name name of the therapy
        void setName(const QString& p_name);

        //! \brief set the therapy's effect on genes
        //! \param p_effect list of effects
        void setEffectOnGenes(const QMap<QString, double>& p_effect);

        [[nodiscard]]
        //! \brief get the therapy name
        //! \return the therapy name
        QString getName() const;

        [[nodiscard]]
        //! \brief get the therapy effects
        //! \return the therapy effects
        QMap<QString, double> getEffectOnGenes() const;
    protected:
    private:

        // methods / functions / slots
    public:
    protected:
    private:

        // members
    protected:
    private:
        //! \brief name of the therapy
        QString m_name;

        //! \brief list of gene and effect
        QMap<QString, double> m_effectOnGenes;
    };

} // data

#endif // _data_TherapyData_
