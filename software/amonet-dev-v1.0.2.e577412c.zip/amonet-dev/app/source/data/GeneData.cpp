//! \file GeneData.cpp
//! \brief Implements GeneData
//! \author http://www.surgiqual-institute.com/
//! \date March 2021.


// Library dependencies
#include <qloggingcategory.h>

// Project dependencies
#include "GeneData.h"
#include "io/LogService.h"
#include "io/Log.h"

namespace data
{

    GeneData::GeneData()
    {
    }

    GeneData::GeneData(const QString& p_name)
    {
        setName(p_name);
    }

    void GeneData::setName(const QString& p_name)
    {
        m_name = p_name;
    }

    void GeneData::setMutationValue(const double p_mutation)
    {
        m_mutationValue = p_mutation;
    }

    QString GeneData::getName() const
    {
        return m_name;
    }

    std::shared_ptr<QList<data::ConnectionData>> GeneData::getConnections() const
    {
        return m_connectionList;
    }

    double GeneData::getMutationValue() const
    {
        return m_mutationValue;
    }

    void GeneData::addConnection(const QString& p_target, const bool p_isOutput, const int& p_layer, const double& p_weight, const double& p_bias)
    {
        data::ConnectionData connection(p_target, p_isOutput, p_layer, p_weight, p_bias);
        m_connectionList->append(connection);
    }

    void GeneData::addConnection(const data::ConnectionData& p_connection)
    {
        data::ConnectionData connection(p_connection.getTarget(), p_connection.getIsOutput(), p_connection.getLayer(), p_connection.getWeight(), p_connection.getBias());
        m_connectionList->append(connection);
    }

} // data


