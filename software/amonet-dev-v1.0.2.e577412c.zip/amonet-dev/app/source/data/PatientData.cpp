//! \file PatientData.cpp
//! \brief Implements PatientData
//! \author http://www.surgiqual-institute.com/
//! \date March 2021.


// Library dependencies
#include <qloggingcategory.h>

// Project dependencies
#include "PatientData.h"
#include "io/Importer.h"
#include "io/ImporterException.h"


namespace data
{

    PatientData::PatientData(const int p_intervalDuration, QObject* p_parent)
        : QObject(p_parent),
        m_intervalDuration{p_intervalDuration},
        m_isLoadingSuccessful{true}
    {
    }

    PatientData::PatientData(QObject* p_parent)
        : QObject(p_parent),
        m_isLoadingSuccessful{ true }
    {
    }

    PatientData::PatientData(const QString p_dataPath, QObject* p_parent)
        : QObject{p_parent}
    {
        try
        {
            int intervalDuration = io::Importer::loadOutputTimeIntervalFromCsv(p_dataPath);
            m_intervalDuration = intervalDuration;
            m_isLoadingSuccessful = true;
        }
        catch (io::CImporterException& p_importerException)
        {
            qInfo() << p_importerException.what();
            m_isLoadingSuccessful = false;
            m_intervalDuration = 0;
        }
    }

    void PatientData::setSurvivalPrediction(const data::NetworkStateData& p_survPred)
    {
        m_survPred = p_survPred;
        emit signalSurvivalPredictionChanged();
    }

    void PatientData::setLastName(const QString& p_lastName)
    {
        m_lastName = p_lastName;
    }

    void PatientData::setFirstName(const QString& p_firstName)
    {
        m_firstName = p_firstName;
    }

    void PatientData::setIdentifier(const QString& p_identifier)
    {
        m_identifier = p_identifier;
    }

    void PatientData::setClinicalInfo(const QString& p_clinicalInfo)
    {
        m_clinicalInfo = p_clinicalInfo;
    }

    int PatientData::getIntervalDuration() const
    {
        return m_intervalDuration;
    }

    data::NetworkStateData PatientData::getSurvivalPrediction() const
    {
        return m_survPred;
    }

    QString PatientData::getLastName() const
    {
        return m_lastName;
    }

    QString PatientData::getFirstName() const
    {
        return m_firstName;
    }

    QString PatientData::getIdentifier() const
    {
        return m_identifier;
    }

    QString PatientData::getClinicalInfo() const
    {
        return m_clinicalInfo;
    }

    bool PatientData::getIsLoadingSuccessful() const
    {
        return m_isLoadingSuccessful;
    }

} // data


