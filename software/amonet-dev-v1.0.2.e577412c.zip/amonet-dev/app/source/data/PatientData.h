#ifndef _data_PatientData_
#define _data_PatientData_

//! \file PatientData.h
//! \brief Defines PatientData
//! \author http://www.surgiqual-institute.com/
//! \date March 2021.


// Library dependencies
#include <qobject.h>
#include <qstring.h>

// Project dependencies
#include "data/NetworkStateData.h"

namespace data
{
    //! \class PatientData
    //! \brief ...
    class PatientData : public QObject
    {
        Q_OBJECT
        // constructor / destructor / operator
    public:
        //! \brief Default constructor
        explicit PatientData(const int p_intervalDuration, QObject* p_parent = nullptr);

        //! \brief Default constructor
        explicit PatientData(const QString p_dataPath, QObject* p_parent = nullptr);

        //! \brief Default constructor
        explicit PatientData(QObject* p_parent = nullptr);

        //! \brief Destructor
        virtual ~PatientData() = default;

        //! \brief Copy constructor
        //! \param[in] p_other Object to copy
        PatientData(const PatientData& p_other) = default; // To implement if copying is non-trivial

        //! \brief Copy assignment operator
        //! \param[in] p_other Object to copy
        PatientData& operator=(const PatientData& p_other) = default; // To implement if copying is non-trivial

        //! \brief Move constructor
        //! \param[in] p_other Object to move
        PatientData(PatientData&& p_other) = default; // To implement if moving is non trivial

        //! \brief Move assignment operator
        //! \param[in] p_other Object to move
        PatientData& operator=(PatientData&& p_other) = default; // To implement if moving is non trivial

        // get / set
    public:
        //! \brief set the survival prediction
        //! \param p_survPred survival prediction 
        void setSurvivalPrediction(const data::NetworkStateData& p_survPred);

        //! \brief set the patient's last name
        //! \param patient's last name
        void setLastName(const QString& p_lastName);

        //! \brief set the patient's first name
        //! \param patient's first name
        void setFirstName(const QString& p_firstName);

        //! \brief set the patient's identifier
        //! \param patient's identifier
        void setIdentifier(const QString& p_identifier);

        //! \brief set the patient's clinical info
        //! \param patient's clinical info
        void setClinicalInfo(const QString& p_clinicalInfo);

        [[nodiscard]]
        //! \brief get the duraction of the interval
        //! \return the duration of an interval
        int getIntervalDuration() const;

        [[nodiscard]]
        //! \brief get the survival prediction
        //! \return the survival prediction
        data::NetworkStateData getSurvivalPrediction() const;
        
        [[nodiscard]]
        //! \brief get the last name
        //! \return the last name
        QString getLastName() const;

        [[nodiscard]]
        //! \brief get the first name
        //! \return the first name
        QString getFirstName() const;

        [[nodiscard]]
        //! \brief get the identifier
        //! \return the identifer
        QString getIdentifier() const;

        [[nodiscard]]
        //! \brief get the clinical info
        //! \return the clinical info
        QString getClinicalInfo() const;

        [[nodiscard]]
        //! \brief get the loading succes
        bool getIsLoadingSuccessful() const;

    protected:
    private:

    public:
    signals:
        void signalSurvivalPredictionChanged();

        // methods / functions / slots
    public:
    protected:
    private:

        // members
    protected:
    private:
        //! \brief Patient's last name
        QString m_lastName = "";

        //! \brief Patient's first name
        QString m_firstName = "";

        //! \brief Patient's id
        QString m_identifier = "";

        //! \brief Patient's clinical informations
        QString m_clinicalInfo = "";

        //! \brief duration (in month) of a interval  
        int m_intervalDuration;

        //! \brief survival prediction
        data::NetworkStateData m_survPred;

        //! \brief true if the network is successfully loaded
        bool m_isLoadingSuccessful = false;
    };

} // data

#endif // _data_PatientData_
