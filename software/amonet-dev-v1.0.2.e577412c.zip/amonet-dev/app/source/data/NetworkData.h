#ifndef _data_NetworkData_
#define _data_NetworkData_

//! \file NetworkData.h
//! \brief Defines NetworkData
//! \author http://www.surgiqual-institute.com/
//! \date March 2021.


// Library dependencies
#include <qobject.h>
#include <qstring.h>
#include <qlist.h>
#include <qfuturesynchronizer.h>
// Project dependencies
#include "data/GeneData.h"
#include "data/TherapyData.h"
namespace data
{
    //! \class NetworkData
    //! \brief ...
    class NetworkData : public QObject
    {
        Q_OBJECT
        // constructor / destructor / operator
    public:
        //! \brief Default constructor
        explicit NetworkData(const QString& p_data, QObject* p_parent = nullptr);

        explicit NetworkData(QObject* p_parent = nullptr);

        //! \brief Destructor
        virtual ~NetworkData() = default;

        //! \brief Copy constructor
        //! \param[in] p_other Object to copy
        NetworkData(const NetworkData& p_other) = default; // To implement if copying is non-trivial

        //! \brief Copy assignment operator
        //! \param[in] p_other Object to copy
        NetworkData& operator=(const NetworkData& p_other) = default; // To implement if copying is non-trivial

        //! \brief Move constructor
        //! \param[in] p_other Object to move
        NetworkData(NetworkData&& p_other) = default; // To implement if moving is non trivial

        //! \brief Move assignment operator
        //! \param[in] p_other Object to move
        NetworkData& operator=(NetworkData&& p_other) = default; // To implement if moving is non trivial

        // get / set
    public:
        [[nodiscard]]
        //! \brief get the list of genes' name
        std::shared_ptr<QStringList> getGenesNames() const;

        [[nodiscard]]
        //! \brief get the list of genes' name
        std::shared_ptr<QList<data::GeneData>> getGenes() const;

        [[nodiscard]]
        //! \brief get the loading succes
        bool getIsLoadingSuccessful() const;


        [[nodiscard]]
        //! \brief get the number of layer in the network
        int getNbOfLayers() const;

        [[nodiscard]]
        //! \brief get the current therapy
        std::shared_ptr<data::TherapyData> getTherapy() const;

    protected:
    private:

    signals:
        void signalNetworkChanged();
        void signalMutationChanged();

        // methods / functions / slots
    public:
        //! \brief modify a gene's mutation
        //! \param p_index index of the gene to modify
        //! \param p_mutationValue value of the new mutation
        void modifyGeneMutation(int p_index, double p_mutationValue);

        //! \brief extract the genes of a chosen layer
        //! \param p_layer layer to extract
        //! \return the list of genes in the layer 
        QList<data::GeneData> extractLayer(int p_layer);

        //! \brief extract the genes targeted by the chosen layer
        //! \param p_layer layer from which the targets will be extracted
        //! \return the list of target genes of the layer 
        QStringList extractTargets(int p_layer);

        //! \brief update the current therapy
        //! \param p_name name of the therapy
        //! \param p_effect list of effects on corresponding genes
        void updateTherapy(const QString& p_name, const QMap<QString, double>& p_effect);

    protected:
    private:
        //! \brief load the network from the decrypted data
        //! \param p_data decrypted data of he network
        void load(const QString& p_data);

        // members
    protected:
    private:
        //! \brief List of genes presents in the network
        std::shared_ptr<QList<data::GeneData>> m_geneList = std::make_shared<QList<data::GeneData>>();

        //! \brief List of genes' names presents in the network
        std::shared_ptr<QStringList> m_geneNameList = std::make_shared<QStringList>();

        //! \brief list of layer in the network
        QList<int> m_layerList;

        //! \brief therapy applied to the network
        std::shared_ptr<data::TherapyData> m_therapy = std::make_shared<data::TherapyData>();

        //! \brief loading synchroniser
        QFutureSynchronizer<void> m_loadingSynch;

        //! \brief true if the network is successfully loaded
        bool m_isLoadingSuccessful = false;
    };

} // data

#endif // _data_NetworkData_
