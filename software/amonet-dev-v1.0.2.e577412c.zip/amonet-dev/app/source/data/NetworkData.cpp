//! \file NetworkData.cpp
//! \brief Implements NetworkData
//! \author http://www.surgiqual-institute.com/
//! \date March 2021.


// Library dependencies
#include <qloggingcategory.h>
#include <QtConcurrent/qtconcurrentrun.h>
#include <qgenericmatrix.h>

// Project dependencies
#include "NetworkData.h"
#include "io/LogService.h"
#include "io/Log.h"

namespace data
{

    NetworkData::NetworkData(const QString& p_data, QObject* p_parent)
        : QObject(p_parent)
    {
        load(p_data);
    }

    NetworkData::NetworkData(QObject* p_parent)
        : QObject(p_parent)
    {
    }

    std::shared_ptr<QStringList> NetworkData::getGenesNames() const
    {
        return m_geneNameList;
    }

    std::shared_ptr<QList<data::GeneData>> NetworkData::getGenes() const
    {
        return m_geneList;
    }

    bool NetworkData::getIsLoadingSuccessful() const
    {
        return m_isLoadingSuccessful;
    }

    int NetworkData::getNbOfLayers() const
    {
        return m_layerList.size();
    }

    std::shared_ptr<data::TherapyData> NetworkData::getTherapy() const
    {
        return m_therapy;
    }

    void NetworkData::modifyGeneMutation(int p_index, double p_mutationValue)
    {
        m_geneList->operator[](p_index).setMutationValue(p_mutationValue);
        emit signalMutationChanged();
    }

    QList<data::GeneData> NetworkData::extractLayer(int p_layer)
    {
        QList<data::GeneData> genesInLayer;

        // if the layer doesn't exist in the network, return an empty list
        if (!m_layerList.contains(p_layer))
        {
            io::LogService::getInstance().LogError("Error while extracting layer: layer not in the current network");
            return genesInLayer;
        }
        
        for (int i = 0; i < m_geneList->size(); i++)
        {
            // init the current gene data
            data::GeneData currentGene(m_geneNameList->at(i));
            currentGene.setMutationValue(m_geneList->at(i).getMutationValue());

            bool isGeneInLayer = false;

            // retrieve the connections of the current gene
            auto connections = m_geneList->at(i).getConnections();

            for (int j = 0; j < connections->size(); j++)
            {
                // if the current connection is from the desired layer, add it to the gene data
                if (connections->at(j).getLayer() == p_layer)
                {
                    currentGene.addConnection(connections->at(j));
                    isGeneInLayer = true;
                }
            }

            // if the gene is in the layer, add it to the list
            if (isGeneInLayer)
            {
                genesInLayer.append(currentGene);
            }
        }

        return genesInLayer;
    }

    QStringList NetworkData::extractTargets(int p_layer)
    {
        QStringList targets;

        // if the layer doesn't exist in the network, return an empty list
        if (!m_layerList.contains(p_layer))
        {
            io::LogService::getInstance().LogError("Error while extracting layer: layer not in the current network");
            return targets;
        }

        for (int i = 0; i < m_geneList->size(); i++)
        {
            auto connections = m_geneList->at(i).getConnections();
            for (int j = 0; j < connections->size(); j++)
            {
                if ((connections->at(j).getLayer() == p_layer) && (!targets.contains(connections->at(j).getTarget())))
                {
                    targets.append(connections->at(j).getTarget());
                }
            }
        }

        return targets;
    }

    void NetworkData::updateTherapy(const QString& p_name, const QMap<QString, double>& p_effect)
    {
        m_therapy->setName(p_name);
        m_therapy->setEffectOnGenes(p_effect);
    }

    void NetworkData::load(const QString& p_data)
    {

        m_loadingSynch.addFuture(QtConcurrent::run(
            [this, p_data]()
            {
                try
                {
                    // Split the data into a list of lines
                    QStringList list = p_data.split("\r\n");

                    // remove the last ligne (artefact)
                    list.removeLast();

                    for (int i = 1; i < list.size(); i++)
                    {
                        // clean the data
                        list.operator[](i).remove("\"");

                        // the current line is structured as follows: colonne1Name, source, interaction_type, target, isOutput, layer, weight, bias,... 
                        // create a sub list 
                        QStringList subList = list.at(i).split(",");
                        QString geneName = subList.at(1);
                        QString geneTarget = subList.at(3);
                        bool geneIsOutput = (subList.at(4) == "TRUE");
                        int geneLayer = subList.at(5).toInt();
                        double geneWeight = subList.at(6).toDouble();
                        double geneBias = subList.at(7).toDouble();
                        if (m_geneNameList->contains(geneName))
                        {
                            // if the gene if already in the gene list, only add it's new connection
                            int geneIndex = m_geneNameList->indexOf(subList.at(1));
                            m_geneList->operator[](geneIndex).addConnection(geneTarget, geneIsOutput, geneLayer, geneWeight, geneBias);
                        }
                        else
                        {
                            //if the gene is not already in the list, create it and add it to the lists
                            data::GeneData newGene(geneName);
                            newGene.addConnection(geneTarget, geneIsOutput, geneLayer, geneWeight, geneBias);
                            m_geneList->append(newGene);
                            m_geneNameList->append(geneName);
                        }

                        // add the layer nb to the layer list if not already present
                        if (!m_layerList.contains(geneLayer))
                        {
                            m_layerList.append(geneLayer);
                        }
                    }

                    m_isLoadingSuccessful = true;
                    io::LogService::getInstance().LogInfo("Network succesfully loaded");
                    emit signalNetworkChanged();
                }
                catch (const std::exception& e)
                {
                    m_isLoadingSuccessful = false;
                    qCritical() << "Error loading network data :\n" << e.what();
                }
  
            }
        ));
    }

} // data


