// STL
#include <unordered_map>

// Qt

// Library dependencies

// Project dependencies
#include "LogLevel.h"

namespace io {
    CLogLevel::ELogLevel CLogLevel::FromString(const std::string &p_DeviceName)
    {
        static std::unordered_map<std::string, CLogLevel::ELogLevel> const l_Devices = {
            {"DEBUG", CLogLevel::ELogLevel::DEBUG},
            {"VERBOSE", CLogLevel::ELogLevel::VERBOSE},
            {"INFO", CLogLevel::ELogLevel::INFO},
            {"WARNING", CLogLevel::ELogLevel::WARNING},
            {"ERROR", CLogLevel::ELogLevel::ERROR}};

        auto l_FindDevice = l_Devices.find(p_DeviceName);
        if (l_FindDevice != l_Devices.end()) {
            return l_FindDevice->second;
        }
        else {
            return CLogLevel::ELogLevel::INFO;
        }
    }

} // namespace corin::core::log
