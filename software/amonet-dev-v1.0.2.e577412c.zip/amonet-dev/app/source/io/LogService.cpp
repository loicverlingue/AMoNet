#include "LogService.h"
#include "Log.h"

namespace io 
{
    CLog& LogService::getInstance() 
    {
        static CLog instance;
        return instance;
    }

}