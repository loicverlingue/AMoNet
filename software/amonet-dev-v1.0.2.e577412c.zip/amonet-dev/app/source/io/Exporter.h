#ifndef _io_Exporter_
#define _io_Exporter_

//! \file Exporter.h
//! \brief Defines Exporter
//! \author http://www.surgiqual-institute.com/
//! \date April 2021


// Qt
#include <qstring.h>
#include <qimage.h>
// Project dependencies
#include "data/PatientData.h"
#include "data/NetworkStateData.h"
namespace io
{
    //! \class Exporter
    //! \brief Handle the export of data 
    class Exporter
    {
        // constructor / destructor / operator
    public:
        //! \brief Default constructor
        explicit Exporter() = default;

        //! \brief Destructor
        virtual ~Exporter() = default;

        //! \brief Copy constructor
        //! \param[in] p_other Object to copy
        Exporter(const Exporter& p_other) = default; // To implement if copying is non-trivial

        //! \brief Copy assignment operator
        //! \param[in] p_other Object to copy
        Exporter& operator=(const Exporter& p_other) = default; // To implement if copying is non-trivial

        //! \brief Move constructor
        //! \param[in] p_other Object to move
        Exporter(Exporter&& p_other) = default; // To implement if moving is non trivial

        //! \brief Move assignment operator
        //! \param[in] p_other Object to move
        Exporter& operator=(Exporter&& p_other) = default; // To implement if moving is non trivial

        // get / set
    public:
    protected:
    private:

        // methods / functions / slots
    public:
        //! \brief export the patient data as text file
        //! \param p_data patient data to export
        //! \param p_path path of the export folder
        //! \param p_fileName name of the file (without extension)
        static void exportPatientData(std::shared_ptr<data::PatientData> p_data,const QString& p_path, const QString& p_fileName);
        
        //! \brief export the prediction as csv file
        //! \param p_data survival values
        //! \param p_interval time interval in month
        //! \param p_path path of the export folder
        //! \param p_fileName name of the file (without extension)
        static void exportPrediction(const data::NetworkStateData& p_data, const int& p_interval, const QString& p_path, const QString& p_fileName);

        //! \brief export the prediction as csv file
        //! \param p_data survival values
        //! \param p_interval time interval in month
        //! \param p_path path of the export folder
        //! \param p_fileName name of the file (without extension)
        static void exportConvergence(const data::NetworkStateData& p_data, const int& p_interval, const QString& p_path, const QString& p_fileName);
        
        //! \brief export the survival graph as png file
        //! \param p_image image of the graph to export
        //! \param p_path path of the export folder
        //! \param p_fileName name of the file (without extension)
        static void exportGraph(const QImage& p_image, const QString& p_path, const QString& p_fileName);

        //! \brief export mutations data to csv
        //! \param p_therapyEffect a map of <GeneName, MutationValue> from the patient
        //! \param p_path path of the export folder
        //! \param p_fileName name of the file (without extension)
        static void exportPatientMutationsToCSV(QMap<QString, double>& p_mutationData, const QString& p_path, const QString& p_fileName);
    protected:
    private:

        // members
    protected:
    private:

    };

} // io

#endif // _io_Exporter_
