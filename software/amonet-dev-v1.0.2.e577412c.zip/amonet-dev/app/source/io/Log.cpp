// STL
#include <filesystem>

// Qt

// Library dependencies

// Project dependencies
#include "Log.h"
#include "LogException.h"
#include "utils/Exceptions.h"

namespace io {

    CLog::~CLog()
    {
        if (!m_pLogger) {
            LogInfo("Closing log file...");
            m_pLogger->close();
        }
    }

    void CLog::Initialize(const std::string &p_LogDirectory, const std::string &p_LogNameWithoutExtension,
                          CLogLevel::ELogLevel p_MinimumLogLevel)
    {
#if defined(__APPLE__)
        std::filesystem::path l_LogDirectory(p_LogDirectory);
#else
        std::filesystem::path l_LogDirectory(std::filesystem::absolute(p_LogDirectory));
#endif
        std::cout << "CLog::Initialize >> l_LogDirectory = " << l_LogDirectory << std::endl;
        
        std::cout << "CLog::Initialize >> l_LogDirectory exists? " << std::to_string(std::filesystem::exists(l_LogDirectory)) << std::endl;
        
        if (!std::filesystem::exists(l_LogDirectory)) {
            bool l_DirCreationSuccessful = std::filesystem::create_directories(l_LogDirectory);
            std::cout << "Created directory: " << l_LogDirectory << "? " << std::to_string(l_DirCreationSuccessful) << std::endl;
        }

        m_pLogger->setFilePath(l_LogDirectory.string().c_str());

        QString l_LogFileNameWithExtension(p_LogNameWithoutExtension.c_str());
        l_LogFileNameWithExtension.append(".log");
        m_pLogger->setFileName(l_LogFileNameWithExtension);
        m_pLogger->setLogLevels(sqi::log::LogLevel::LogAll);
        m_pLogger->enableFlushAllInRelease();

        if (!m_pLogger->open()) {
            THROW_VERBOSE_EXCEPTION(CLogException, "Failed to open log file.");
        }

        m_bIsInitialized = true;
        m_CurrentLevel = p_MinimumLogLevel;
    }

    void CLog::LogDebug(const QString &p_Message)
    {
        LogDefault(CLogLevel::ELogLevel::DEBUG, p_Message);
    }

    void CLog::LogVerbose(const QString &p_Message)
    {
        LogDefault(CLogLevel::ELogLevel::VERBOSE, p_Message);
    }

    void CLog::LogInfo(const QString &p_Message)
    {
        LogDefault(CLogLevel::ELogLevel::INFO, p_Message);
    }

    void CLog::LogWarning(const QString &p_Message)
    {
        LogDefault(CLogLevel::ELogLevel::WARNING, p_Message);
    }

    void CLog::LogError(const QString& p_Message)
    {
        LogDefault(CLogLevel::ELogLevel::ERROR, p_Message);
    }

    void CLog::LogDefault(CLogLevel::ELogLevel p_LogLevel, const QString &p_Message)
    {
        if (p_LogLevel >= m_CurrentLevel) {
            m_pLogger->log(GeneratePrefix(p_LogLevel), p_Message);
        }
    }

    CLog::CLog()
    {
        m_pLogger = std::make_unique<sqi::log::LogData>();
        m_bIsInitialized = false;
        m_CurrentLevel = CLogLevel::ELogLevel::INFO;
    }

    QString CLog::GeneratePrefix(CLogLevel::ELogLevel p_Level)
    {
        switch (p_Level) {
            case CLogLevel::ELogLevel::VERBOSE:
                return PREFIX_VERBOSE;
            case CLogLevel::ELogLevel::DEBUG:
                return PREFIX_DEBUG;
            case CLogLevel::ELogLevel::INFO:
                return PREFIX_INFO;
            case CLogLevel::ELogLevel::WARNING:
                return PREFIX_WARNING;
            default:
                [[fallthrough]];
            case CLogLevel::ELogLevel::ERROR:
                return PREFIX_ERROR;
        }
    }

    CLogLevel::ELogLevel CLog::GetCurrentLevel() const
    {
        return m_CurrentLevel;
    }

    void CLog::SetCurrentLevel(const CLogLevel::ELogLevel &p_Level)
    {
        m_CurrentLevel = p_Level;
    }
} // namespace corin::core::log
