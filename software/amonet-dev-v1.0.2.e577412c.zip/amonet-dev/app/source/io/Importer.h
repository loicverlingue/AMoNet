#ifndef _io_Importer_
#define _io_Importer_

//! \file Importer.h
//! \brief Defines Importer
//! \author http://www.surgiqual-institute.com/
//! \date March 2021.


// Library dependencies
#include <qobject.h>
#include <qmap.h>
#include <qstring.h>
// Project dependencies


namespace io
{
    //! \class Importer
    //! \brief Class used to handle data importation
    class Importer
    {
        // constructor / destructor / operator
    public:
        //! \brief Default constructor
        explicit Importer()= default;

        //! \brief Destructor
        virtual ~Importer() = default;

        //! \brief Copy constructor
        //! \param[in] p_other Object to copy
        Importer(const Importer& p_other) = default; // To implement if copying is non-trivial

        //! \brief Copy assignment operator
        //! \param[in] p_other Object to copy
        Importer& operator=(const Importer& p_other) = default; // To implement if copying is non-trivial

        //! \brief Move constructor
        //! \param[in] p_other Object to move
        Importer(Importer&& p_other) = default; // To implement if moving is non trivial

        //! \brief Move assignment operator
        //! \param[in] p_other Object to move
        Importer& operator=(Importer&& p_other) = default; // To implement if moving is non trivial

        // get / set
    public:
    protected:
    private:

        // methods / functions / slots
    public:
        //! \brief load mutations data from csv
        //! \param p_path path of the file to load
        //! \return a map of <GeneName, MutationValue>
        static QMap<QString, double> loadPatientMutationsFromCSV(const QString& p_path, bool p_isTherapy);

        //! \brief load list of training mutation from csv
        //! \param p_path path of the file to load
        static QStringList loadTrainingDataMutationsFromCSV(const QString& p_path);

        //! \brief load testing patients data (MUT or outputs)
        //! \param p_path path of the file to load
        //! \return a map of <PatientName, map of <GeneName or OutputName, Value>>
        static QMap<QString,QMap<QString, double>> loadTestPatientsDataFromCSV(const QString& p_path);


        //! \brief decrypte the network data
        static QString decryptNetworkData(const QString& p_path);

        //! \brief compute the time interval from the csv
        static int loadOutputTimeIntervalFromCsv(const QString& p_path);
    protected:
    private:

        // members
    protected:
    private:

    };

} // io

#endif // _io_Importer_
