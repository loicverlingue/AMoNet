//! \file Importer.cpp
//! \brief Implements Importer
//! \author http://www.surgiqual-institute.com/
//! \date March 2021.


// Library dependencies
#include <qfile.h>
#include <qloggingcategory.h>
// Project dependencies
#include "Importer.h"
#include "ImporterException.h"
#include "io/LogService.h"
#include "io/Log.h"
#include "encryption/SimpleCrypt.h"
#include "def/EncryptionDefinitions.h"
#include "utils/Exceptions.h"

namespace io
{
	QMap<QString, double> Importer::loadPatientMutationsFromCSV(const QString& p_path, bool p_isTherapy)
	{
        QMap<QString, double> mutationList;
        std::vector<double> checkTherapy = std::vector<double>{-1, 1};
        double precision = 1e-4;
		
        QFile file(p_path);
		if (!file.open(QIODevice::ReadOnly))
		{
            THROW_VERBOSE_EXCEPTION(CImporterException, "Cannot open .csv file");
		}
        else
        {
            // read the file data
            QString fileData = file.readAll();
            file.close();

            // convert the raw data into list of lines
            QStringList listData = fileData.split("\r\n");

            if (listData.size() <= 1) 
            {
                listData = fileData.split("\n");
                if (listData.size() <= 1)
                {
                    THROW_VERBOSE_EXCEPTION(CImporterException, "Bad data inside CSV");
                }
            }

            for (int i = 1; i < listData.size(); i++)
            {
                // clean the data
                listData.operator[](i).remove("\"");

                QStringList subData = listData.at(i).split(",");
                if (subData.size() == 2)
                {
                    bool isConverted = false;
                    double value = 0;
                    if (!p_isTherapy && subData.at(1).trimmed() == "NA")
                    {
                        value = 0;
                    }
                    else
                    {
                        value = subData.at(1).toDouble(&isConverted);
                        if (!isConverted)
                        {
                            if (p_isTherapy && std::find(checkTherapy.begin(), checkTherapy.end(), value) == checkTherapy.end())
                            {
                                THROW_VERBOSE_EXCEPTION(CImporterException, "Bad data inside CSV");
                            }
                            else if (!p_isTherapy && (value < -precision || value > 1.0 + precision))
                            {
                                THROW_VERBOSE_EXCEPTION(CImporterException, "Bad data inside CSV");
                            }
                        }
                    }
                    mutationList.insert(subData.at(0), value);
                }
                else if(!listData.at(i).isEmpty())
                {
                    THROW_VERBOSE_EXCEPTION(CImporterException, "Bad data inside CSV");
                }
            }
        }

        return mutationList;
	}
    
    QMap<QString, QMap<QString, double>> Importer::loadTestPatientsDataFromCSV(const QString& p_path)
    {
        QMap<QString, QMap<QString, double>> patientsMUT;

        QFile file(p_path);
        if (!file.open(QIODevice::ReadOnly))
        {
            THROW_VERBOSE_EXCEPTION(CImporterException, "Cannot open .csv file");
        }
        else
        {
            // read the file data
            QString fileData = file.readAll();
            file.close();

            // convert the raw data into list of lines
            QStringList listData = fileData.split("\r\n");

            if (listData.size() <= 1)
            {
                listData = fileData.split("\n");
                if (listData.size() <= 1)
                {
                    THROW_VERBOSE_EXCEPTION(CImporterException, "Bad data inside CSV");
                }
            }

            listData.removeLast();
            
            // clean name list
            listData.operator[](0).remove("\"");
            QStringList geneNameList = listData.at(0).split(",");

            if (listData.size() <= 1) 
            {
                THROW_VERBOSE_EXCEPTION(CImporterException, "Bad data inside CSV");
            }

            // parse all patients
            for (int i = 1; i < listData.size(); i++)
            {
                // clean the data
                listData.operator[](i).remove("\"");
                QStringList subData = listData.at(i).split(",");
                QMap<QString, double> subPatientData;
                
                // parse all genes/output
                for (int j = 1; j < subData.size(); j++)
                {
                    QString val = subData.at(j);
                    if (val == "NA")
                    {
                        val = "0.0";
                    }
                    subPatientData.insert(geneNameList.at(j), val.toDouble());
                }
                patientsMUT.insert(subData.at(0), subPatientData);
            }
        }
        return patientsMUT;
    }

    QString Importer::decryptNetworkData(const QString& p_path)
    {
        std::cout << "Loading network data form: " << p_path.toStdString() << std::endl;
        
        // path :"encrypted_AMoNet_network.csv"
        QFile file(p_path);
        if (!file.open(QIODevice::ReadOnly))
        {
            io::LogService::getInstance().LogError("Cannot open encrypted file");
            THROW_VERBOSE_EXCEPTION(CImporterException, "Cannot open encrypted file");
        }

        // Read file
        QByteArray encryptedData = file.readAll();
        file.close();

        // Decrypt data
        SimpleCrypt crypto(def::AMONET_ENCRYPT_KEY);
        QString decryptedFileContent = crypto.decryptToString(encryptedData);
        if (decryptedFileContent.isEmpty())
        {
            io::LogService::getInstance().LogError("Cannot decrypted file");
            THROW_VERBOSE_EXCEPTION(CImporterException, "Cannot decrypted file");
        }
        io::LogService::getInstance().LogInfo("Data decrypted");
        return decryptedFileContent;
    }

    int Importer::loadOutputTimeIntervalFromCsv(const QString& p_path)
    {
        int timeInterval = 0;
        int total = 0;
        double totalTime = 0.;

        QFile file(p_path);
        if (!file.open(QIODevice::ReadOnly))
        {
            THROW_VERBOSE_EXCEPTION(CImporterException, "Cannot open .csv file");
        }
        else
        {
            // read the file data
            QString fileData = file.readAll();
            file.close();

            // convert the raw data into list of lines
            QStringList listData = fileData.split("\r\n");

            if (listData.size() <= 2)
            {
                listData = fileData.split("\n");
                if (listData.size() <= 2)
                {
                    THROW_VERBOSE_EXCEPTION(CImporterException, "Bad data inside CSV");
                }
            }

            for (int i = 2; i < listData.size(); i++)
            {
                // clean the data
                listData.operator[](i).remove("\"");
                if (!listData.at(i).isEmpty()) {
                    bool isConverted1{}, isConverted2{};
                    double result = listData.at(i).toDouble(&isConverted1) - listData.at(i - 1).toDouble(&isConverted2);
                    if (isConverted1 && isConverted2) {
                        totalTime += result;
                        ++total;
                    }
                    else 
                    {
                        THROW_VERBOSE_EXCEPTION(CImporterException, "Bad data inside CSV");
                    }
                }
            }
            if (total != 0) {
                timeInterval = totalTime / total;
            }
        }

        return timeInterval;
    }

    QStringList Importer::loadTrainingDataMutationsFromCSV(const QString& p_path)
    {
        QStringList mutationList;

        QFile file(p_path);
        if (!file.open(QIODevice::ReadOnly))
        {
            THROW_VERBOSE_EXCEPTION(CImporterException, "Cannot open .csv file");
        }
        else
        {
            // read the file data
            QString fileData = file.readAll();
            file.close();

            // convert the raw data into list of lines
            QStringList listData = fileData.split("\r\n");

            if (listData.size() <= 1)
            {
                listData = fileData.split("\n");
                if (listData.size() <= 1)
                {
                    THROW_VERBOSE_EXCEPTION(CImporterException, "Bad data inside CSV");
                }
            }

            for (int i = 1; i < listData.size(); i++)
            {
                // clean the data
                listData.operator[](i).remove("\"");

                if (!listData.at(i).isEmpty()) {
                    mutationList.push_back(listData.at(i));
                }
            }
        }

        return mutationList;
    }
} // io


