//! \file Exporter.cpp
//! \brief Implements Exporter
//! \author http://www.surgiqual-institute.com/
//! \date April 2021


// Qt
#include <qfile.h>
#include <qtextstream.h>
#include <qloggingcategory.h>

// Project dependencies
#include "Exporter.h"


namespace io
{
	void Exporter::exportPatientData(std::shared_ptr<data::PatientData> p_data, const QString& p_path, const QString& p_fileName)
	{
		QFile file(p_path + "/" + p_fileName + ".txt");
		if (file.open(QFile::WriteOnly | QFile::Text))
		{
			QTextStream stream(&file);

			stream << "Patient's Data \n\n";
			stream << "Last name: " << p_data->getLastName() + "\n\n";
			stream << "First name: " << p_data->getFirstName() + "\n\n";
			stream << "Identifier: " << p_data->getIdentifier() + "\n\n";
			stream << "Clinical Info: " << p_data->getClinicalInfo();
		}
		else
		{
			qInfo() << "Error: cannot write text file";
		}
		file.close();
	}
	void Exporter::exportPrediction(const data::NetworkStateData& p_data, const int& p_interval, const QString& p_path, const QString& p_fileName)
	{
		QFile file(p_path + "/" + p_fileName + ".csv");
		if (file.open(QFile::WriteOnly))
		{
			QTextStream stream(&file);
			stream << "\"Time Interval (in month)\",\"Probability of survival (in percent)\"" << "\n";

			for (int i = 0; i < p_data.getSize(); i++)
			{
				// for each output value, add it to the csv (in %) associated with its time interval
				stream << QString::number(i * p_interval) << "," << QString::number(100*p_data.getGeneState(p_data.getGeneName(i)));
			
				// add new line only if the current line isn't the last one
				if (i != (p_data.getSize() - 1))
				{
					stream << "\n";
				}
			}
		}
		else
		{
			qInfo() << "Error: cannot write csv file";
		}
		file.close();
	}

	void Exporter::exportConvergence(const data::NetworkStateData& p_data, const int& p_interval, const QString& p_path, const QString& p_fileName)
	{
		QFile file(p_path + "/" + p_fileName + ".csv");
		if (file.open(QFile::WriteOnly))
		{
			QTextStream stream(&file);
			stream << "Step, Mean update of the output nodes" << "\n";

			for (int i = 0; i < p_data.getConvergenceValues().size(); i++)
			{
				// for each output value, add it to the csv (in %) associated with its time interval
				stream << QString::number(i) << "," << QString::number(p_data.getConvergenceValues()[i]) << "\n";
			}
		}
		else
		{
			qInfo() << "Error: cannot write csv file";
		}
	}

	void Exporter::exportGraph(const QImage& p_image, const QString& p_path, const QString& p_fileName)
	{
		if (!p_image.save(p_path + "/" + p_fileName + ".png"))
		{
			qInfo() << "Error: cannot write png file";
		}
	}

	void Exporter::exportPatientMutationsToCSV(QMap<QString, double>& p_mutationData, const QString& p_path, const QString& p_fileName)
	{
		QFile file(p_path + "/" + p_fileName + ".csv");
		if (file.open(QFile::WriteOnly))
		{
			QTextStream stream(&file);
			stream << "gene,mutationValue" << "\r\n";

			for (std::pair<QString, double> mutationData : p_mutationData.toStdMap())
			{
				if (mutationData.second < 1e-4)
				{
					stream << mutationData.first << "," << "NA" << "\r\n";
				}
				else
				{
					stream << mutationData.first << "," << mutationData.second << "\r\n";
				}
			}
		}
		else
		{
			qInfo() << "Error: cannot write csv file";
		}
	}
} // io


