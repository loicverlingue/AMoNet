#pragma once

// STL
#include <string>

// Qt

// Library dependencies

// Project dependencies

namespace io {
    /*****************************************************************************************
     * \class CLogLevel
     * \brief Class to manage enum of the different levels of log verbosity
     */
    class CLogLevel
    {

    public:
        /*****************************************************************************************
         * \enum LogLevel
         * \brief Defines the different type of levels
         * remark: For a given level, all the higher levels will be logged!
         */
        enum class ELogLevel { DEBUG, VERBOSE, INFO, WARNING, ERROR };

        /*************************************************************************************
         * \brief Convert a log level name (typically from a settings file) to the corresponding log level
         * \param std::string p_LevelName Log level name, lowercase
         * Returns INFO as default level.
         */
        static ELogLevel FromString(const std::string &p_LevelName);


        /*************************************************************************************
         * \brief Default constructor
         */
        explicit CLogLevel() = delete;

        /*************************************************************************************
         * \brief Copy constructor
         * \param[in] p_Other Object to copy
         */
        CLogLevel(const CLogLevel &p_Other) = delete;

        /*************************************************************************************
         * \brief Copy assignment operator
         * \param[in] p_Other Object to copy
         */
        CLogLevel &operator=(const CLogLevel &p_Other) = delete;

        /*************************************************************************************
         * \brief Destructor
         */
        virtual ~CLogLevel() = delete;

        /*************************************************************************************
         * \brief Move constructor
         * \param[in] p_Other Object to move
         */
        CLogLevel(CLogLevel &&p_Other) = delete;

        /*************************************************************************************
         * \brief Move assignment operator
         * \param[in] p_Other Object to move
         */
        CLogLevel &operator=(CLogLevel &&p_Other) = delete;

    protected:
    private:
    };

} // namespace corin::core::log
