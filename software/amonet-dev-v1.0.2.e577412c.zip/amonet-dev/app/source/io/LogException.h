#pragma once

// STL
#include <exception>
#include <stdexcept>

// Qt
#include <qstring.h>

// Project dependencies

namespace io {
    /*****************************************************************************************
     * \class CLogException
     * \brief Defines exception raised by the log package
     */
    class CLogException : public std::runtime_error
    {
    public:
        /*************************************************************************************
         * \brief Default constructor
         */
        explicit CLogException(const std::string &p_Message);

        /*************************************************************************************
         * \brief Copy constructor
         * \param[in] p_Other Object to copy
         */
        CLogException(const CLogException &p_Other) = default;

        /*************************************************************************************
         * \brief Copy assignment operator
         * \param[in] p_Other Object to copy
         */
        CLogException &operator=(const CLogException &p_Other) = default;

        /*************************************************************************************
         * \brief Destructor
         */
        virtual ~CLogException() = default;

        /*************************************************************************************
         * \brief Move constructor
         * \param[in] p_Other Object to move
         */
        CLogException(CLogException &&p_Other) = default;

        /*************************************************************************************
         * \brief Move assignment operator
         * \param[in] p_Other Object to move
         */
        CLogException &operator=(CLogException &&p_Other) = default;
    };

} // namespace corin::core::log
