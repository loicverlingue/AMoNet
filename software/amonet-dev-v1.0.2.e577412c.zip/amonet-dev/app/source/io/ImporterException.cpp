// Library dependencies

// Project dependencies
#include "ImporterException.h"

namespace io {
    CImporterException::CImporterException(const std::string& p_Message) : std::runtime_error(p_Message)
    {
    }
} // namespace log
