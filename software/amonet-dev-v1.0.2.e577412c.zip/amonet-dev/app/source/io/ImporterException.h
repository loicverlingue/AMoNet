#pragma once

// STL
#include <exception>
#include <stdexcept>

// Qt
#include <qstring.h>

// Project dependencies

namespace io {
    /*****************************************************************************************
     * \class CImporterException
     * \brief Defines exception raised by the importer package
     */
    class CImporterException : public std::runtime_error
    {
    public:
        /*************************************************************************************
         * \brief Default constructor
         */
        explicit CImporterException(const std::string& p_Message);

        /*************************************************************************************
         * \brief Copy constructor
         * \param[in] p_Other Object to copy
         */
        CImporterException(const CImporterException& p_Other) = default;

        /*************************************************************************************
         * \brief Copy assignment operator
         * \param[in] p_Other Object to copy
         */
        CImporterException& operator=(const CImporterException& p_Other) = default;

        /*************************************************************************************
         * \brief Destructor
         */
        virtual ~CImporterException() = default;

        /*************************************************************************************
         * \brief Move constructor
         * \param[in] p_Other Object to move
         */
        CImporterException(CImporterException&& p_Other) = default;

        /*************************************************************************************
         * \brief Move assignment operator
         * \param[in] p_Other Object to move
         */
        CImporterException& operator=(CImporterException&& p_Other) = default;
    };

} // namespace corin::core::log
