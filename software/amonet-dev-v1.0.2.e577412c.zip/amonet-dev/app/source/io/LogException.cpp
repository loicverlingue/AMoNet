// Library dependencies

// Project dependencies
#include "LogException.h"

namespace io {
    CLogException::CLogException(const std::string &p_Message) : std::runtime_error(p_Message)
    {
    }
} // namespace log
