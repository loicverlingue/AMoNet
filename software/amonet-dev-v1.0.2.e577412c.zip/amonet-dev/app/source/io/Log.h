#pragma once

// Qt

// Libraries
#include <sqi/Log/Log.h>

// Project dependencies
#include "io/LogLevel.h"

namespace io {
    /*****************************************************************************************
     * \class CLog
     * \brief Defines a class to acess to the io
     */
    class CLog
    {
    public:
        /*************************************************************************************
         * \brief Default constructor
         */
        explicit CLog();

        /*************************************************************************************
         * \brief Copy constructor
         */
        CLog(const CLog &p_Other) = delete;

        /*************************************************************************************
         * \brief Copy assignment operator
         * \param[in] p_Other Object to copy
         */
        CLog &operator=(const CLog &p_Other) = delete;

        /*************************************************************************************
         * \brief Destructor
         */
        virtual ~CLog();

        /*************************************************************************************
         * \brief Move constructor
         */
        CLog(CLog &&p_Other) = delete;

        /*************************************************************************************
         * \brief Move assignment operator
         * \param[in] p_Other Object to move
         */
        CLog &operator=(CLog &&p_Other) = delete;

        /*************************************************************************************
         * \brief Initialize the io
         * \param[in] p_LogDirectory Path to the Log directory
         * \param[in] p_LogNameWithoutExtension Application name is used for the default log name
         * \param[in] p_MinimumLogLevel Minimum log level which will be saved in the log file
         */
        void Initialize(const std::string &p_LogDirectory, const std::string &p_LogNameWithoutExtension,
                        CLogLevel::ELogLevel p_MinimumLogLevel = CLogLevel::ELogLevel::INFO);

        /*************************************************************************************
         * \brief Log a debug message
         * \param[in] p_Message Message to log
         */
        void LogDebug(const QString &p_Message);

        /*************************************************************************************
         * \brief Log a verbose message
         * \param[in] p_Message Message to log
         */
        void LogVerbose(const QString &p_Message);

        /*************************************************************************************
         * \brief Log an info message
         * \param[in] p_Message Message to log
         */
        void LogInfo(const QString &p_Message);

        /*************************************************************************************
         * \brief Log a warning message
         * \param[in] p_Message Message to log
         */
        void LogWarning(const QString &p_Message);

        /*************************************************************************************
        * \brief Log a error message
        * \param[in] p_Message Message to log
        */
        void LogError(const QString& p_Message);

        CLogLevel::ELogLevel GetCurrentLevel() const;

        void SetCurrentLevel(const CLogLevel::ELogLevel &p_Level);

    private:
        void LogDefault(CLogLevel::ELogLevel p_LogLevel, const QString &p_Message);
        QString GeneratePrefix(CLogLevel::ELogLevel p_Level);

        static constexpr char *PREFIX_VERBOSE = "VERB";
        static constexpr char *PREFIX_DEBUG = "DBG ";
        static constexpr char *PREFIX_INFO = "INFO";
        static constexpr char *PREFIX_WARNING = "WARN";
        static constexpr char *PREFIX_ERROR = "ERR ";

        std::unique_ptr<sqi::log::LogData> m_pLogger;

        bool m_bIsInitialized;

        CLogLevel::ELogLevel m_CurrentLevel;
    };

} // namespace corin::core::log
