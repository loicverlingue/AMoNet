    #ifndef _LogService_
    #define _LogService_

    namespace io
    {
        class CLog;
    }

    namespace io
    {
        class LogService {
        public:
            static CLog& getInstance();

            //! \brief Constructor
            LogService() = delete;

            //! \brief Destructor
            ~LogService() = default;

            LogService(const LogService&) = delete;

            LogService& operator=(const LogService&) = delete;

        };
    };
    #endif //_LogService