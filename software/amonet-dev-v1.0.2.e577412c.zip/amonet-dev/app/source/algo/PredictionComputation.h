#ifndef _algo_PredictionComputation_
#define _algo_PredictionComputation_

//! \file PredictionComputation.h
//! \brief Defines PredictionComputation
//! \author http://www.surgiqual-institute.com/
//! \date March 2021


// Library dependencies

// Project dependencies
#include "data/NetworkData.h"
#include "data/NetworkStateData.h"

namespace algo
{
    //! \class PredictionComputation
    //! \brief Static class with tools to compute prediction
    class PredictionComputation
    {
        // constructor / destructor / operator
    public:
        //! \brief Default constructor
        explicit PredictionComputation() = default;

        //! \brief Destructor
        virtual ~PredictionComputation() = default;

        //! \brief Copy constructor
        //! \param[in] p_other Object to copy
        PredictionComputation(const PredictionComputation& p_other) = default; // To implement if copying is non-trivial

        //! \brief Copy assignment operator
        //! \param[in] p_other Object to copy
        PredictionComputation& operator=(const PredictionComputation& p_other) = default; // To implement if copying is non-trivial

        //! \brief Move constructor
        //! \param[in] p_other Object to move
        PredictionComputation(PredictionComputation&& p_other) = default; // To implement if moving is non trivial

        //! \brief Move assignment operator
        //! \param[in] p_other Object to move
        PredictionComputation& operator=(PredictionComputation&& p_other) = default; // To implement if moving is non trivial

        // get / set
    public:
    protected:
    private:

        // methods / functions / slots
    public:
        //! \brief Predict the survival rate for a given network
        //! \brief The algorithme used in this prediction is from the fist DETSP
        //! \brief the idea is that for each layer, the data are propagated to every targets of the current layer
        //! \param p_network network used for the computation
        //! \return a network state data containing the outputs
        static data::NetworkStateData predictSurvivalRateV0(std::shared_ptr<data::NetworkData> p_network);
    
        //! \brief Predict the survival rate for a given network
        //! \param p_network network used for the computation
        //! \return a network state data containing the outputs
        static data::NetworkStateData predictSurvivalRate(std::shared_ptr<data::NetworkData> p_network, const double p_valMut, const int p_minStepForward);

        //! \brief Sigmo�d function : y = sigmoid(x)
        //! \param p_val parameter of the function : x
        //! \return result of the function : y
        static double sigmoid(const double p_val);
    protected:
    private:
        // members
    protected:
    private:

    };

} // algo

#endif // _algo_PredictionComputation_
