//! \file PredictionComputation.cpp
//! \brief Implements PredictionComputation
//! \author http://www.surgiqual-institute.com/
//! \date March 2021


// Qt
#include <qrandom.h>

// Std
#include <cmath>
#include <ctime>

// Project dependencies
#include "PredictionComputation.h"
#include "app/Locator.h"
#include "app/ApplicationSettings.h"
#include "data/NetworkData.h"
#include "data/NetworkStateData.h"
#include "data/TherapyData.h"
#include "io/Importer.h"
namespace algo
{
	data::NetworkStateData PredictionComputation::predictSurvivalRateV0(std::shared_ptr<data::NetworkData> p_network)
	{
		
		// retrieve settings values
		int minStepForward = app::Locator::getSettings()->getMainSettingsValue<int>("prediction/minStepForward");
		int valMut = app::Locator::getSettings()->getMainSettingsValue<int>("prediction/valMut");
		int nbOfLayers = p_network->getNbOfLayers();

		// Init the random number generator
		QRandomGenerator randGenerator;
		randGenerator.seed(std::time(0));

		// Init the global network state
		data::NetworkStateData stateGlobal;
		auto geneNames = p_network->getGenesNames();

		// The mutation list is handle with a NetworkStateData here
		data::NetworkStateData stateMUT;

		for (int i = 0; i < geneNames->size(); i++)
		{
			stateGlobal.addGeneState(geneNames->at(i), randGenerator.generateDouble());
			stateMUT.addGeneState(geneNames->at(i), p_network->getGenes()->at(i).getMutationValue());
		}

		// extract the number of outputs, ie the number of target of the last layer
		int nbOfOutputs = p_network->extractTargets(p_network->getNbOfLayers()).size();
		for (int i = 1; i <= nbOfOutputs; i++)
		{
			stateGlobal.addGeneState("Output" + QString::number(i), randGenerator.generateDouble());
		}
		
		data::NetworkStateData stateOutput;

		for (int step = 0; step < minStepForward; step++)
		{
			for (int layer = 1; layer <= nbOfLayers; layer++)
			{
				// get the genes in the current layer
				auto genesInLayer = p_network->extractLayer(layer);

				// create state for source and target genes of the current layer
				data::NetworkStateData stateSource;
				data::NetworkStateData stateTarget;
				
				// fill the stateSource and the stateTarget
				for (int i = 0; i < genesInLayer.size(); i++)
				{
					QString sourceName = genesInLayer.at(i).getName();
					stateSource.addGeneState(sourceName, stateGlobal.getGeneState(sourceName));

					// get the list of connection for the current source gene
					auto sourceConnections = genesInLayer.at(i).getConnections();

					// compute state value
					for (int j = 0; j < sourceConnections->size(); j++)
					{
						QString targetName = sourceConnections->at(j).getTarget();
						double targetValue = sourceConnections->at(j).getWeight() * stateSource.getGeneState(sourceName) + sourceConnections->at(j).getBias();

						
						if (!stateTarget.containsGene(targetName))
						{
							stateTarget.addGeneState(targetName, targetValue);
						}
						else
						{
							stateTarget.modifyGeneState(targetName, stateTarget.getGeneState(targetName) + targetValue);
						}
					}
				}

				// apply sigmoid function
				for (int i = 0; i < stateTarget.getSize(); i++)
				{
					QString name = stateTarget.getGeneName(i);

					stateTarget.modifyGeneState(name, sigmoid(stateTarget.getGeneState(name)));
				}

				// apply MUT data
				for (int i = 0; i < stateTarget.getSize(); i++)
				{
					
					QString targetName = stateTarget.getGeneName(i);

					if (!stateMUT.containsGene(targetName))
					{
						stateGlobal.modifyGeneState(targetName, stateTarget.getGeneState(targetName));
					}
					else if (data::mutationTypeFromDouble( stateMUT.getGeneState(targetName) ) == data::MutationType::NO_MUTATION)
					{
						stateGlobal.modifyGeneState(targetName, stateTarget.getGeneState(targetName));
					}
					else
					{
						stateGlobal.modifyGeneState(targetName, valMut*stateMUT.getGeneState(targetName));
					}
				}

				if ((step == minStepForward-1) && (layer == nbOfLayers))
				{
					for (int i = 0; i < stateTarget.getSize(); i++)
					{
						stateOutput.addGeneState(stateTarget.getGeneName(i), stateTarget.getGeneState(stateTarget.getGeneName(i)));
					}
				}
			}

		}

		return stateOutput;

	}

	data::NetworkStateData PredictionComputation::predictSurvivalRate(std::shared_ptr<data::NetworkData> p_network, const double p_valMut, const int p_minStepForward)
	{

		// retrieve settings values
		int minStepForward = p_minStepForward;
		double valMut = p_valMut;
		int nbOfLayers = p_network->getNbOfLayers();
		
		// Init the random number generator
		QRandomGenerator randGenerator;
		randGenerator.seed(std::time(0));
		
		// Init the global network state
		data::NetworkStateData stateGlobal;
		auto geneNames = p_network->getGenesNames();

		// Retrieve therapy effects
		auto therapyEffect = p_network->getTherapy()->getEffectOnGenes();
		
		// The mutation list is handle with a NetworkStateData here
		data::NetworkStateData stateMUT;
		
		// init the global state and the MUT state
		for (int i = 0; i < geneNames->size(); i++)
		{
			stateGlobal.addGeneState(geneNames->at(i), randGenerator.generateDouble());
			stateMUT.addGeneState(geneNames->at(i), p_network->getGenes()->at(i).getMutationValue());
		}

		// extract the number of outputs, ie the number of target of the last layer
		int nbOfOutputs = p_network->extractTargets(p_network->getNbOfLayers()).size();
		for (int i = 1; i <= 10; i++)
		{
			stateGlobal.addGeneState("Output" + QString::number(i), randGenerator.generateDouble());
		}
		
		// extract targets of each layers
		QList<QStringList> targetsPerLayer;
		for (int i = 1; i < p_network->getNbOfLayers() + 1; i++)
		{
			targetsPerLayer.append(p_network->extractTargets(i));
		}
		
		// extract all the source genes
		auto sourceGenes = p_network->getGenes();
		
		std::vector<double> convergenceValues;

		// perform several iterations
		for (int step = 0; step < minStepForward; step++)
		{
			// init the state of the current step
			data::NetworkStateData currentState = stateGlobal;
		
			for (int layer = 1; layer <= nbOfLayers; layer++)
			{
				data::NetworkStateData stateTarget;
				// retrieve targets of the current layer
				auto targetsInLayer = targetsPerLayer.at(layer - 1);
		
				// for all source genes, find if they are targeting a gene in targetsInLayer
				for (int i = 0; i < sourceGenes->size(); i++)
				{
					auto currentGene = sourceGenes->at(i);
		
					for (int j = 0; j < currentGene.getConnections()->size(); j++)
					{
						auto currentConnection = currentGene.getConnections()->at(j);
						
						// check if the current target is in the list of targets of the current layer
						if (targetsInLayer.contains(currentConnection.getTarget()))
						{
							if (!stateTarget.containsGene(currentConnection.getTarget()))
							{
								// if the current target is not already in the target state, add it with the value State(sourceGene)*Weight(currentTarget) + Bias(currentTarget)
								stateTarget.addGeneState(currentConnection.getTarget(), stateGlobal.getGeneState(currentGene.getName()) * currentConnection.getWeight() + currentConnection.getBias());
							}
							else
							{
								// if already in the target state, modidy it's value : newValue = oldValue + State(sourceGene)*Weight(currentTarget)
								stateTarget.modifyGeneState(currentConnection.getTarget(), stateTarget.getGeneState(currentConnection.getTarget()) + stateGlobal.getGeneState(currentGene.getName()) * currentConnection.getWeight());
							}
						}
					}
					
				}
		
				// apply sigmoid function to the targets
				for (int i = 0; i < stateTarget.getSize(); i++)
				{
					QString name = stateTarget.getGeneName(i);
					stateTarget.modifyGeneState(name, sigmoid(stateTarget.getGeneState(name)));
				}
		
				// add the new values to the current state
				for (int i = 0; i < currentState.getSize(); i++)
				{
					QString currentGene = currentState.getGeneName(i);
					
					// add new values for the targets of this layer
					if (stateTarget.containsGene(currentGene))
					{
						currentState.modifyGeneState(currentGene, stateTarget.getGeneState(currentGene));
					}

					// apply therapy and mutation data for all source genes
					if (stateMUT.containsGene(currentGene))
					{
						if (therapyEffect.contains(currentGene))
						{
							currentState.modifyGeneState(currentGene, valMut * therapyEffect.value(currentGene));
						}
						else if (stateMUT.getGeneState(currentGene) != 0.0)
						{
							currentState.modifyGeneState(currentGene, valMut * stateMUT.getGeneState(currentGene));
						}
					}
		
				}
			}
		
			double convergenceValue = 0.;
			// update the global state
			for (int i = 0; i < currentState.getSize(); i++)
			{
				if (stateGlobal.containsGene(currentState.getGeneName(i)))
				{
					if (currentState.getGeneName(i).contains("Output")) {
						convergenceValue += std::abs(stateGlobal.getGeneState(currentState.getGeneName(i)) - currentState.getGeneState(currentState.getGeneName(i)));
					}
					stateGlobal.modifyGeneState(currentState.getGeneName(i), currentState.getGeneState(currentState.getGeneName(i)));
				}
			}
			if (nbOfOutputs != 0)
			{
				convergenceValues.push_back(convergenceValue / (double)nbOfOutputs);
				qInfo() << "convergence value for step " << step << " is : " << convergenceValues.back();
			}
			else
			{
				qInfo() << "no outputs";
			}
		}
		// retrieve the outputs values
		data::NetworkStateData outputs;
		for (int i = 0; i < stateGlobal.getSize(); i++)
		{
			if (stateGlobal.getGeneName(i).contains("Output"))
			{
				outputs.addGeneState(stateGlobal.getGeneName(i), stateGlobal.getGeneState(stateGlobal.getGeneName(i)));
			}
			
		}
		outputs.setConvergenceValues(convergenceValues);
		return outputs;

	}

	double PredictionComputation::sigmoid(const double p_val)
	{
		return 1 / (1 + std::exp(-p_val));
	}
	
} // algo


